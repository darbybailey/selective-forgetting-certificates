"""Replay the six deterministic proof experiments, comparing with the saved records."""
from pathlib import Path
import json
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
SUITES = ("projection", "counting", "holes", "merge", "collision", "memory")


def main():
    for name in SUITES:
        directory = ROOT / name
        result = subprocess.run(
            [sys.executable, "-B", str(directory / "run.py")],
            cwd=directory,
            capture_output=True,
            text=True,
        )
        if result.returncode:
            sys.exit(f"{name} failed\n{result.stderr}")
        if name != "merge":
            expected = json.loads((directory / "RESULTS.json").read_text())
            if json.loads(result.stdout) != expected:
                sys.exit(f"{name} produced different results")
        # The merge suite checks its own reconstructed record byte for byte.
        print(f"PASS  {name}", flush=True)
    print("All six suites reproduced.")


if __name__ == "__main__":
    main()
