# Safe successors from exact Euler-tour counts

## Raw input and counting convention

Let D be a labeled directed graph with n ≥ 1 vertices. A witness is a permutation of the vertices with one cycle such that each successor pair is an arc of D. Cyclic rotations give the same witness. Writing the cyclic order starting with vertex 0 gives one representative. For n = 1 a loop is required.

Make a bipartite graph with tail and head copies of every vertex and join tail(i) to head(j) for every arc i→j. Each connected component is called a station. A Hamiltonian cycle matches all tail and head copies, so a component with unequal part sizes certifies impossibility. At each balanced station, fill its incidence block to a complete bipartite graph. Call the missing pairs holes H, and write k = |H|. The station multigraph R has one distinguished directed wire for vertex i, from the station of head(i) to the station of tail(i). Each station is balanced. Cyclic Euler orders of its wires are exactly the Hamiltonian cycles of the completed D. Avoiding H recovers the cycles of D.

Błażewicz, Kasprzak, Leroy-Beaulieu and de Werra explicitly describe this cluster completion and the forbidden-transition reduction in Theorem 2 and Remark 9 of *Finding Hamiltonian circuits in quasi-adjoint graphs* (2008). They also establish the general computational hardness. [Original paper](https://doi.org/10.1016/j.dam.2008.03.014)

## Pinned count and inclusion–exclusion

For a set Q of forced transitions, let C(Q) count the completed graph's cyclic Euler orders containing Q. Conflicting incoming or outgoing pins and pins joining incompatible stations give C(Q)=0. Otherwise the pins form vertex-disjoint directed paths and cycles on the wire labels. A forced proper cycle gives zero, and a forced cycle containing all wires gives one. Contract each remaining path to a distinguished arc with the endpoints of the path. Include isolated wires as one-wire paths. Expanding the paths uniquely in cyclic order gives a bijection between tours before and after contraction. The resulting multigraph is balanced on its active stations.

For contracted edges E, fix any active root station r. The BEST theorem and the directed matrix-tree theorem give

    C(Q) = det(L with row and column r removed) × ∏_v (outdegree(v)−1)!.

L is the outgoing Laplacian on the active stations. Loops cancel in L and contribute to outdegree. The empty determinant is one. The count treats parallel arcs as distinguished. Equivalently each cyclic order has a unique linearization starting with a specified arc out of r. If the active part is disconnected, the cofactor vanishes. The one-arc loop has count one. [BEST theorem and determinant computation](https://drops.dagstuhl.de/storage/00lipics/lipics-vol388-esa2026/html/LIPIcs.ESA.2026.60/LIPIcs.ESA.2026.60.html)

For P consisting of allowed pins, exact inclusion–exclusion gives

    Z(P) = ∑_{S⊆H} (−1)^|S| C(P∪S).

Any compatible S contains at most one hole per row and at most one per column. For row sizes h_i and column sizes g_j, at most min(∏_i(1+h_i), ∏_j(1+g_j)) ≤ 2^k terms need evaluation. The total deterministic bit cost is 2^k poly(n), polynomial when k = O(log n). Cofactors, factorials and sums have polynomial bit length by elementary factorial and determinant bounds. For a tail still free under P, Z(P) is the sum of Z(P∪{i→j}) over its allowed successors. Choosing any positive branch and repeating recovers a verified witness using at most n² pinned-count calls. The canonical stations and holes are computed from the original raw graph for every call, so pinning does not require a structural promise on a residual graph.

## A polynomial test with unrestricted hole count

Let T be a forest on the k holes and define

    L_T(P) = C(P) − ∑_{h∈H} C(P∪{h}) + ∑_{ab∈T} C(P∪{a,b}).

For a completed tour let U be its set of realized holes. Its contribution is 1−|U|+|E(T[U])|. This equals one when U is empty and equals one minus the number of induced forest components otherwise. Consequently L_T(P) ≤ Z(P). Choose a maximum-weight forest with weights C({a,b}), then fix T. This maximizes the initial bound over all forests and takes O(k²) polynomial-time count calls. L_T(P) is additive when partitioning by the next ambient successor. An inadmissible successor can contribute at most zero because all tours through it have U nonempty. If L_T(P)>0 there is an allowed successor with positive score. Repeat to extract a complete witness. At most n² branch comparisons are necessary and each score takes O(k+1) polynomial-time count calls. Negative or zero scores leave existence undetermined.

The forest inequality is Hunter's classical upper bound on a union, applied to the uniform completed Euler-tour measure. The conditional-expectation extraction is a standard derandomization argument. No priority is claimed for the combination. [Hunter, *An upper bound for the probability of a union* (1976)](https://www.cambridge.org/core/journals/journal-of-applied-probability/article/an-upper-bound-for-the-probability-of-a-union/092D711504BA968EF0D1D903A2685D60)

## Matched infinite positive and negative controls

Take d≥5 vertices on each side and all arcs between the two sides in both directions. Forward transitions give a permutation f and reverse transitions a permutation g. Their union gives a Hamiltonian cycle precisely when g∘f is a d-cycle. For each fixed f there are (d−1)! choices of g, so the ambient count is N=d!(d−1)!. The forward permutation is uniform. A given forward transition occurs in N/d tours and two distinct ones in the same row or column never co-occur. Every other forward pair occurs in N/[d(d−1)].

Delete one forward perfect matching. The bound using singles is zero. All d forbidden cells are mutually compatible in pairs, so any spanning tree gives L=N/d>0. This yields a deterministic witness for arbitrarily many holes covering distinct rows and columns. Delete two forward cyclic matchings i→i and i→i+1 in local coordinates. The incidence block stays connected, since allowable offsets 2 and 3 differ by one. There are 2d holes. Every forest has at most 2d−1 edges, hence

    L/N ≤ −1 + (2d−1)/[d(d−1)] < 0.

Nevertheless f(i)=i+2 and g(j)=j−1 modulo d give the full cyclic shift g(f(i))=i+1. This refutes completeness of the optimized forest rule even on a simple explicit family. The positive and negative controls are implemented for d=5 and d=16.

More generally the same f,g argument works for an arbitrary forward 0-1 adjacency matrix A and all reverse arcs. The underlying undirected graph is connected and bipartite because all reverse arcs are present. Its bipartition is recoverable up to swapping the sides by a two-color traversal, and checking completeness in each direction is polynomial. Existence and construction reduce to a bipartite perfect matching. Once f is found, choose any d-cycle c and set g=c∘f⁻¹. The exact count is (d−1)! perm(A), so counting in this subclass is #P-hard by a polynomial-time one-call reduction allowing integer division. The distinction between evaluating a counting polynomial and finding a single valid successor occurs even in this elementary setting. [Valiant, *The complexity of computing the permanent* (1979)](https://doi.org/10.1016/0304-3975(79)90044-6)

## Tests and scope

Run `python3 run.py` and compare its output with `RESULTS.json`. All 4,160 loopless labeled digraphs on three or four vertices were compared with independent vertex-permutation enumeration. Forty seeded six-vertex graphs permitting loops and pinned cases were also compared. For 512 choices of a 3×3 forward matrix the complete-reverse construction was recognized and solved using alternating-path bipartite matching on both the original and a seeded vertex permutation, the witness was checked, and all exact counts were compared with the permanent formula and independent permutation enumeration. In a separate 64-vertex control, all thirty missing transitions share one tail, leaving two allowed successors. The exact solver evaluates 31 contracted counts for the initial graph and obtains 2(31!)² cycles. Both successor branches independently give (31!)². The recovered tour is checked against every edge of the original graph.

These rules give efficiently identifiable positive cases for directed Hamiltonicity. No guarantee is proved for the unrestricted task or for the earlier three-coloring compiler. Priority for the parameterized and conditional tests has not been established.
