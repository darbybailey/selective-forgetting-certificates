"""Count directed Hamiltonian cycles by completing stations and excluding holes."""
from collections import defaultdict
from itertools import permutations
from math import factorial, prod
from random import Random
import json


def stations(rows):
    """Return a wire for each label, plus forbidden transitions, or None."""
    n = len(rows)
    neighbors = [set() for _ in range(2 * n)]
    for i, row in enumerate(rows):
        for j in row:
            neighbors[i].add(n + j)
            neighbors[n + j].add(i)
    component = [-1] * (2 * n)
    holes = []
    for start in range(2 * n):
        if component[start] >= 0:
            continue
        stack = [start]
        component[start] = start
        tails, heads = [], set()
        while stack:
            i = stack.pop()
            if i < n:
                tails.append(i)
            else:
                heads.add(i - n)
            for j in neighbors[i]:
                if component[j] < 0:
                    component[j] = start
                    stack.append(j)
        if len(tails) != len(heads):
            return None
        holes.extend((i, j) for i in tails for j in heads - rows[i])
    return [(component[n+i], component[i]) for i in range(n)], sorted(holes)


def determinant(a):
    """Fraction-free Bareiss elimination on integer entries."""
    if not a:
        return 1
    a = [row[:] for row in a]
    n, sign, previous = len(a), 1, 1
    for i in range(n - 1):
        if a[i][i] == 0:
            k = next((j for j in range(i + 1, n) if a[j][i]), None)
            if k is None:
                return 0
            a[i], a[k] = a[k], a[i]
            sign = -sign
        pivot = a[i][i]
        for j in range(i + 1, n):
            for k in range(i + 1, n):
                a[j][k] = (pivot*a[j][k] - a[j][i]*a[i][k]) // previous
        previous = pivot
    return sign * a[-1][-1]


def best(edges):
    """Cyclic Euler orders of distinguished arcs of a balanced multigraph."""
    vertices = sorted({v for edge in edges for v in edge})
    index = {v: i for i, v in enumerate(vertices)}
    lap = [[0] * len(vertices) for _ in vertices]
    degree = [0] * len(vertices)
    for u, v in edges:
        i, j = index[u], index[v]
        degree[i] += 1
        lap[i][i] += 1
        lap[i][j] -= 1
    trees = determinant([row[1:] for row in lap[1:]])
    return trees * prod(factorial(d - 1) for d in degree)


def spliced_count(wires, successor, predecessor):
    """Contract paths of forced transitions, treating forced circuits separately."""
    n = len(wires)
    if len(predecessor) == n:
        i, length = successor[0], 1
        while i:
            i, length = successor[i], length + 1
        return int(length == n)
    seen = 0
    edges = []
    for first in range(n):
        if first in predecessor:
            continue
        last = first
        seen += 1
        while last in successor:
            last = successor[last]
            seen += 1
        edges.append((wires[first][0], wires[last][1]))
    return best(edges) if seen == n else 0


def count_cycles(rows, pins=(), stats=None):
    n = len(rows)
    if not n:
        raise ValueError("A cycle requires at least one vertex.")
    data = stations(rows)
    if data is None:
        return 0
    wires, holes = data
    successor, predecessor = {}, {}
    for i, j in pins:
        if j not in rows[i] or (i in successor and successor[i] != j):
            return 0
        if j in predecessor and predecessor[j] != i:
            return 0
        successor[i], predecessor[j] = j, i
    row_groups, col_groups = defaultdict(list), defaultdict(list)
    for i, j in holes:
        if i not in successor and j not in predecessor:
            row_groups[i].append((i, j))
            col_groups[j].append((i, j))
    groups = min((row_groups, col_groups),
                 key=lambda g: prod(1+len(v) for v in g.values()))
    groups = sorted(groups.values(), key=len, reverse=True)

    def total(k):
        if k == len(groups):
            if stats is not None:
                stats["spliced_counts"] += 1
            return spliced_count(wires, successor, predecessor)
        answer = total(k + 1)
        for i, j in groups[k]:
            if i in successor or j in predecessor:
                continue
            successor[i], predecessor[j] = j, i
            answer -= total(k + 1)
            del successor[i], predecessor[j]
        return answer

    return total(0)


def recover(rows):
    """Select the first positive-count successor for each still-unpinned tail."""
    if not count_cycles(rows):
        return None
    pins = []
    for i, row in enumerate(rows):
        for j in sorted(row):
            if count_cycles(rows, pins + [(i, j)]):
                pins.append((i,j))
                break
        else:
            raise AssertionError("A positive count must have a positive branch.")
    return dict(pins)


def brute_cycles(rows):
    n = len(rows)
    result = []
    for suffix in permutations(range(1, n)):
        path = (0,) + suffix
        edges = frozenset(zip(path, path[1:] + path[:1]))
        if all(j in rows[i] for i, j in edges):
            result.append(edges)
    return result


def ambient(wires, pins):
    successor, predecessor = {}, {}
    for i, j in pins:
        if wires[i][1] != wires[j][0]:
            return 0
        if (i in successor and successor[i] != j) or (j in predecessor and predecessor[j] != i):
            return 0
        successor[i], predecessor[j] = j, i
    return spliced_count(wires, successor, predecessor)


def best_forest(wires, holes):
    """Kruskal on exact pair-intersection counts; zero-weight edges are optional."""
    from itertools import combinations
    weighted = sorted(((ambient(wires, (a,b)), a, b) for a,b in combinations(holes,2)),
                      reverse=True)
    parent = {a:a for a in holes}
    def root(a):
        while a != parent[a]:
            parent[a] = parent[parent[a]]
            a = parent[a]
        return a
    forest = []
    for weight,a,b in weighted:
        if not weight:
            break
        x, y = root(a), root(b)
        if x != y:
            parent[x] = y
            forest.append((a,b))
    return forest


def lower_bound(wires, holes, forest, pins):
    total = ambient(wires, pins)
    if not total:
        return 0
    singles = sum(ambient(wires, pins+[a]) for a in holes)
    pairs = sum(ambient(wires, pins+[a,b]) for a,b in forest)
    return total - singles + pairs


def forest_witness(rows):
    data = stations(rows)
    if data is None:
        return None, 0
    wires, holes = data
    forest = best_forest(wires, holes)
    initial = lower_bound(wires, holes, forest, [])
    if initial <= 0:
        return None, initial
    pins = []
    for i, row in enumerate(rows):
        for j in sorted(row):
            if lower_bound(wires, holes, forest, pins+[(i,j)]) > 0:
                pins.append((i,j))
                break
        else:
            raise AssertionError("Positive score guarantees a viable successor")
    return dict(pins), initial


def matching_controls(d):
    result = {}
    scale = factorial(d-1)**2
    for t in (1,2):
        rows = [set(range(d,2*d)) for _ in range(d)] + [set(range(d)) for _ in range(d)]
        for i in range(d):
            for shift in range(t):
                rows[i].remove(d+(i+shift)%d)
        wires, holes = stations(rows)
        baseline = lower_bound(wires,holes,[],[])
        assert baseline == (1-t)*d*scale
        witness, score = forest_witness(rows)
        if t == 1:
            assert witness is not None and score == scale
        else:
            assert witness is None and score < 0
            # A direct independent witness for the two-deletion negative control.
            witness = {i:d+(i+2)%d for i in range(d)}
            witness.update({d+i:(i-1)%d for i in range(d)})
        tour, i = [], 0
        for step in range(2*d):
            tour.append(i)
            j = witness[i]
            assert j in rows[i]
            i = j
        assert i == 0 and len(set(tour)) == 2*d
        result[f"deleted_matchings_{t}"] = dict(vertices=2*d, holes=t*d,
            first_moment_bound=str(baseline), best_forest_bound=str(score),
            certified_by_forest=t==1, edge_verified_tour=tour)
    return result


def one_sided_witness(rows):
    """Recognize and solve bipartite digraphs complete in one direction."""
    n = len(rows)
    undirected = [set(row) for row in rows]
    for i, row in enumerate(rows):
        for j in row:
            undirected[j].add(i)
    side = {0:0}
    stack = [0]
    while stack:
        i = stack.pop()
        for j in undirected[i]:
            if j in side:
                if side[j] == side[i]:
                    return "OUTSIDE", None
            else:
                side[j] = 1-side[i]
                stack.append(j)
    if len(side) != n:
        return "OUTSIDE", None
    parts = [{i for i in side if side[i] == x} for x in (0,1)]
    if len(parts[0]) != len(parts[1]):
        return "OUTSIDE", None
    left, right = parts
    if not all(rows[j] == left for j in right):
        left, right = right, left
        if not all(rows[j] == left for j in right):
            return "OUTSIDE", None
    matched_left, matched_right = {}, {}
    ordered = sorted(left)
    for start in ordered:
        # Find an alternating path from start to an unmatched right vertex.
        stack = [start]
        parent = {}
        end = None
        while stack and end is None:
            i = stack.pop()
            for j in sorted(rows[i]):
                if j in parent:
                    continue
                parent[j] = i
                if j not in matched_right:
                    end = j
                    break
                stack.append(matched_right[j])
        if end is None:
            return "NO", None
        while end is not None:
            i = parent[end]
            previous = matched_left.get(i)
            matched_left[i], matched_right[end] = end, i
            end = previous
    successor = dict(matched_left)
    for pos, i in enumerate(ordered):
        successor[matched_left[i]] = ordered[(pos+1)%len(ordered)]
    return "YES", successor


def check():
    records = {}
    for n in (3, 4):
        arcs = [(i,j) for i in range(n) for j in range(n) if i != j]
        positives = total_count = pin_checks = 0
        for mask in range(1 << len(arcs)):
            rows = [set() for _ in range(n)]
            for bit, (i,j) in enumerate(arcs):
                if mask >> bit & 1:
                    rows[i].add(j)
            truth = brute_cycles(rows)
            assert count_cycles(rows) == len(truth)
            positives += bool(truth)
            total_count += len(truth)
            if mask % 17 == 0:
                for j in range(n):
                    assert count_cycles(rows, [(0,j)]) == sum((0,j) in t for t in truth)
                    pin_checks += 1
        records[f"all_loopless_n{n}"] = dict(graphs=2**len(arcs), positive=positives,
                                               sum_of_counts=total_count, pin_checks=pin_checks)
    rng = Random(54298)
    n = 6
    pins_checked = 0
    for _ in range(40):
        rows = [{j for j in range(n) if rng.random() < 0.7} for i in range(n)]
        truth = brute_cycles(rows)
        assert count_cycles(rows) == len(truth)
        for _ in range(4):
            pins = [(rng.randrange(n),rng.randrange(n)) for _ in range(rng.randrange(1,5))]
            assert count_cycles(rows, pins) == sum(set(pins) <= t for t in truth)
            pins_checked += 1
    records["looped_n6"] = dict(graphs=40, pins=pins_checked, seed=54298)
    rows = [set(range(4)) for _ in range(4)]
    controls = {
        "empty_singleton":count_cycles([set()]),
        "loop_singleton":count_cycles([{0}]),
        "proper_subtour":count_cycles(rows,[(0,1),(1,0)]),
        "full_four_cycle":count_cycles(rows,[(0,1),(1,2),(2,3),(3,0)]),
        "two_subtours":count_cycles(rows,[(0,1),(1,0),(2,3),(3,2)]),
        "conflicting_predecessors":count_cycles(rows,[(0,1),(2,1)]),
        "disconnected_stations":count_cycles([{1},{0},{3},{2}])
    }
    assert list(controls.values()) == [0,1,0,1,0,0,0]
    records["edge_cases"] = controls
    d = 3
    count_sum = positives = 0
    for mask in range(1 << (d*d)):
        forward = [{j for j in range(d) if mask >> (d*i+j) & 1} for i in range(d)]
        rows = [{d+j for j in row} for row in forward] + [set(range(d)) for _ in range(d)]
        permanent = sum(all(j in forward[i] for i,j in enumerate(p)) for p in permutations(range(d)))
        expected = factorial(d-1)*permanent
        truth = brute_cycles(rows)
        assert len(truth) == expected
        status, construction = one_sided_witness(rows)
        assert status == ("YES" if expected else "NO")
        if construction:
            assert frozenset(construction.items()) in truth
        perm = list(range(2*d))
        rng.shuffle(perm)
        permuted = [set() for _ in perm]
        for i, row in enumerate(rows):
            permuted[perm[i]] = {perm[j] for j in row}
        status2, construction2 = one_sided_witness(permuted)
        assert status == status2
        if construction2:
            assert frozenset(construction2.items()) in brute_cycles(permuted)
        assert count_cycles(rows) == expected
        positives += bool(permanent)
        count_sum += expected
    records["asymmetric_bipartite_all_forward_3x3"] = dict(graphs=512, positive=positives,
                                                            sum_of_counts=count_sum)
    for d in (6,32):
        rows = [set(range(d,2*d)) for _ in range(d)] + [set(range(d)) for _ in range(d)]
        rows[0] = {d, d+1}
        assert len(stations(rows)[1]) == d-2
        stats = {"spliced_counts":0}
        count = count_cycles(rows,stats=stats)
        expected_per_arc = factorial(d-1)**2
        assert count == 2*expected_per_arc
        assert count_cycles(rows,[(0,d)]) == expected_per_arc
        assert count_cycles(rows,[(0,d+1)]) == expected_per_arc
        recovered = recover(rows)
        i, tour = 0, []
        for _ in range(2*d):
            tour.append(i)
            j = recovered[i]
            assert j in rows[i]
            i = j
        assert i == 0 and len(set(tour)) == 2*d
        records[f"one_row_d{d}"] = dict(vertices=2*d, holes=d-2, count=str(count),
                  count_per_allowed_pin=str(expected_per_arc), verified_tour=tour, **stats)
    for d in (5, 16):
        records[f"forest_controls_d{d}"] = matching_controls(d)
    return records


if __name__ == "__main__":
    print(json.dumps(check(), indent=2, sort_keys=True))
