"""A literal-weight projection of the historical four-matching construction onto HC."""
from collections import Counter, defaultdict, deque
from itertools import permutations, product
from math import factorial, prod
from pathlib import Path
from random import Random
import json
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent / "vendor"))
from one_defect_hard import audit_structure, compile_nae, good, normalized_quotient, plane


def negate(row):
    return tuple(-x for x in row)


class Circuit:
    """Signed integer gate labels; bit 1 is the pinned false reference."""
    def __init__(self, first_gate):
        self.first = first_gate
        self.gates = []
        self.cache = {}

    def and_gate(self, a, b):
        if a == 1 or b == 1 or a == -b:
            return 1
        if a == -1 or a == b:
            return b
        if b == -1:
            return a
        key = tuple(sorted((a,b)))
        if key not in self.cache:
            self.cache[key] = self.first + len(self.gates)
            self.gates.append(key)
        return self.cache[key]

    def conjunction(self, literals):
        z = -1
        for x in literals:
            z = self.and_gate(z, x)
        return z

    def disjunction(self, literals):
        return -self.conjunction(-x for x in literals)


def gate_rows(c, a, b, f):
    return [(-c,a,f),(-c,b,f),(-a,-b,c)]


def hc_verifier(m):
    arcs = [(i,j) for i in range(m) for j in range(m) if i != j]
    names = {arc: i+2 for i,arc in enumerate(arcs)}
    circuit = Circuit(len(arcs) + 2)
    tests = []
    for u in range(m):
        for local in ([x for (i,j),x in names.items() if i == u],
                      [x for (i,j),x in names.items() if j == u]):
            tests.append(circuit.disjunction(local))
            tests.extend(-circuit.and_gate(a,b) for pos,a in enumerate(local)
                         for b in local[pos+1:])
    # Reachability in at most m-1 steps, including zero steps at vertex 0.
    reach = [-1] + [1]*(m-1)
    for _ in range(m-1):
        reach = [circuit.disjunction([reach[j]] + [
            circuit.and_gate(reach[i],names[i,j]) for i in range(m) if i != j
        ]) for j in range(m)]
    output = circuit.conjunction(tests + reach)
    signed = []
    for idx,(a,b) in enumerate(circuit.gates, circuit.first):
        signed.extend(gate_rows(idx, a,b,1))
    signed.append((output,1,1))
    return arcs, signed, len(circuit.gates)


def read_pinned_chart():
    rows = [r for direction in plane() for r in direction][2:]
    choices = [x for x in product((0,1),repeat=9) if all(good(r,x) for r in rows)]
    histogram = Counter(x[:6] for x in choices)
    assert sorted(histogram.values()) == [6,6]
    pinned = [x for x in choices if x[6:] == (0,0,1)]
    assert len(pinned) == 2 and pinned[0][:6] == (0,0,0,1,1,1) and pinned[1][:6] == (1,1,1,0,0,0)
    return {x[0]:x for x in pinned}


class Propagation:
    """A verifier of the decoded physical rows, independent of the AND schedule."""
    def __init__(self, nae):
        cnf = set()
        for row in nae:
            for c in (row, negate(row)):
                s = frozenset(c)
                if not any(-l in s for l in s):
                    cnf.add(tuple(sorted(s)))
        self.clauses = sorted(cnf)
        self.n = max(abs(l) for c in cnf for l in c)
        self.units = [c[0] for c in self.clauses if len(c)==1]
        self.incidence = defaultdict(list)
        for c in self.clauses:
            for literal in c:
                self.incidence[literal].append(c)

    def solve_with_inputs(self, initial):
        assignment = [None]*(self.n+1)
        work = deque([*initial,*self.units])
        while work:
            literal = work.popleft()
            u = abs(literal)
            value = int(literal>0)
            if assignment[u] is not None:
                if assignment[u] != value:
                    return None
                continue
            assignment[u] = value
            for clause in self.incidence[-literal]:
                free = []
                for l in clause:
                    b=assignment[abs(l)]
                    if b is None:
                        free.append(l)
                    elif b == int(l>0):
                        break
                else:
                    if not free:
                        return None
                    if len(free)==1:
                        work.append(free[0])
        assert None not in assignment[1:], "An output was undetermined by the projected rows."
        return assignment


def independent_cycles(m, arcs):
    index = {edge: k for k,edge in enumerate(arcs)}
    masks = []
    for order in permutations(range(1,m)):
        walk = (0, *order, 0)
        masks.append(sum(1<<index[i,j] for i,j in zip(walk,walk[1:])))
    return sorted(masks)


def case(m, pinned):
    arcs, signed, logical_gates = hc_verifier(m)
    groups, owners = compile_nae(signed,3)
    n = len(owners)*9
    audit_structure(groups,n)
    recovered, _ = normalized_quotient(groups)
    propagate = Propagation(recovered)
    reps = {}
    for b,v in enumerate(owners):
        reps.setdefault(v,9*b)
    assert set(reps) == set(range(1,propagate.n+1))
    support = []
    for mask in range(1<<len(arcs)):
        initial = [-1] + [(i+2 if mask>>i&1 else -(i+2)) for i in range(len(arcs))]
        sol = propagate.solve_with_inputs(initial)
        if sol is None:
            continue
        word = [z for v in owners for z in pinned[sol[v]]]
        assert word[reps[1]]==0
        assert all(word[b*9+6:b*9+9] == [0,0,1] for b in range(len(owners)))
        assert all(good(c,word) for group in groups for c in group)
        actual_mask = sum(word[reps[j+2]]<<j for j in range(len(arcs)))
        assert actual_mask==mask
        support.append(actual_mask)
    target = independent_cycles(m,arcs)
    assert support == target and len(support)==factorial(m-1)
    rng=Random(972441+m)
    probes=[[1]*len(arcs),[0]*len(arcs),*[ [rng.randint(-8,9) for _ in arcs] for _ in range(14)]]
    for weights in probes:
        seen = sum(prod(weights[j] for j in range(len(arcs)) if mask>>j&1) for mask in support)
        reference = sum(prod(weights[arcs.index(e)] for e in zip((0,*p),(*p,0))) for p in permutations(range(1,m)))
        assert seen==reference and all(seen%q==reference%q for q in (2,3,5))
    return {"cities":m,"edge_input_bits":len(arcs),"and_gates":logical_gates,"signed_rows":len(signed),
            "physical_points":n,"physical_triples":sum(map(len,groups)),"charts":len(owners),
            "boolean_edge_selections_exhausted":1<<len(arcs),
            "distinct_monomials_each_coefficient_one":len(support),
            "one_physical_model_recounted_per_monomial":len(support),
            "evaluations_per_ring":len(probes),
            "sum_at_all_ones_in_Z_F2_F3_F5":[len(support),*(len(support)%q for q in (2,3,5))]}


def main():
    for a,b,c in product((0,1), repeat=3):
        v={1:0,2:a,3:b,4:c}
        good_rows=all(len({v[abs(l)]^(l<0) for l in row})==2 for row in gate_rows(4,2,3,1))
        assert good_rows==(c==(a&b))
    charts=read_pinned_chart()
    return {"and_truth_table":8,"nine_point_local_colorings_exhausted":512,
            "test_fields":[2,3,5],"cases":[case(m,charts) for m in (2,3,4)]}


if __name__=="__main__":
    print(json.dumps(main(),indent=2))
