# Weighted colorings and one safe choice

Read NOTE.md or its PDF equivalent. From the extracted package, run:

    python3 verify.py

All six suites are deterministic and run using Python 3.10+ with the standard library. All proofs and local inputs are included. Each suite has its full argument in PROOF.md, executable checks in run.py, and its recorded output in RESULTS.json. The counting suite reuses the projection compiler. A byte-for-byte copy of the earlier four-matching compiler is in projection/vendor.

| Directory | Claim and control |
|---|---|
| projection | Hamiltonian-cycle projection with coefficient one in every field. A known witness exists on each unweighted base instance. |
| counting | One formal variable per point suffices. Removing weights and encoding absent arcs gives an explicit integer count and its exact multiplicity. |
| holes | Matching reader with a completely unrestricted reverse side, exact counts for few forbidden transitions, constructive forest certificate and an infinite failure family. |
| merge | Monotone successor switches with an explicit density bound, a cover that blocks all joining switches and a parity obstruction. |
| collision | Two graphs share the same tail-and-option cover data but differ on Hamiltonicity. Random minimum covers can also miss a unique Hamiltonian cycle. |
| memory | Sharp universal linear-memory requirement against arbitrary continuations and an exact graph-specific existence criterion. |

All graph and hypergraph claims use the input conventions in their proofs. These tests neither build the external Lean development nor run the earlier seven-way compiler on new arbitrary SAT branches. The supplied note cites the original release and the relevant prior work.
