"""Check the one-weight projection and the integer multiplicity of unweighted graphs."""
import importlib.util
import json
from collections import Counter
from itertools import permutations, product
from pathlib import Path


module_path = Path(__file__).resolve().parents[1] / "projection" / "run.py"
spec = importlib.util.spec_from_file_location("actor_projection", module_path)
compiler = importlib.util.module_from_spec(spec)
spec.loader.exec_module(compiler)


def local_patterns():
    rows = [row for group in compiler.plane() for row in group][2:]
    legal = [v for v in product(range(2), repeat=9) if all(compiler.good(row, v) for row in rows)]
    by_phase = [[v for v in legal if v[0] == phase] for phase in (0, 1)]
    assert [len(v) for v in by_phase] == [6, 6]
    for phase, words in enumerate(by_phase):
        assert {w[:6] for w in words} == {(phase,)*3 + (1-phase,)*3}
        assert {w[6:] for w in words} == set(product(range(2), repeat=3)) - {(0,0,0),(1,1,1)}
        # A unary weight of zero kills any term with bit one at that point.
        # Setting only the first two private weights to zero forces the third bit to one.
        survivors = [w for w in words if w[6] == w[7] == 0]
        assert len(survivors) == 1 and survivors[0][6:] == (0, 0, 1)
    return by_phase


def expected_selections(m, arcs, present):
    cycles = set()
    for middle in permutations(range(1, m)):
        path = (0,) + middle + (0,)
        mask = sum(1 << arcs.index(arc) for arc in zip(path, path[1:]))
        if mask & present == mask:
            cycles.add(mask)
    return cycles


def experiment(m, present, charts):
    arcs, rows, _ = compiler.hc_verifier(m)
    rows += [(-(i + 2), 1, 1) for i in range(len(arcs)) if not (present >> i & 1)]
    groups, owners = compiler.compile_nae(rows, 3)
    compiler.audit_structure(groups, 9*len(owners))
    recovered, _ = compiler.normalized_quotient(groups)
    propagate = compiler.Propagation(recovered)
    arc_count = len(arcs)
    expected = expected_selections(m, arcs, present)
    models = [set(), set()]
    sizes = [0, 0]
    checked = 0
    for phase in (0, 1):
        for selection in range(1 << arc_count):
            literals = [1 if phase else -1]
            for i in range(arc_count):
                physical_bit = (selection >> i & 1) ^ phase
                literals.append(i+2 if physical_bit else -(i+2))
            logical = propagate.solve_with_inputs(literals)
            if logical is None:
                continue
            assert logical[1] == phase
            models[phase].add(selection)
            # Choose different private rows in consecutive blocks, then verify every triple.
            physical = [value for block, variable in enumerate(owners)
                        for value in charts[logical[variable]][block % 6]]
            assert all(compiler.good(triple, physical) for group in groups for triple in group)
            # The choices in distinct private rows only enter the ten local triples.
            sizes[phase] += 6 ** len(owners)
            checked += 1
    assert models[0] == models[1] == expected
    total = sum(sizes)
    factor = 2 * (6 ** len(owners))
    assert divmod(total, factor) == (len(expected), 0)
    return {"size": m, "arc_mask": present, "blocks": len(owners),
            "projected_solutions_per_phase": [len(set_) for set_ in models],
            "physical_witnesses_checked": checked, "total_count_bit_length": total.bit_length(),
            "integer_quotient": total // factor}


def main():
    charts = local_patterns()
    test3 = [experiment(3, present, charts) for present in range(64)]
    # No edges, one prescribed directed four-cycle, complete graph minus one arc, complete graph.
    arcs, _, _ = compiler.hc_verifier(4)
    full = (1 << len(arcs)) - 1
    ring = sum(1 << arcs.index((i, (i+1) % 4)) for i in range(4))
    test4 = [experiment(4, present, charts) for present in (0, ring, full-1, full)]
    hist = Counter(result["integer_quotient"] for result in test3)
    assert hist == {0: 49, 1: 14, 2: 1}
    assert [result["integer_quotient"] for result in test4] == [0, 1, 4, 6]
    return {"local_rows_exhausted": 512, "extensions_for_the_two_phases": list(map(len, charts)),
            "phase_extensions_after_two_zero_weights": [1, 1],
            "three_vertex_graphs": len(test3), "three_vertex_cycle_histogram": dict(sorted(hist.items())),
            "three_vertex_physical_witnesses_checked": sum(r["physical_witnesses_checked"] for r in test3),
            "four_vertex_cases": test4}


if __name__ == "__main__":
    print(json.dumps(main(), indent=2))
