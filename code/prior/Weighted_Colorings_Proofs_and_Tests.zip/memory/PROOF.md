# The sharp linear memory cost of a full-support coefficient

Let K be any field and z₁,...,zₙ be commuting formal markers. Write z_S for the product of variables indexed by S, and let Λ select the coefficient of z₁⋯zₙ. A prefix polynomial p is summarized by a K-linear map L into d stored field elements. The requirement is that Λ(pq) can be recovered from L(p) and q for every allowed continuation q. The recovery function can be nonlinear. The word “memory” below means dimension under this precise linear contract.

## Universal continuations

On square-free monomial spans the pairing is

    Λ(z_S z_([n] minus T)) = 1 if S=T, and 0 otherwise.

The exponent of a coordinate in this product is its prefix indicator plus its continuation indicator. All exponents can equal one only when T=S. Hence the pairing matrix is an identity matrix after ordering the column complements. If a nonzero p mapped to zero, testing against the complement of any monomial with nonzero coefficient in p would distinguish p and zero. It follows that d≥2ⁿ, with no restriction on the algorithm used after reading the summary. With homogeneous prefix degree k and degree-(n−k) continuations, the identical argument gives d≥binom(n,k).

Both bounds are sharp. Store the coefficient of every square-free monomial, or just all monomials of degree k at the stated layer. If multiplication is required as well, do it in the square-zero algebra K[z₁,...,zₙ]/(z₁²,...,zₙ²). A term with any repeated variable can never contribute to the requested monomial later. Square-free monomials form a basis and the product of two is zero when their supports overlap, otherwise their union monomial. Thus the algebra's dimension is exactly 2ⁿ.

More generally, for prefix and continuation subspaces P,Q the minimum possible d is the rank of the bilinear pairing B(p,q)=Λ(pq) restricted to P×Q. Necessity follows from ker(L) being contained in the left kernel of B. Sufficiency follows by storing coordinates in the quotient of P by that left kernel. If P and Q are spanned by specified subsets of the monomial basis, the restricted matrix is a partial permutation matrix, so its rank over every field is the number of complementary pairs in those subsets. This is the elementary linear continuation-rank principle related to the classical Hankel-rank characterization of linear representations of formal series (Carlyle–Paz and Fliess).

## The minimum relevant rank on a given directed graph

Root an n-vertex digraph at vertex 0, and fix 1≤k<n, for instance k=⌊n/2⌋. At each endpoint v≠0, let P_v be the span of departure-set monomials of all simple directed prefixes from 0 to v of k edges. A prefix includes the root and leaves v unconsumed. Let Q_v be the span of departure-set monomials of all simple suffixes from v to 0 of n−k edges. A suffix includes v and leaves the final root unconsumed.

The restricted rank equals the number of distinct prefix sets admitting a complementary suffix at that endpoint. A complementary pair yields a directed Hamiltonian cycle by concatenation: the two departure lists already contain each vertex exactly once between them and agree at the join. Conversely any directed Hamiltonian cycle provides such a prefix and suffix at its kth step. Thus the sum of the ranks over endpoints is nonzero exactly when the given digraph is Hamiltonian. Equivalently, this is the rank of a direct-sum pairing when the continuation is allowed to ask about an individual endpoint. Even deciding positivity of that rank for the middle layer is NP-complete, by the identity map from directed Hamiltonian cycle and the certificate consisting of a Hamiltonian cycle. This statement concerns existence, unlike a scalar count evaluated modulo the characteristic of a field: the pairing uses distinct basis vectors even when several actual paths have the same departure set.

The complete loopless digraph permits all k-element prefix sets containing the root and excluding v; their complements can all be continued. The rank per endpoint is binom(n−2,k−1), so the sum is (n−1)binom(n−2,k−1). In the two circulant families from the cycle-cover experiment, that sum is one on the positive family (a unique directed Hamiltonian cycle) and zero on the other family. On a 24-vertex positive instance 4,095 distinct prefix states appear at the middle layer, while exactly one state has a complementary suffix. A general method that can determine whether any compatible state survives from the raw graph is already deciding a classical NP-complete language.

## Reproduction and scope

Run python3 run.py and compare with RESULTS.json. The program constructs the unrestricted pairing entry by entry for n=1,4,8, checks its entries as integers, and recomputes the full and homogeneous-layer ranks over the binary field. A separate path enumeration builds forward and backward spaces from actual graph adjacency. It forms restricted binary pairing matrices explicitly and compares their ranks with complementary-set counts for eight circulant digraphs and four complete digraphs. The linear lower bounds refer to preserving the full-support coefficient of arbitrary formal prefixes against arbitrary allowed future products; a single subset has an n-bit encoding. The bounds make no time or memory claim for arbitrary Boolean decision algorithms, nonlinear compressed representations, or particular already-known inputs.

References: Richard Karp, “Reducibility Among Combinatorial Problems” (1972), https://www2.seas.gwu.edu/~simhaweb/champalg/tsp/papers/KarpOriginal.pdf ; Berstel and Reutenauer, *Noncommutative Rational Series with Applications* (2011), Theorem 1.6. The elementary pairing proof given above is self-contained. Priority for the specific graph comparison is unassessed.
