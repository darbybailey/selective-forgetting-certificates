"""Exact continuation memory for a square-free marker coefficient."""
from math import comb
import json


def coefficient_of_two_monomials(prefix, suffix, n):
    # Use the actual per-variable exponents: no implicit quotient relations.
    return int(all(((prefix >> j) & 1) + ((suffix >> j) & 1) == 1 for j in range(n)))


def binary_rank(rows):
    basis = {}
    for row in rows:
        while row:
            pivot = row.bit_length() - 1
            if pivot not in basis:
                basis[pivot] = row
                break
            row ^= basis[pivot]
    return len(basis)


def universal_checks(n):
    masks = list(range(1 << n))
    patterns = []
    tested = 0
    for a in masks:
        row = 0
        for idx, b in enumerate(masks):
            value = coefficient_of_two_monomials(a, b, n)
            assert value == int(b == (((1 << n) - 1) ^ a))
            row |= value << idx
            tested += 1
        patterns.append(row)
    dimension = binary_rank(patterns)
    layer_ranks = [binary_rank(patterns[s] for s in masks if s.bit_count() == k) for k in range(n+1)]
    assert dimension == 2**n and layer_ranks == [comb(n,k) for k in range(n+1)]
    return {"markers":n,"pairing_entries":tested,"linear_dimension":dimension,
            "homogeneous_layer_dimensions":layer_ranks}


def simple_path_layers(graph, steps):
    # State includes current vertex and all vertices encountered, including both endpoints.
    state = {(0, 1)}
    for _ in range(steps):
        choices = set()
        for tail, used in state:
            for head in graph[tail]:
                if not (used >> head) & 1:
                    choices.add((head, used | (1 << head)))
        state = choices
    return state


def middle_memory(graph):
    n = len(graph)
    k = n // 2
    all_points = (1 << n) - 1
    back = [tuple(i for i, row in enumerate(graph) if j in row) for j in range(n)]
    pre = [set() for _ in graph]
    post = [set() for _ in graph]
    for v, used in simple_path_layers(graph, k):
        pre[v].add(used ^ (1 << v))  # Departures on forward path, current v is unconsumed.
    for v, used in simple_path_layers(back, n-k):
        post[v].add(used ^ 1)  # Forward suffix departs v and finishes at root.
    ranks = []
    for v in range(1,n):
        possible = set(pre[v]) & {all_points ^ t for t in post[v]}
        suffixes = sorted(post[v])
        matrix = [sum(1 << j for j,t in enumerate(suffixes) if (s & t) == 0 and (s | t) == all_points)
                  for s in pre[v]]
        measured = binary_rank(matrix)
        assert measured == len(possible)
        ranks.append(measured)
    return {"vertices":n,"split_length":k,"forward_states":sum(map(len,pre)),
            "backward_states":sum(map(len,post)),"sum_of_endpoint_ranks":sum(ranks),
            "per_endpoint_ranks":ranks}


def main():
    universal=[universal_checks(n) for n in (1,4,8)]
    collisions=[]
    for n in (6,12,18,24):
        record=[]
        for a in (1,3):
            graph=[((i+a)%n,(i+a+1)%n) for i in range(n)]
            record.append(middle_memory(graph))
        assert [r['sum_of_endpoint_ranks'] for r in record] == [1,0]
        collisions.append(record)
    complete=[]
    for n in (4,6,8,10):
        graph=[tuple(j for j in range(n) if j!=i) for i in range(n)]
        seen=middle_memory(graph)
        assert seen['per_endpoint_ranks']==[comb(n-2,n//2-1)]*(n-1)
        complete.append(seen)
    return {"universal":universal,"circulant_collision_pairs":collisions,
            "complete_directed_graphs":complete}


if __name__=="__main__":
    print(json.dumps(main(),indent=2))
