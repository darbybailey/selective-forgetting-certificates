"""Replay the graph-only dense station reader and two exact boundary controls."""
import argparse
from collections import Counter, deque
import hashlib
import json
from pathlib import Path
import random


def split_stations(graph):
    """Components of the bipartite tail/head graph, derived from arcs alone."""
    size = len(graph)
    split = [[] for _ in range(2 * size)]
    for row, targets in enumerate(graph):
        for target in targets:
            split[row].append(size + target)
            split[size + target].append(row)
    seen = set()
    stations = []
    for start in range(2 * size):
        if start in seen:
            continue
        seen.add(start)
        stack = [start]
        rows, columns = [], []
        while stack:
            item = stack.pop()
            if item < size:
                rows.append(item)
            else:
                columns.append(item - size)
            for other in split[item]:
                if other not in seen:
                    seen.add(other)
                    stack.append(other)
        stations.append((sorted(rows), sorted(columns)))
    return stations


def locally_missing(graph, rows, columns):
    if not rows or len(rows) != len(columns):
        return None
    degrees = [len(graph[row]) for row in rows]
    column_degrees = Counter(target for row in rows for target in graph[row])
    degrees.extend(column_degrees[column] for column in columns)
    return len(rows) - min(degrees)


def find_cover(graph):
    """Ordinary augmenting paths in the bipartite adjacency graph."""
    row_at_column = {}
    successor = [None] * len(graph)
    neighbors = [sorted(targets) for targets in graph]
    for source in range(len(graph)):
        frontier = deque([source])
        parent = {}
        free_column = None
        while frontier and free_column is None:
            row = frontier.popleft()
            for column in neighbors[row]:
                if column in parent:
                    continue
                parent[column] = row
                if column not in row_at_column:
                    free_column = column
                    break
                frontier.append(row_at_column[column])
        if free_column is None:
            return None
        column = free_column
        while column is not None:
            row = parent[column]
            previous = successor[row]
            row_at_column[column] = row
            successor[row] = column
            column = previous
    return successor


def cycles(successor):
    assert sorted(successor) == list(range(len(successor)))
    labels = [-1] * len(successor)
    parts = []
    for start in range(len(successor)):
        if labels[start] != -1:
            continue
        here = start
        part = []
        while labels[here] == -1:
            labels[here] = len(parts)
            part.append(here)
            here = successor[here]
        assert here == start
        parts.append(part)
    return labels, parts


def check_cover(graph, successor):
    assert len(graph) == len(successor)
    assert sorted(successor) == list(range(len(graph)))
    assert all(target in graph[row] for row, target in enumerate(successor))


def merges(graph, stations, successor, labels):
    for rows, _columns in stations:
        for index, first in enumerate(rows):
            for second in rows[index + 1:]:
                if (labels[first] != labels[second]
                        and successor[second] in graph[first]
                        and successor[first] in graph[second]):
                    yield first, second


def read(graph):
    """Start from a matching derived from the input and take legal joining swaps."""
    successor = find_cover(graph)
    if successor is None:
        return None
    stations = split_stations(graph)
    initial = successor.copy()
    steps = []
    while True:
        labels, parts = cycles(successor)
        if len(parts) == 1:
            return initial, steps, parts[0]
        pair = next(merges(graph, stations, successor, labels), None)
        if pair is None:
            return initial, steps, None
        first, second = pair
        successor[first], successor[second] = successor[second], successor[first]
        steps.append(pair)


def check_trace(graph, result):
    """Independently replay the transitions and check each reported edge."""
    initial, steps, tour = result
    check_cover(graph, initial)
    state = initial.copy()
    initial_count = len(cycles(state)[1])
    for index, (first, second) in enumerate(steps):
        state[first], state[second] = state[second], state[first]
        check_cover(graph, state)
        assert len(cycles(state)[1]) == initial_count - index - 1
    if tour is not None:
        assert sorted(tour) == list(range(len(graph)))
        for pos, vertex in enumerate(tour):
            nxt = tour[(pos + 1) % len(tour)]
            assert nxt == state[vertex] and nxt in graph[vertex]
        assert len(steps) == initial_count - 1
    return initial_count


def exhaustive_permitted_covers(graph):
    """Enumerate legal permutations directly; independent of the swap reader."""
    partial = []
    occupied = set()

    def visit():
        if len(partial) == len(graph):
            yield partial.copy()
            return
        for nxt in sorted(graph[len(partial)] - occupied):
            partial.append(nxt)
            occupied.add(nxt)
            yield from visit()
            occupied.remove(nxt)
            partial.pop()
    yield from visit()


def edge_fingerprint(graph):
    edge_list = [(i, j) for i, row in enumerate(graph) for j in sorted(row)]
    encoded = json.dumps(edge_list, separators=(',', ':')).encode()
    return hashlib.sha256(encoded).hexdigest()


def dense_fixture(m, d, t, fixture_seed):
    """A connected balanced wire graph, with t forbidden entries per local list."""
    randomizer = random.Random(fixture_seed)
    incoming = [[] for _ in range(m)]
    outgoing = [[] for _ in range(m)]
    for station in range(m):
        for port in range(d):
            wire = station * d + port
            offset = 1 + port % (m - 1)
            outgoing[station].append(wire)
            incoming[(station + offset) % m].append(wire)
    graph = [set() for _ in range(m * d)]
    for station in range(m):
        rows = incoming[station]
        columns = outgoing[station]
        randomizer.shuffle(rows)
        randomizer.shuffle(columns)
        for index, row in enumerate(rows):
            forbidden = {columns[(index + shift) % d] for shift in range(t)}
            graph[row] = set(columns) - forbidden
    return graph


def relabel(graph, seed):
    perm = list(range(len(graph)))
    random.Random(seed).shuffle(perm)
    result = [set() for _ in graph]
    for row, targets in enumerate(graph):
        result[perm[row]] = {perm[j] for j in targets}
    return result


def dense_tests():
    records = []
    for m, d, t in [(3, 5, 1), (5, 9, 2), (6, 13, 3), (7, 17, 4)]:
        for fixture_seed in (51, 771):
            base = dense_fixture(m, d, t, fixture_seed)
            for shuffle_seed in range(7):
                graph = relabel(base, shuffle_seed)
                stations = split_stations(graph)
                assert len(stations) == m
                for rows, columns in stations:
                    assert len(rows) == d and locally_missing(graph, rows, columns) == t
                result = read(graph)
                assert result is not None and result[2] is not None
                initial_count = check_trace(graph, result)
                records.append(dict(stations=m, ports=d, missing=t, vertices=len(graph),
                                    fixture_seed=fixture_seed, label_seed=shuffle_seed,
                                    graph_sha256=edge_fingerprint(graph),
                                    initial_cycles=initial_count, joining_swaps=len(result[1]),
                                    tour=result[2]))
    return records


def boundary_four():
    # Alternate between A={0..3} and B={4..7}. Each local table is K4,4
    # minus one permutation. Its omissions obstruct every cross-cycle swap.
    within = [1, 0, 3, 2]
    blocked_partner = [2, 3, 1, 0]
    initial = [4 + i for i in range(4)] + within
    graph = [set(range(4, 8)) - {4 + blocked_partner[i]} for i in range(4)]
    graph += [set(range(4)) - {within[blocked_partner[i]]} for i in range(4)]
    stations = split_stations(graph)
    assert len(stations) == 2
    assert all(len(rows) == 4 and locally_missing(graph, rows, cols) == 1
               for rows, cols in stations)
    check_cover(graph, initial)
    labels, parts = cycles(initial)
    assert len(parts) == 2 and not list(merges(graph, stations, initial, labels))
    histogram = Counter()
    witness = None
    for cover in exhaustive_permitted_covers(graph):
        components = cycles(cover)[1]
        histogram[len(components)] += 1
        if len(components) == 1 and witness is None:
            witness = components[0]
    assert witness is not None
    assert all(witness[(i + 1) % len(witness)] in graph[v] for i, v in enumerate(witness))
    return dict(adjacency=[sorted(row) for row in graph], blocked_start=initial,
                starting_cycles=parts, legal_joining_swaps=0,
                cover_histogram={str(k): v for k, v in sorted(histogram.items())},
                hamiltonian_witness=witness)


def cubic_control():
    darts = [(tail, head) for tail in range(4) for head in range(4) if tail != head]
    graph = [{j for j, (start, end) in enumerate(darts) if start == head and end != tail}
             for tail, head in darts]
    stations = split_stations(graph)
    assert len(stations) == 4
    assert all(len(rows) == 3 and locally_missing(graph, rows, cols) == 1
               for rows, cols in stations)
    histogram = Counter()
    for cover in exhaustive_permitted_covers(graph):
        number = len(cycles(cover)[1])
        histogram[number] += 1
        assert (len(graph) - number) % 2 == 0
    assert sum(histogram.values()) == 16 and histogram[1] == 0
    return dict(darts=darts, vertices=len(graph), allowed_arcs=sum(map(len, graph)),
                allowed_covers=sum(histogram.values()), hamiltonian_covers=0,
                cover_histogram={str(k): v for k, v in sorted(histogram.items())})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--write', action='store_true', help='regenerate the recorded JSON')
    args = parser.parse_args()
    records = dense_tests()
    results = dict(dense=dict(instances=len(records),
                              verified_hamiltonian_tours=len(records),
                              total_joining_swaps=sum(r['joining_swaps'] for r in records),
                              cases=records),
                   boundary_d4=boundary_four(), cubic_d3=cubic_control())
    output = Path(__file__).with_name('RESULTS.json')
    encoded = json.dumps(results, indent=2) + '\n'
    if args.write:
        output.write_text(encoded)
    else:
        assert output.read_text() == encoded, 'recorded output mismatch'
    print(f"{len(records)} dense tours, {results['dense']['total_joining_swaps']} joining swaps")
    print(f"Boundary cover counts by cycle count: {results['boundary_d4']['cover_histogram']}")
    print(f"Cubic cover counts by cycle count: {results['cubic_d3']['cover_histogram']}")


if __name__ == '__main__':
    main()
