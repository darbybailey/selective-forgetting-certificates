# Joining cycle covers by switching two successors

A cycle cover of a directed graph chooses one outgoing arc and one incoming arc at every vertex. It is a permutation of the vertices. A Hamiltonian cycle is a cycle cover with one cycle. This note identifies a condition under which every starting cover can reach a Hamiltonian cycle through switches that each join two cycles.

## A graph-only reader

Given a nonempty directed graph on N vertices, make two copies of each vertex. Draw an undirected edge from the left copy of u to the right copy of v for each allowed arc from u to v. Call each connected component of this bipartite graph a station. They are determined from the input. A station is balanced when it has d left and d right vertices. Let t be the maximum number of missing entries in any row or column of its d by d adjacency table. Values of d and t may differ by station.

A vertex v of the original graph is a directed wire from the station containing its right copy to the station containing its left copy. The resulting station multigraph may have loops or parallel wires. Its transitions are the arcs of the original graph. Assume its undirected underlying graph is connected.

**Pair-switch guarantee.** If each station is balanced and satisfies d > 4t, every cycle cover can be joined into a Hamiltonian cycle by exactly c − 1 switches, where c is its initial number of cycles. A deterministic algorithm finds an initial cover and all the switches in polynomial time.

Each table has minimum degree d − t > d/2. For a nonempty set of at most d/2 rows, one row alone has enough neighbors to satisfy Hall's inequality. A set of more than d/2 rows touches every column by the column degree bound. Thus every table has a perfect matching. Taking their union yields a cover, which the reader finds by ordinary bipartite augmenting paths.

Fix such a cover and a station. Two matched entries can exchange their two assigned columns when both cross entries are allowed. Form the undirected graph of these exchanges on the d matched entries. At a given entry, at most t partners are ruled out by the first cross entry and at most t by the other. Its exchange degree is at least d − 1 − 2t, hence at least floor(d/2) when d > 4t. This graph is connected, since two separate components would each have at least floor(d/2) + 1 vertices.

If the cover has more than one cycle, some station is visited by multiple cycles. Otherwise each station belongs to a single cycle and the wire connecting any two stations forces them to belong to the same cycle, contrary to connectivity. At a station visited by multiple cycles, label each matched entry by its cycle. A connected exchange graph has an edge joining different labels. Switching the successors on that edge joins these cycles and leaves all others intact. Repeat until one cycle remains. The initial matching takes O(N |E|) operations using augmenting paths. The pair scans over at most N rounds take O(N³) with an adjacency table. The list of exchanges and the resulting Hamiltonian cycle are directly checkable.

## Exact boundary controls

**A blocked cover at d = 4, t = 1.** Take eight vertices with the following outgoing neighborhoods.

| Vertex | Neighbors |
|---|---|
| 0 | 4, 5, 7 |
| 1 | 4, 5, 6 |
| 2 | 4, 6, 7 |
| 3 | 5, 6, 7 |
| 4 | 0, 1, 2 |
| 5 | 0, 1, 3 |
| 6 | 1, 2, 3 |
| 7 | 0, 2, 3 |

The balanced stations are the two directed interfaces between the sets {0,1,2,3} and {4,5,6,7}. Each is missing exactly one entry in every row and column. The cover (0 4 1 5)(2 6 3 7) has no legal joining exchange. For example at the first station, exchanging 0 or 1 with 2 or 3 would require one of the omitted arcs 0→6, 3→4, 2→5, 1→7, respectively for pairs (0,2), (0,3), (1,2), (1,3). At the other station the same four cases fail after relabeling. Yet (0 4 2 6 1 5 3 7) is a Hamiltonian cycle. Exhaustion finds 12 one-cycle, 36 two-cycle, 24 three-cycle, and 9 four-cycle covers. This establishes failure of strictly cycle-joining pair switches from that starting cover at equality.

**A graph with no tour at d = 3, t = 1.** Bidirect the six edges of the complete graph on four vertices. The 12 directed edges are the vertices of the input digraph. An allowed transition continues at the endpoint and may take either outgoing edge that avoids immediate reversal. At each of the four stations a cover pairs three incoming edges with three outgoing edges by a derangement of neighbor labels, which is a 3-cycle and therefore even. The global cover permutation first reverses the directed edge, then applies the station permutations to outgoing edges. Reversal is a product of six disjoint transpositions, also even. Every cover has even sign, whereas a 12-cycle is odd. Direct enumeration finds 14 covers with two cycles and two covers with four. This 12-vertex digraph is Isaak's P(4,2).

## Existing results and scope

Garth Isaak gives a stronger existence guarantee for compatible Euler tours when every incoming edge has at most (d − 2)/2 forbidden continuations and every outgoing edge is forbidden after at most (d − 2)/2 incoming edges. His method starts with an unrestricted Euler tour, cuts the tour at visits to one station, and reorders all segments there. It covers d = 4, t = 1, including the blocked example. The pair-switch argument here addresses the narrower requirement of monotonically joining from an arbitrary compatible cover using two successors at a time. No priority claim is made. Isaak also proves non-Hamiltonicity of P(n,n−2) for n ≥ 4. [Isaak, European Journal of Combinatorics 27 (2006), 801–805, §2 and Corollary 1](https://www.lehigh.edu/~gi02/PNK.pdf)

Carraher and Hartke give polynomial-time algorithms for several special cases with three incoming and three outgoing edges at every station and one forbidden mate per edge. Guo, Li, Xu and Zhang give more general sufficient conditions for compatible Euler tours. [Carraher and Hartke (2017)](https://doi.org/10.1137/140992850) · [Guo et al. (2018)](https://doi.org/10.1016/j.disc.2018.04.014)

## Reproduction

Run `python3 run.py` beside `RESULTS.json`. No external dependencies are required. The run regenerates every test and compares its output with the recorded JSON. Each of four parameter settings (d,t) = (5,1), (9,2), (13,3), (17,4) has two underlying graphs and seven seeded relabelings per graph. Input sizes are 15, 45, 78 and 119 vertices. Only the adjacency list enters the reader. All 56 returned tours pass verification, and the 199 joining exchanges are independently replayed. The two boundary controls exhaust all permitted permutations using a separate enumerator. These finite checks exercise the implementation. The guarantee for arbitrary sizes in the stated family follows from the proof above.
