# Which information does a weighted cycle cover retain?

## Two covers and a missing Hamiltonian bit

Fix n divisible by six, n ≥ 6. On vertices 0,...,n−1 with indices modulo n, let D_a have two options at each tail i: an arc of weight x_i to i+a and an arc of weight y_i to i+a+1. Use a=1 for the positive graph and a=3 for the negative graph. Both are loopless and two-regular in each direction. They are strongly connected: the additive generators a and a+1 generate the cyclic group, and in a finite group each inverse is a nonnegative power.

A directed cycle cover chooses exactly one option at each tail and covers every head exactly once. Choosing y_i prevents the next tail from choosing x_(i+1), since both reach i+a+1. Therefore the only two covers use either every x or every y. Let X=∏_i x_i and Y=∏_i y_i. A uniform shift by s has gcd(n,s) directed cycles and sign (−1)^(n−gcd(n,s)). In the positive graph the two cycle counts are 1 and 2. In the negative graph they are 3 and gcd(n,4), which is at least 2 and even. Consequently the complete weighted identities in every field are

    per(D_1) = per(D_3) = X+Y,
    det(D_1) = det(D_3) = −X+Y,
    HC(D_1) = X,               HC(D_3) = 0.

In these identities D denotes its independently weighted adjacency matrix; the determinant's two signs coincide in characteristic two. All input arc weights in the two polynomial identities are identified by tail and local option. They are not identified by a simultaneous isomorphism of the vertices. The two graphs differ in the assignment of outgoing ports to heads. A procedure that sees this assignment can read cycle structure directly. In particular on these examples a cycle traversal costs linear time.

## Seven exclusion tags

Use seven slots and put D_1 only at a hidden live tag j, with D_3 at the other six. A safe nonempty exclusion in this singleton situation is any tag different from j. Even the complete signed cover list in the common tail/option coordinates is independent of j, hence so are arbitrary adaptive evaluations, common weightings, edge zeroings or isolations computed solely from that observation and independent randomness. Across the seven equally likely choices of j a deterministic output fails once. For a randomized procedure choosing tag i with probability p_i, some live j has p_j≥1/7, so the worst-case chance of a safe exclusion is at most 6/7. This is an information bound for the declared observation channel. A rule with access to the original adjacency matrix can and does beat this bound on the same family. The test presently concerns directed-Hamiltonian source slots; no graph-only SAT compiler timing or loss of original adjacency information is claimed.

## A unique minimum can still be a disconnected cover

In a directed cycle of t ≥ 2 three-vertex blocks A_i→B_i→C_i→A_(i+1), add A_i→A_(i+1) and C_i→B_i. The original Hamiltonian ring proves strong connectivity. The maximum indegree and outdegree are two, and the graph has no loops. Every cover must use B_i→C_i. The other two tails in block i must then bijectively cover heads B_i and A_(i+1). They have two local options. The straight choice visits all three block vertices in the main cycle; the crossed choice creates an extra B_i,C_i cycle. The options are independent. Thus there are 2^t covers, of which exactly one is Hamiltonian.

For an exact finite weight experiment, independently assign a random permutation of costs 1,2,4,8 to the four variable arcs of each block. Give forced arcs any fixed costs. The two pair sums always differ, so a unique global minimum cover exists for every draw. Twelve of the 24 permutations favor the straight option and twelve favor the crossed option. The probability that the unique minimum is Hamiltonian is exactly 2^(−t). The same probability holds for independent, identically distributed continuous arc costs. This calculation concerns minimizing over all cycle covers. Isolating the family of Hamiltonian cycles directly is a different objective; evaluating the minimum of that family is already hard. The result does not rule out input-aware weights or other methods. For context on isolating perfect matchings, see Mulmuley, Vazirani and Vazirani, https://doi.org/10.1145/28395.383347.

## A lossless coefficient and its cost

For any finite weighted directed graph with adjacency matrix A put Z=diag(z_0,...,z_(n−1)). Over any field, formal series give (I−ZA)^(-1)=∑_(k≥0)(ZA)^k. The (0,0) entry enumerates rooted closed walks, with a vertex marker for each departure. Its coefficient of z_0⋯z_(n−1) is exactly HC_D. Such a walk has length n, uses each vertex once, and counts each directed Hamiltonian cycle once from its prescribed root. The denominator of this rational function is det(I−ZA), with constant term one. The numerator is the determinant of its principal minor obtained by deleting the root. This explains how a compact rational expression retains the answer while the difficult computation is extracting its exact full-support coefficient.

Over the nonnegative integers with unit arc weights the coefficient is positive exactly when the graph is Hamiltonian. Over a finite field, specializations can cancel distinct cycles, whereas an indeterminate for each arc keeps their monomials distinct. One exact extraction is the alternating sum over the 2^(n−1) induced vertex sets S containing the root of (−1)^(n−|S|) times (A[S]^n)_(0,0). It removes every walk missing a vertex. The identity supplies a check and an exponential algorithm. Counting directed Hamiltonian cycles in this manner is a classical inclusion-exclusion technique; see https://conferences.mpi-inf.mpg.de/adfocs13/material/lukasz/ie.pdf.

## Replay

Run `python3 run.py` and compare its JSON with RESULTS.json. It tests every binary outgoing option pattern on each of the 6-, 12- and 18-vertex paired examples, performs 96 specialized determinant/permanent comparisons over four finite fields, tests 12 independent rooted-walk coefficient extractions, and checks all seven singleton worlds. For the isolation construction it independently enumerates all actual covers and all 24 local weight orderings on 2,4,6 blocks. The analytic arguments give the infinite families. Bibliographic novelty of these explicit examples has not been assessed.
