"""Weighted directed cycle-cover observations and the missing Hamiltonian bit."""
from collections import Counter
from itertools import permutations, product
import json
from math import gcd
from random import Random


def heads(n, a):
    return [((i + a) % n, (i + a + 1) % n) for i in range(n)]


def components(perm):
    visited = set()
    lengths = []
    for i in range(len(perm)):
        if i in visited:
            continue
        k = 0
        while i not in visited:
            visited.add(i)
            k += 1
            i = perm[i]
        lengths.append(k)
    return tuple(sorted(lengths))


def reachable(graph):
    todo = [0]
    seen = {0}
    for v in todo:
        for w in graph[v]:
            if w not in seen:
                todo.append(w)
                seen.add(w)
    return len(seen) == len(graph)


def enumerate_covers(graph):
    """Actual directed cycle covers from every binary edge choice on all rows."""
    n = len(graph)
    covers = []
    for options in product((0, 1), repeat=n):
        target = tuple(graph[i][b] for i, b in enumerate(options))
        if len(set(target)) != n:
            continue
        lengths = components(target)
        covers.append((options, (-1) ** (n - len(lengths)), lengths))
    return covers


def monomial(options, weights):
    w = 1
    for i, option in enumerate(options):
        w *= weights[i][option]
    return w


def count_rooted_full_support(graph, weights):
    """Extract the square-free degree-n coefficient by root-anchored inclusion/exclusion."""
    n = len(graph)
    total = 0
    for choice in range(1 << (n - 1)):
        active = 2 * choice + 1
        dp = [1] + [0] * (n - 1)
        for _ in range(n):
            new = [0] * n
            for u, count in enumerate(dp):
                if not count:
                    continue
                for option, v in enumerate(graph[u]):
                    if active >> v & 1:
                        new[v] += count * weights[u][option]
            dp = new
        total += (-1) ** (n - active.bit_count()) * dp[0]
    return total


def rooted_simple_cycles(graph):
    """Canonical starting vertex removes cyclic overcounting."""
    n = len(graph)
    def dfs(cur, seen):
        if len(seen) == n:
            return int(0 in graph[cur])
        return sum(dfs(w, seen | {w}) for w in graph[cur] if w not in seen)
    return dfs(0, {0})


def isolation_control(t):
    graph = []
    for i in range(t):
        a, b, c = 3*i, 3*i+1, 3*i+2
        d = 3*((i+1) % t)
        graph.extend([(b, d), (c,), (d, b)])
    assert reachable(graph)
    reverse = [tuple(i for i, row in enumerate(graph) if j in row) for j in range(3*t)]
    assert reachable(reverse)
    histogram = Counter()
    for perm in product(*graph):
        if len(set(perm)) == len(graph):
            histogram[len(components(perm))] += 1
    assert sum(histogram.values()) == 2**t and histogram[1] == 1
    local = [a+b < c+d for a,b,c,d in permutations((1,2,4,8))]
    assert sum(local) == 12 and len(local) == 24
    return {"blocks":t, "vertices":3*t, "cover_count":2**t, "hamiltonian_count":histogram[1],
            "independent_local_orderings":24**t, "orderings_with_hamiltonian_minimum":12**t,
            "hamiltonian_minimum_probability":"1/"+str(2**t),
            "cycle_count_histogram":dict(sorted(histogram.items()))}


def test():
    rng = Random(82291)
    finite = []
    base_signature = None
    numerics = 0
    coeffs = 0
    for n in (6, 12, 18):
        pair = {}
        for a, key in [(1, 'yes'), (3, 'no')]:
            graph = heads(n, a)
            incoming = Counter(w for neighbors in graph for w in neighbors)
            transpose = [[u for u, neighbors in enumerate(graph) if v in neighbors] for v in range(n)]
            assert len(incoming) == n and set(incoming.values()) == {2}
            assert all(i not in neighbors and len(set(neighbors)) == 2 for i, neighbors in enumerate(graph))
            assert reachable(graph) and reachable(transpose)
            covers = enumerate_covers(graph)
            hcount = rooted_simple_cycles(graph)
            assert hcount == sum(len(z[2]) == 1 for z in covers)
            assert len(covers) == 2
            assert all(len(c[2]) == gcd(n, a + c[0][0]) for c in covers)
            pair[key] = (graph, covers, hcount)
        yes, no = pair['yes'], pair['no']
        sy, sn = tuple((q, t) for q,t,_ in yes[1]), tuple((q, t) for q,t,_ in no[1])
        assert sy == sn == (((0,)*n,-1), ((1,)*n,1))
        assert (yes[2], no[2]) == (1,0)
        for trial in range(8):
            weights = tuple(tuple(rng.randrange(-3, 5) for _ in range(2)) for _ in range(n))
            for modulus in (2, 3, 5, 101):
                evals = []
                for _, covers, _ in (yes, no):
                    terms = [(sign, monomial(options, weights)) for options,sign,_ in covers]
                    evals.append((sum(v for _,v in terms)%modulus,sum(s*v for s,v in terms)%modulus))
                assert evals[0] == evals[1]
                numerics += 1
            if n <= 12 and trial < 3:
                for graph, covers, _ in (yes, no):
                    expected = sum(monomial(options,weights) for options,_,lengths in covers if len(lengths) == 1)
                    assert count_rooted_full_support(graph, weights) == expected
                    coeffs += 1
        finite.append({"vertices":n,"arcs_per_graph":2*n,"assignments_per_cover_enumeration":2**n,
                       "yes_cycle_lengths":[list(r[2]) for r in yes[1]],"no_cycle_lengths":[list(r[2]) for r in no[1]],
                       "rooted_hamiltonian_cycles":[yes[2],no[2]]})
        if n == 6:
            base_signature = (yes[1],no[1])

    # Worlds have an independent branch at every tag. Exactly the hidden tag is YES.
    # Fixed observations give even the full signed list of option-string covers.
    def observe(covers):
        return tuple((q,sign) for q,sign,_ in covers)
    transcripts = []
    fail = Counter()
    for live in range(1,8):
        sources = [base_signature[0] if j == live else base_signature[1] for j in range(1,8)]
        assert [j+1 for j,s in enumerate(sources) if any(len(z[2])==1 for z in s)] == [live]
        transcript = tuple(observe(s) for s in sources)
        transcripts.append(transcript)
        for exclusion in range(1,8):
            fail[exclusion] += int(exclusion == live)
    assert len(set(transcripts)) == 1 and all(fail[j] == 1 for j in range(1,8))
    return {"isolation_control":[isolation_control(t) for t in (2,4,6)],"instances":finite,"weighted_permanent_and_determinant_checks":numerics,
            "independent_full_support_coefficient_checks":coeffs,"singleton_worlds":7,
            "distinct_seven_tag_cover_transcripts":len(set(transcripts)),
            "worlds_failing_for_each_fixed_exclusion":[fail[i] for i in range(1,8)],
            "uniform_hidden_tag_success":"6/7"}


if __name__ == "__main__":
    print(json.dumps(test(), indent=2))
