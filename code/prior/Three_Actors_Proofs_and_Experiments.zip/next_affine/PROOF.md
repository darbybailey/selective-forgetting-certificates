# Linear and affine maps that never increase the number of defects

Write D_H(x) for the number of monochromatic triples. A four-matching system on n points is linear (no repeated point pair), has M=4n/3 triples, and has an 8-regular point-pair graph E_H. Write χ_u(x)=(-1) raised to the binary inner product of u and x. Adding the three pair characters within each triple gives

    4 D_H(x) = M + sum over pairs ij in E_H of χ_(e_i+e_j)(x).

## All homogeneous linear maps on equal connected sources

For T(x)=Lx, each target triple is monochromatic when two homogeneous binary linear equations hold. Their rank is at most two, so a uniformly random x makes the triple monochromatic with probability at least 1/4. For equal-order A,B, the expected value of D_A is M/4. If D_B(Lx) ≤ D_A(x) for EVERY assignment then the expectations must coincide and equality holds pointwise. In the character identity every summand has positive coefficient. Uniqueness of the character expansion forces the transpose of L to carry the distinct B edge vectors bijectively to the A edge vectors. Conversely such a map gives equality. If the graphs are connected, both edge spans have dimension n−1. The induced map on them is a linear isomorphism and can be extended to an invertible transformation of the full n-dimensional space. Preserving edge-vector dependencies amounts to isomorphism of the binary cycle matroids, as proved in next_nofold/PROOF.md. Thus permitting rank loss in a homogeneous map gives no extra instances of pointwise defect domination in this equal-order connected class. The same argument holds for equal component counts.

For an affine map T with output i equal to the inner product of row r_i with x plus offset b_i, the exact expectation is

    4 E[D_B(Tx)] = M + sum over ij in E_B with r_i=r_j of (−1)^(b_i+b_j).

Strict pointwise improvement at even one assignment, together with weak domination everywhere, requires strictly more collapsed edges of permanently opposite colors than collapsed edges of identical colors. For affine bijections no edge collapses. Pointwise domination then implies exact equality; the offset must make all triples monochromatic at x=0 and hence be constant per target component.

## Allowing both translation and rank loss

Suppose A is supplied with a perfect coloring and B is an arbitrary four-matching input of the same order n≥2. Existence of an affine map of rank one satisfying D_B(Tx) ≤ D_A(x) for every x is equivalent to bicolorability of B. A witness w of B gives T(x)=w+x_1·1, whose two images both satisfy B. Conversely evaluate the map at the supplied witness of A. This gives NP-completeness on this contract by four-matching bicolorability; the known-positive A can always be constructed at large n as below, with the bounded small sizes immaterial.

A substantially higher-rank version uses B from the closed-ring four-matching reduction in the previous archive (one_defect_hard.py). It has n=324m, where m is the number of clauses of the input 3-SAT instance. Every nine-point piece has six external ports indicating the phase; in a global solution each of its three private bits may vary provided their three-bit word is nonconstant. Keeping the phases from a solution, choose the private bits of each piece as (u_j,1+u_j,v_j) with independent parameters. Additionally toggle the phases on all pieces together with one global bit. Every sensitive NAE triple remains true under this global complementation. Every internal triple still either uses opposite plane rows or belongs to the private row, which is nonconstant. These patterns form an affine subspace of perfect colorings of rank r=2n/9+1. Mapping r independent input bits to those parameters produces a rank-r affine map with identically zero target defect. If the source 3-SAT input is unsatisfiable, no map can be sound since A is known satisfiable.

For A use n=3q and four partitions (a_i,b_(i+s),c_(i+2s)), i modulo q, s=0,1,2,3. For q≥7 these are linear and a publicly known coloring sets the a and c parts to zero and the b part to one. The input map is polynomial, and the target is bicolorable exactly on YES inputs. Thus rank-at-least-r affine domination is NP-hard, and on these specific generated instances the promise decision problem is NP-complete, with a satisfying coloring of B as the NP witness. This does not establish NP membership for general inputs subject only to a high-rank bound.

For any fixed δ in (0,1), append identically labeled, disjoint copies of this positive A to both sides. On the padding use the identity. Choose N, the new total size, a polynomially bounded multiple of n such that N^δ≥n, for instance N=n^(ceil(1/δ)). Then N−rank ≤ n−r ≤ N^δ. All four matchings extend by disjoint union, and on NO inputs the padded B is unsatisfiable. Hardness therefore persists for rank at least N−N^δ on this padded promise. The padding is disconnected. No constant-corank hardness or connected, near-full-rank extension is asserted.

The script checks every output triple on an entire affine subspace symbolically by testing the consistency of its two affine monochromaticity equations. The 324- and 972-point examples certify dimensions 73 and 217. Another 512 exhaustive small maps check the affine expectation formula. The algebra does not yield a method for finding the shift from an arbitrary target.

References: https://arxiv.org/abs/2412.03395 (four-matching bicolorability); https://www.cse.iitm.ac.in/~bvrr/jour/RS1.pdf (bounded-degree graphic matroids, Corollary 6.3). Priority for the combined statements has not been assessed.
