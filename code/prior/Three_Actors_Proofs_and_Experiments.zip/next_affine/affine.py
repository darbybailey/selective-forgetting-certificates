"""Certify entire affine subspaces of valid bicolorings using symbolic affine forms."""
from itertools import product
from pathlib import Path
import json
import sys

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"frontier2_near"))
from one_defect_hard import audit_structure, chain_gate, compile_nae, extend_gate


def rank(vectors):
    basis={}
    for word in vectors:
        while word:
            pivot=word.bit_length()-1
            if pivot not in basis:
                basis[pivot]=word
                break
            word ^= basis[pivot]
    return len(basis)


def can_be_monochromatic(forms):
    # Turning a triple monochromatic requires both induced affine equations to hold.
    (r,b),(s,c),(t,d)=forms
    pairs=[(r^s,b^c),(r^t,b^d)]
    return not (any(v==0 and q for v,q in pairs) or (pairs[0][0]==pairs[1][0] and pairs[0][1]!=pairs[1][1]))


def tripartite(n):
    assert n%3==0 and n//3>=7
    side=n//3
    return [[(i,side+(i+j)%side,2*side+(i+2*j)%side) for i in range(side)] for j in range(4)]


def sample(cnf,witness):
    signed,s,f,chain=chain_gate(cnf,len(cnf))
    bits=extend_gate(cnf,witness,False)
    assert bits is not None
    bits.update({v:1 for v in chain})
    rows,owners=compile_nae(signed,3)
    n=9*len(owners)
    audit_structure(rows,n)
    a=tripartite(n)
    audit_structure(a,n)
    assert all(len({v//(n//3)==0 for v in e})==2 for group in a for e in group)
    forms=[]
    global_bit=1
    for j,owner in enumerate(owners):
        phase=bits[owner]
        u,v=1<<(2*j+1),1<<(2*j+2)
        forms.extend([(global_bit,phase)]*3+[(global_bit,1^phase)]*3+[(u,0),(u,1),(v,0)])
    r=rank(row for row,b in forms)
    assert r==2*len(owners)+1
    assert all(not can_be_monochromatic([forms[v] for v in e]) for group in rows for e in group)
    return {"variables":n,"charts":len(owners),"affine_rank":r,
            "triples_universally_satisfied":sum(map(len,rows)),"input_A_given_coloring_valid":True}


def mean_identity():
    cases=0
    for row in product(range(4),repeat=3):
        for bias in product((0,1),repeat=3):
            true_mean=sum(len({((r&x).bit_count()%2)^b for r,b in zip(row,bias)})==1 for x in range(4))/4
            exp=(1+sum((-1)**(bias[i]^bias[j]) for i,j in ((0,1),(1,2),(0,2)) if row[i]==row[j]))/4
            assert true_mean==exp
            assert can_be_monochromatic(list(zip(row,bias)))==(exp>0)
            cases+=1
    return cases


if __name__=="__main__":
    results=[sample([(1,1,1)],{1:1}),sample([(1,-2,3),(-1,2,3),(1,2,-3)],{1:1,2:1,3:1})]
    print(json.dumps({"flats":results,"three_bit_affine_mean_checks":mean_identity()},indent=2))
