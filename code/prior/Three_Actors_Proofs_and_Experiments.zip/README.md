# A distinction visible only to three actors

The PDF and Markdown working paper describe three-branch inference, exact proofs and controls, and the remaining general problem. The archive is self-contained. No outside solver is used for these tests.

From an extracted copy, using Python 3.10 or newer:

    python3 verify.py --full

The default runs 14 checks. The full run executes all 18, including four additional compiled-graph checks. For two parallel test processes use --jobs 2. RELEASE_CHECKS.json records the detached full replay and file hashes. Source families are deliberately constructed to test precise hypotheses. The numerical benchmarks do not justify a worst-case SAT bound.

| Folder | Proofs and experiments |
|---|---|
| next_ternary | Witness gluing, connected graph inputs, all pairwise projections, Horn closure characterization, negative controls. |
| next_boundary | Strict boundary inclusion, arbitrary conditional SAT inputs, three-pin alternative, exact search and a 330,799-vertex graph. |
| next_nofold | Changing coordinates on a two-terminal separation, the pair-character formula, cycle matroids, counterexamples, and repeated twists. |
| next_flat | Sharp 5V/12 bound on the dimension of a satisfying affine space, connected equality examples, and the near-maximum decision reduction. |
| next_affine | Separating homogeneous linear comparison from singular affine domination, a rank lower bound for hardness, and symbolic witnesses for entire affine subspaces. |
| next_blind | Sharp linear-radius limitation, first distinguishing closed-walk count, and equal stable color refinements on eight compiler graphs. |
| next_weak | Error-tolerant exclusion criteria, finite histograms and controlled pruning trials. |
| next_priority | Maximum size of a list of prefixes for which no certified implication is known. An arbitrary hard core can persist after many safe deletions. |

The remaining folders hold support code from the preceding package. Each new experiment folder includes its detailed mathematical note and recorded numerical outputs. Finite code checks are distinct from the general reductions. The general actor is open.
