"""Gauge-equivalent rooted balls and opposite bicolorability on a four-matching cycle."""
from collections import Counter
from itertools import combinations, product
import json


def ring(signs):
    k=len(signs)
    assert k>=3
    groups=[[] for _ in range(4)]
    for i,s in enumerate(signs):
        off=9*i
        follow=9*((i+1)%k)
        for slope in range(3):
            for intercept in range(3):
                groups[slope].append(tuple(off+3*x+(slope*x+intercept)%3 for x in range(3)))
        groups[3].append((off+6,off+7,off+8))
        for x in (0,1):
            groups[3].append((off+3*x,off+3*x+1,follow+3*(x^1^s)+2))
    return groups


def shadow(groups):
    vertices=sum(len(e) for e in groups[0])
    adj=[set() for _ in range(vertices)]
    for G in groups:
        assert sorted(v for e in G for v in e)==list(range(vertices))
        for row in G:
            for a,b in combinations(row,2):
                assert b not in adj[a]
                adj[a].add(b);adj[b].add(a)
    return adj


def ball(adj,root,radius):
    seen={root}; shell={root}
    for _ in range(radius):
        shell={v for u in shell for v in adj[u]}-seen
        seen.update(shell)
    return seen


def chart_flip(v):
    sheet,p=divmod(v,9)
    x,y=divmod(p,3)
    return 9*sheet+3*((1-x)%3)+(1-y)%3


def lifted_ball_map(adj,signs,toggles,root,radius):
    k=len(signs);center=root//9
    lifted={root};front={root}
    for _ in range(radius):
        outer=set()
        for v in front:
            layer=v//9
            for w in adj[v%(9*k)]:
                move=(w//9-layer)%k
                assert move in (0,1,k-1)
                offset=-1 if move==k-1 else move
                outer.add(9*(layer+offset)+w%9)
        front=outer-lifted
        lifted.update(front)
    phases={center:0}
    for b in range(center+1,1+max(v//9 for v in lifted)):
        phases[b]=phases[b-1]^signs[(b-1)%k]^toggles[(b-1)%k]
    for b in range(center-1,min(v//9 for v in lifted)-1,-1):
        phases[b]=phases[b+1]^signs[b%k]^toggles[b%k]
    answer={v%(9*k):(chart_flip(v) if phases[v//9] else v)%(9*k) for v in lifted}
    assert len(answer)==len(lifted)==len(set(answer.values()))
    return answer


def model_count_by_transfer(groups):
    size=sum(map(len,groups[0]));k=size//9
    intern=[[e for G in groups for e in G if all(i//9==b for i in e)] for b in range(k)]
    bands=[[e for e in groups[3] if len({i//9 for i in e})==2 and e[0]//9==b] for b in range(k)]
    models=[]
    for b in range(k):
        valid=[bits for bits in product((0,1),repeat=9)
               if all(len({bits[i%9] for i in e})==2 for e in intern[b])]
        models.append(valid)
    # Independently count all actual boundary assignments, including six interiors per phase.
    total=0
    for initial in models[0]:
        count={initial:1}
        for b,band in enumerate(bands):
            choices=[initial] if b==k-1 else models[b+1]
            count={new:sum(n for old,n in count.items()
                           if all(len({(old if i//9==b else new)[i%9] for i in e})==2 for e in band))
                   for new in choices}
        total+=count[initial]
    return total


def audit(k):
    plus=[(i*3//2)%2 for i in range(k)]
    plus[0]^=sum(plus)%2
    minus=[s^(i%3==0) for i,s in enumerate(plus)]
    if sum(minus)%2==0:minus[-1]^=1
    g,h=ring(plus),ring(minus)
    a,b=shadow(g),shadow(h)
    hash_edge=lambda edge: tuple(sorted(edge))
    h_edges=[{hash_edge(e) for e in G} for G in h]
    all_r=k-1
    distinct_sizes=set()
    edges_checked=0
    for v in range(9*k):
        x=ball(a,v,all_r); y=ball(b,v,all_r)
        mapping=lifted_ball_map(a,plus,minus,v,all_r)
        assert set(mapping)==x
        convert=mapping.__getitem__
        assert convert(v)==v and {convert(u) for u in x}==y
        assert all({convert(z) for z in a[u]&x}==b[convert(u)]&y for u in x)
        for j,G in enumerate(g):
            relevant=[e for e in G if set(e)<=x]
            assert len(relevant)==sum(set(e)<=y for e in h[j])
            for e in relevant: assert hash_edge(map(convert,e)) in h_edges[j]
            edges_checked+=len(relevant)
        distinct_sizes.add(len(x))
    counts=[model_count_by_transfer(G) for G in (g,h)]
    assert counts==[2*6**k,0]
    return {'variables':9*k,'blocks':k,'radius':all_r,'matching_labeled_triple_comparisons':edges_checked,
            'rooted_ball_sizes':sorted(distinct_sizes),'matched_roots':9*k,'exact_solutions':counts}


def run():
    rows=[audit(k) for k in (3,4,5,8,9,17,24,33)]
    return {'cases':rows,'all_roots_at_maximum_proved_radius':sum(q['matched_roots'] for q in rows)}


if __name__=='__main__':print(json.dumps(run(),indent=2))
