"""Exact closed-walk moment audit on equal-size point graphs."""
import json
from random import Random
from rings import ring,shadow


def moments(adj,steps):
    n=len(adj)
    trace=[0]*(steps+1)
    for root in range(n):
        paths=[0]*n
        paths[root]=1
        for j in range(steps+1):
            trace[j]+=paths[root]
            if j!=steps:
                paths=[sum(paths[v] for v in ns) for ns in adj]
    return trace


def test(k):
    plus=[int(i%3==0) for i in range(k)]
    plus[0]^=sum(plus)%2
    minus=plus.copy();minus[-1]^=1
    values=[]
    for j,signs in enumerate((plus,minus)):
        adj=shadow(ring(signs))
        p=list(range(9*k));Random(691*k+j).shuffle(p)
        perm=[set() for _ in p]
        for v,neighbors in enumerate(adj):perm[p[v]]={p[w] for w in neighbors}
        values.append(moments(perm,2*k))
    dif=[a-b for a,b in zip(*values)]
    assert dif==[0]*(2*k)+[k*2**(k+3)]
    return {'blocks':k,'vertices':9*k,'first_different_moment':2*k,
            'trace_even':values[0][-1],'trace_odd':values[1][-1],
            'difference':dif[-1]}


if __name__=='__main__':print(json.dumps([test(k) for k in (3,4,5,6,7,9,12,17)],indent=2))
