"""Compare full stabilized 1-WL on all seven branch masks and read each by parity."""
from collections import Counter
from pathlib import Path
from random import Random
import json
import sys

ROOT=Path(__file__).resolve().parents[1]
for sub in ('infer_new/actor','infer_new/quotient','frontier2_quotient','frontier2_energy'):
    sys.path.insert(0,str(ROOT/sub))
from audit import compile_seven,relabel
from quotient import as_cnf, decode_blocks, reduce_factors, one_group, read_triangles
from kernel import ungauge
from read_without_start import classify
from rings import ring


def cnf(partitions,start):
    clauses=[]
    for group in partitions:
        for row in group:
            for rotate in range(3):
                order=row[rotate:]+row[:rotate]
                for sign in (-1,1):
                    clauses.append(tuple(sign*(start+p+1) for p in order))
    return clauses


def graph(mask):
    # Distinct variables across prescribed independent slots.
    parts=[[(500+i,),(-500-i,)] for i in range(7)]
    for j,k in enumerate((3,4,5)):
        twist=[0]*k
        twist[-1]=int(not mask&(1<<j))
        parts[(1<<j)-1]=cnf(ring(twist),100*j)
    g=compile_seven(parts)
    return relabel(g,[0,1,2,3],Random(8675+3*mask))


def marked_wl(g,marks):
    colors=[0]*len(g)
    for i,v in enumerate(marks,1):colors[v]=i
    traces=[]
    while True:
        signatures=[(colors[v],tuple(sorted(colors[u] for u in ns))) for v,ns in enumerate(g)]
        types=sorted(set(signatures))
        index={t:i for i,t in enumerate(types)}
        new=[index[t] for t in signatures]
        counts=tuple(sorted(Counter(new).items()))
        # Compare complete signature dictionaries and cell sizes, not digests.
        traces.append((types,counts))
        if len(set(colors))==len(types):return traces
        colors=new


def parity_reader(g,star):
    names,rows=read_triangles(g,star[0])
    blocks=decode_blocks(names,rows,star[1:])
    answers=[]
    for sig in ((0,0,1),(0,1,0),(0,1,1)):
        ok,fac,_=reduce_factors(blocks,zip((names[v] for v in star[1:]),sig),set())
        assert ok
        survived=one_group(as_cnf(fac))[0]
        gauged=ungauge(survived)
        assert gauged
        h=gauged[0]; labels={v:i for i,v in enumerate(sorted(set().union(*h)))}
        edges=[tuple(labels[v] for v in e) for e in h]
        status,w=classify(edges)
        assert status is not None
        if status:assert all(len({w[v] for v in e})==2 for e in edges)
        answers.append(status)
    return sum((1<<i)*b for i,b in enumerate(answers))


def run():
    baseline=None;cases=[]
    for mask in range(8):
        g,marks=graph(mask)
        trace=marked_wl(g,marks)
        if baseline is None:baseline=trace
        else:assert baseline==trace
        got=parity_reader(g,marks)
        assert got==mask
        cases.append({'truth':mask,'recovered_mask':got,'vertices':len(g),
                      'edges':sum(map(len,g))//2,'stable_classes':len(trace[-1][0]),'refinement_rounds':len(trace)})
    return {'source_block_sizes':[3,4,5], 'source_vertex_counts':[27,36,45], 'all_full_signature_traces_equal':True,
            'cases':cases}


if __name__=='__main__':print(json.dumps(run(),indent=2))
