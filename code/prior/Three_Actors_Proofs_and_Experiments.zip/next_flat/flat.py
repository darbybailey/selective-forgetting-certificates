"""Sharp dimension of an affine solution space and connected crossing checks."""
from itertools import combinations, product
from math import isqrt
from pathlib import Path
import json,sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'frontier2_near'))
from one_defect_hard import compile_nae,chain_gate,extend_gate,audit_structure,normalized_quotient,signs_truth


def phase(v,off=0):
    return v,off


def opposite(x,y):
    return x[0]==y[0] and x[1]!=y[1]


def fixed_true(row,forms):
    return any(opposite(forms[a],forms[b]) for a,b in combinations(row,2))


def flat_test(parts,forms):
    return all(fixed_true(row,forms) for group in parts for row in group)


def connected(parts):
    n=len(parts[0])*3
    p=list(range(n))
    def find(i):
        while p[i]!=i:
            p[i]=p[p[i]];i=p[i]
        return i
    for group in parts:
        for u,v,w in group:
            for t in (v,w):p[find(t)]=find(u)
    return len({find(i) for i in range(n)})==1


def extremal(k):
    omega=[0,2,3,1]
    return [[(12*b+i,12*b+4+(i^s),12*((b+int(s==1))%k)+8+(i^omega[s]))
             for b in range(k) for i in range(4)] for s in range(4)]


def ext_forms(k,start=0):
    values=[]
    for b in range(k):
        a=start+5*b
        values.extend([phase(a)]*4+[phase(a,1)]*4+[phase(a+i) for i in range(1,5)])
    return values


def core(cnf):
    m=len(cnf)
    rows,s,f,chain=chain_gate(cnf,m)
    parts,owners=compile_nae(rows,3)
    marked=len(parts[3])-3*len(rows)+1
    return parts,owners,marked


def core_flat(cnf,known):
    H,owners,mark=core(cnf)
    rows,s,f,chain=chain_gate(cnf,len(cnf))
    y=extend_gate(cnf,known,False)
    assert y is not None
    y.update(dict.fromkeys(chain,1))
    assert signs_truth(rows,y)==0
    forms=[]
    for i,v in enumerate(owners):
        forms.extend([phase(0,y[v])]*3+[phase(0,1-y[v])]*3+
                     [phase(2*i+1),phase(2*i+1,1),phase(2*i+2)])
    assert flat_test(H,forms)
    return H,forms,mark


def cross(H,P,core_edge):
    V=3*len(H[0]);parts=[list(row) for row in H]
    for i,row in enumerate(P):
        parts[i].extend(tuple(v+V for v in e) for e in row)
    bound=len(H[3]); g=parts[3]
    u,v,w=g[core_edge];a,b,c=g[bound]
    g[core_edge]=(u,v,c);g[bound]=(a,b,w)
    return parts


def shift_source(V):
    q=V//3
    return [[(i,q+(i+s)%q,2*q+(i+2*s)%q) for i in range(q)] for s in range(4)]


def threshold(n,d):
    diff=max(0,5*n-12*d)
    return diff*diff<=144*n


def local_flat_lemma():
    def form(mask,w):
        return (mask>>3)^((mask&w).bit_count()%2)
    checks=0;always=0
    for triple in product(range(16),repeat=3):
        valid=all(len({form(f,x) for f in triple})==2 for x in range(8))
        fixed=any(a^b==8 for a,b in combinations(triple,2))
        assert valid==fixed
        checks+=1;always+=valid
    return {'3_parameter_affine_triples_tested':checks,'all_points_valid':always}


def flat_examples():
    results=[]
    for k in (1,2,5,25):
        h=extremal(k);v=12*k;forms=ext_forms(k)
        audit_structure(h,v);assert connected(h) and flat_test(h,forms)
        d=len({x for x,off in forms});assert 12*d==5*v
        results.append({'vertices':v,'rank':d,'connected':True,'triples':4*v//3})
    return results


def joined_example():
    cnf=[(1,1,1)];H,forms,mark=core_flat(cnf,{1:1})
    v=len(forms);d0=len({x for x,o in forms})
    # Choose the least number of blocks achieving the actual threshold in this example.
    k=1
    while not threshold(v+12*k,d0+5*k):k+=1
    P=extremal(k);joined=cross(H,P,mark)
    forms+=ext_forms(k,d0)
    n=v+12*k;d=len({x for x,o in forms})
    audit_structure(joined,n)
    assert connected(joined) and flat_test(joined,forms) and threshold(n,d)
    return {'vertices':n,'triples':4*n//3,'core_vertices':v,'padding_blocks':k,'flat_dimension':d,
            'ceiling_threshold_met':True,'every_triple_has_a_certified_opposite_pair':True,'connected':True}


def domination_example():
    cnf=[(1,1,1)]
    H,core_forms,mark=core_flat(cnf,{1:1})
    v=len(core_forms);d0=len({q for q,_ in core_forms})
    k=max(1,((v-d0)**2-v+11)//12)
    P=extremal(k);n=v+12*k
    A0=shift_source(v);A=cross(A0,P,0);B=cross(H,P,mark)
    audit_structure(A,n);audit_structure(B,n)
    assert connected(A) and connected(B)
    domain_q=A0[3][0][2];target_q=H[3][mark][2]
    global_parameter,off=core_forms[target_q]
    assert global_parameter==0
    labels=[domain_q]+[i for i in range(v) if i!=domain_q][:d0-1]
    # Change the global phase's affine offset so target Q_y equals the selected domain bit.
    forms=[phase(labels[j],o^(off if j==0 else 0)) for j,o in core_forms]
    forms.extend(phase(i) for i in range(v,n))
    assert forms[target_q]==phase(domain_q)
    # Every target core row and its crossing with a padding bit is identically true.
    # Every target padding row equals the corresponding domain row as affine arguments.
    core_rows=padding_rows=0
    for i in range(4):
        for ix,e in enumerate(B[i]):
            if ix<len(H[i]):
                assert fixed_true(e,forms);core_rows+=1
            else:
                assert [forms[w] for w in e]==[phase(w) for w in A[i][ix]];padding_rows+=1
    # Do not enumerate 2^N physical assignments. The row identities prove dominance on every word.
    Aforms=[phase(0,0)]*(v//3)+[phase(0,1)]*(v//3)+[phase(0,0)]*(v//3)+ext_forms(k,1)
    assert flat_test(A,Aforms)
    rank=len({j for j,o in forms});assert n-rank<=isqrt(n) and rank<n
    return {'vertices_per_connected_system':n,'triples_per_system':4*n//3,'core_target_rows_always_valid':core_rows,
            'padding_target_rows_verified_identical':padding_rows,'affine_rank':rank,'ambient_rank_deficit':n-rank,
            'floor_sqrt_N':isqrt(n),'known_domain_flat_verified':True}


def negative_example():
    cnf=[(1,1,1),(-1,-1,-1)];H,owners,i=core(cnf)
    local=[row.copy() for row in H];local[3].pop(i)
    residual,sz=normalized_quotient(local)
    variables=sorted({abs(x) for row in residual for x in row})
    cnt=sum(signs_truth(residual,dict(zip(variables,bits)))==0 for bits in product((0,1),repeat=len(variables)))
    assert cnt==0
    h=cross(H,extremal(2),i);n=3*len(h[0]);audit_structure(h,n)
    assert connected(h)
    return {'connected_vertices':n,'after_removing_redundant_filler_nae_variables':len(variables),
            'source_assignments_exhausted':2**len(variables),'source_models_after_deletion':cnt}


def run():
    return {'local_lemma':local_flat_lemma(),'sharp_connected_families':flat_examples(),
            'near_max_connected':joined_example(),'high_rank_pointwise_dominance':domination_example(),
            'negative_after_attachment':negative_example()}


if __name__=='__main__':print(json.dumps(run(),indent=2))
