"""A common-context three-branch exclusion with full pair projections before the promise. Support, equality and count checks are all exact."""
from collections import Counter,defaultdict
from itertools import combinations,product
from random import Random
from terminal import cuts,edges,fano_missing
from verify_boundary import shuffle_rows,cnf,compile_seven,relabel,decode_blocks,read_triangles,reduce_factors,one_group,ungauge,as_cnf


def local(p,q,relation,free):
    # One eight-point system: among 0,1,2,7 the first three agree and the last is opposite.
    order=([p,free[0],q,*free[1:5],free[-1]] if relation=='eq' else [free[0],free[1],p,*free[2:],q])
    assert len(set(order))==8
    return fano_missing(order[:7])|{frozenset(order[i] for i in row) for row in ((0,1,7),(2,3,7))}


def example(states):
    p,b,c,bbar,cbar=range(5)
    context=(local(b,bbar,'ne',list(range(5,11))) | local(c,cbar,'ne',list(range(11,17))) |
             edges([(b,bbar,p),(c,cbar,p)]))
    for u,v in product((0,1),repeat=2):
        if (u,v) not in states:
            context.add(frozenset((p,bbar if u else b,cbar if v else c)))
    free=list(range(17,23))
    return [context|local(t,s,r,free) for t,s,r in ((p,b,'eq'),(p,c,'eq'),(p,c,'ne'))]


def isomorphic(a,b,mark_a=(),mark_b=()):
    av=set().union(*a);bv=set().union(*b)
    if len(a)!=len(b) or len(av)!=len(bv):return False
    inc=[]
    for rows,vs in ((a,av),(b,bv)):
        inc.append({v:[e-{v} for e in rows if v in e] for v in vs})
    def recurse(c,d):
        while True:
            keys={}
            nxt=[]
            for incidence,cols in zip(inc,(c,d)):
                nc={}
                for x in cols:
                    typ=cols[x],tuple(sorted(tuple(sorted(cols[y] for y in w)) for w in incidence[x]))
                    nc[x]=keys.setdefault(typ,len(keys))
                nxt.append(nc)
            if Counter(nxt[0].values())!=Counter(nxt[1].values()):return False
            if len(set(nxt[0].values()))==len(set(c.values())):
                c,d=nxt;break
            c,d=nxt
        cells=Counter(c.values())
        if len(cells)==len(av):
            names={color:x for x,color in d.items()};mp={v:names[col] for v,col in c.items()}
            return {frozenset(mp[v] for v in row) for row in a}==b and {mp[v] for v in mark_a}==set(mark_b)
        _,tag=min((num,tag) for tag,num in cells.items() if num>1)
        x=min(v for v in c if c[v]==tag)
        fresh=max(c.values())+1
        return any(recurse({**c,x:fresh},{**d,y:fresh}) for y in sorted(d) if d[y]==tag)
    return recurse({v:int(v in mark_a) for v in av},{v:int(v in mark_b) for v in bv})


def ternary_actor(systems):
    candidates=[list(cuts(rows,6)) for rows in systems]
    for pp,_,bb,sb in candidates[1]:
        for qq,_,cc,sc in candidates[2]:
            if not all(x or y for x,y in zip(sb,sc)):continue
            if not isomorphic(bb,cc,pp,qq):continue
            for _,_,aa,_ in candidates[0]:
                if isomorphic(aa,bb):
                    return {'excluded_mask':1,'context_clauses':len(bb),'B_counts':sb,'C_counts':sc}
    return None


def raw_graph_reader(graph,star):
    pv,*rest=star
    names,tri=read_triangles(graph,pv)
    blocks=decode_blocks(names,tri,rest)
    branches=[]
    for sig in ((0,0,1),(0,1,0),(0,1,1)):
        ok,fs,_=reduce_factors(blocks,zip([names[v] for v in rest],sig),set())
        res=one_group(as_cnf(fs))[0] if ok else None
        data=ungauge(res) if res else None
        if data is None:return None
        branches.append(data[0])
    return ternary_actor(branches)


def satisfiable(rows):
    vertices=sorted(set().union(*rows))
    def solve(partial):
        scores=Counter()
        for row in rows:
            known={partial[v] for v in row if v in partial}
            if len(known)==2:continue
            unassigned=row-partial.keys()
            if not unassigned:return False
            for v in unassigned:scores[v]+=4**(3-len(unassigned))
        if not scores:return True
        v=max(scores,key=lambda x:(scores[x],-x))
        return any(solve({**partial,v:bit}) for bit in (0,1))
    return solve({vertices[0]:0})


def main():
    observed=set();accepted=0;reports=[]
    bits=list(product((0,1),repeat=2))
    for world in range(16):
        states={w for j,w in enumerate(bits) if world>>j&1}
        branches=example(states)
        mask=(int(any(u==0 for u,v in states)) | (int(any(v==0 for u,v in states))<<1)
              |(int(any(v==1 for u,v in states))<<2))
        assert sum(1<<j for j,branch in enumerate(branches) if satisfiable(branch))==mask
        rng=Random(49251+world)
        if world in (0,2,9):
            from verify_boundary import compile_four,restored
            recovered=[restored(shuffle_rows(compile_four(rs),rng)) for rs in branches]
            assert all(recovered) and ternary_actor(recovered)
        assert ternary_actor([shuffle_rows(r,rng) for r in branches])
        observed.add(mask);accepted+=1
        if world in (1,2,4,8,12,15):
            alternatives=[[(1,),(-1,),(1,j+2)] for j in range(7)]
            for idx,rows in zip((0,1,3),branches):alternatives[idx]=cnf(rows,rng)
            graph,star=relabel(compile_seven(alternatives),[0,1,2,3],rng)
            cert=raw_graph_reader(graph,star)
            assert cert and cert['excluded_mask']!=mask
            reports.append({'available_pin_states':sorted(states),'true_mask':mask,'graph_vertices':len(graph),
                            'graph_edges':sum(map(len,graph))//2,'certificate':cert})
    assert observed=={0,2,3,4,5,6,7}
    assert all({(m>>i&1,m>>j&1) for m in observed}==set(product((0,1),repeat=2))
               for i,j in combinations(range(3),2))
    # Matched false relation control: A is true and B,C both demand the missing pin relation.
    a,b,c=example({(0,0)})
    forged=[a,c,c]
    assert not ternary_actor(forged)
    rng=Random(9317)
    alternatives=[[(1,),(-1,),(1,j+2)] for j in range(7)]
    for k,rows in zip((0,1,3),forged):alternatives[k]=cnf(rows,rng)
    g,star=relabel(compile_seven(alternatives),[0,1,2,3],rng)
    assert not raw_graph_reader(g,star)
    return {'tested_contexts':accepted,'attained_masks':sorted(observed),'each_pair_projection_including_zero_is_full':True, 'on_nonempty_promise_B_or_C':True,
            'four_matching_triples_of_branches_checked':3,'compiled_examples':reports,
            'false_control':{'true_mask':1,'vertices':len(g),'edges':sum(map(len,g))//2,'abstained':True}}

if __name__=='__main__':
    import json
    print(json.dumps(main(),indent=2))
