"""Audit the exact status pair (SAT(F), SAT(F) OR SAT(G)) with independent CNF payloads."""
from collections import Counter,defaultdict
from itertools import product, combinations
import json
from terminal import fano_missing,signatures,good


def guarded(f,g):
    pin='p';selector='q';rows=[]
    for name,form in [('F',f),('G',g)]:
        for i,clause in enumerate(form):
            a,b,c=[((name,abs(v)),int(v<0)) for v in clause]
            u=(name,i,'u');v=(name,i,'v')
            rows.extend([((selector,int(name=='G')),a,(u,0)),
                         ((u,1),b,(v,0)),((v,1),c,(pin,0))])
    return rows


def physical(rows):
    # Each occurrence has its own port. Equality/disequality modules impose adjacent signs.
    old={'p':(0,0), 'q':(1,0)};nextpoint=2
    pieces=[];real=[]
    def alloc(k):
        nonlocal nextpoint
        fresh=list(range(nextpoint,nextpoint+k));nextpoint+=k
        return fresh
    for row in rows:
        line=[]
        for var,sign in row:
            t,=alloc(1)
            if var in old:
                a,prior=old[var]
                if prior==sign:
                    part=fano_missing([a,t,*alloc(5)])
                else:
                    b,c,*rem=alloc(6)
                    part=fano_missing([a,b,c,*rem])|{frozenset((b,c,t))}
                pieces.append((a,t,prior^sign,part))
            old[var]=(t,sign)
            line.append(t)
            real.append((t,var,sign))
        pieces.append((None,None,None,{frozenset(line)}))
    return pieces,real,nextpoint


def model(bits,f):
    return all(any(bits[abs(v)] ^ (v<0) for v in row) for row in f)


def run():
    m1=[(1,1,1)]
    m0=[(1,1,1),(-1,-1,-1)]
    fixtures=[(m1,m1),(m1,m0),(m0,m1),(m0,m0)]
    data=[]
    for f,g in fixtures:
        rows=guarded(f,g);parts,ports,n=physical(rows)
        counts=Counter();project=set();certified=0
        for a,b,neg,part in parts:
            if a is not None and neg not in counts:
                table=signatures(part,(a,b))
                assert tuple(bool(x) for x in table)==tuple((u^v)==neg for v in (0,1) for u in (0,1))
                counts[neg]=1
        physical_rows=set().union(*(part for _,_,_,part in parts))
        degrees=Counter(x for row in physical_rows for x in row)
        assert max(degrees.values())<=5
        pairs=[tuple(sorted(p)) for r in physical_rows for p in combinations(r,2)]
        assert len(set(pairs))==len(pairs)
        all_vars=sorted({var for r in rows for var,s in r},key=repr)
        for bits in product((0,1),repeat=len(all_vars)):
            d=dict(zip(all_vars,bits))
            if any(len({d[v]^s for v,s in row})<2 for row in rows):continue
            pins=(d['p'],d['q'])
            if pins in project:continue
            project.add(pins)
            # Find a concrete model of EACH independent local connector, then verify the union.
            word={0:pins[0],1:pins[1],**{x:d[v]^s for x,v,s in ports}}
            for a,b,neg,part in parts:
                if a is None:continue
                inner=sorted(set().union(*part)-{a,b})
                for w in product((0,1),repeat=len(inner)):
                    local={**{a:word[a],b:word[b]},**dict(zip(inner,w))}
                    if all(good(row,local) for row in part):
                        word.update(local);break
                else:raise AssertionError('incompatible boundary assignment')
            assert len(word)==n and all(good(row,word) for row in physical_rows)
            certified+=1
        sf=any(model({1:b},f) for b in (0,1));sg=any(model({1:b},g) for b in (0,1))
        assert project=={(p,q) for p,q in product((0,1),repeat=2) if (sf if p==q else sg)}
        pair=(any(p==q for p,q in project),bool(project))
        assert pair==(sf,sf or sg)
        data.append({'independent_source_bits':[sf,sg],'branch_bits':pair,
                     'connected_context_points':n,'context_triples':len(physical_rows),
                     'maximum_point_degree':max(degrees.values()),
                     'projected_pin_words':sorted(project),'full_context_witnesses_checked':certified})
    return data

if __name__=='__main__':print(json.dumps(run(),indent=2))
