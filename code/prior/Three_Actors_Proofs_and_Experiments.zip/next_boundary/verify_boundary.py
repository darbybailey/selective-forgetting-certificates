"""Replay independently labelled sources, full four-partition systems, and optional compiled graphs."""
from itertools import combinations
from pathlib import Path
from random import Random
import json
import sys
from terminal import ROOT, compare, edges, good, signatures, source

for name in ('experiment_regular','frontier2_near','frontier2_quotient','infer_new/actor','infer_new/quotient'):
    sys.path.insert(0,str(ROOT/name))
from one_defect_hard import compile_nae, audit_structure
from kernel import kernel, ungauge
from audit import compile_seven,relabel
from quotient import as_cnf,decode_blocks,read_triangles,reduce_factors,one_group


def shuffle_rows(rows, rng):
    vs=sorted(set().union(*rows))
    new=list(range(len(vs)))
    rng.shuffle(new);label=dict(zip(vs,new))
    return {frozenset(label[v] for v in r) for r in rows}


def compile_four(rows):
    triples=[tuple(sorted(v+1 for v in e)) for e in sorted(map(tuple,(sorted(e) for e in rows)))]
    groups,owners=compile_nae(triples,3)
    audit_structure(groups,len(owners)*9)
    return edges(e for p in groups for e in p)


def restored(rows):
    ans=kernel(rows)
    if not ans or ans['inconsistent'] or not ans['monotone']:return None
    return edges(ans['monotone'])


def cnf(rows,rng):
    vs=sorted(set().union(*rows));labels=[(i+1)*rng.choice((-1,1)) for i in range(len(vs))]
    rng.shuffle(labels);d=dict(zip(vs,labels))
    result=[]
    for e in sorted(tuple(sorted(r)) for r in rows):
        w=[d[v] for v in e];rng.shuffle(w)
        result.extend((tuple(w),tuple(-x for x in w)))
    rng.shuffle(result)
    return result


def graph_reader(graph,star,regular):
    p,*rest=star
    names,tri=read_triangles(graph,p)
    blocks=decode_blocks(names,tri,rest)
    cores=[]
    for sig in ((0,0,1),(0,1,0)):
        ok,fs,_=reduce_factors(blocks,zip([names[v] for v in rest],sig),set())
        res=one_group(as_cnf(fs))[0] if ok else None
        raw=ungauge(res) if res else None
        if not raw:return None
        cores.append(restored(raw[0]) if regular else raw[0])
    return compare(*cores) if all(cores) else None


def run(large=False):
    reports=[]
    for idx,(kind,backwards) in enumerate((('forces_different',False),('both',False),('impossible',False),('forces_different',True))):
        a,b=source('strong',kind),source('weak',kind)
        a_count=sum(signatures(a,(0,1)));b_count=sum(signatures(b,(0,1)))
        if kind=='forces_different':
            assert a_count==0 and b_count>0
            assert max(sum({u,v}<=r for r in a) for u,v in combinations(range(13),2))==1
            assert all(frozenset(t) in b for t in combinations((2,3,4,5),3))
        if backwards: a,b=b,a;a_count,b_count=b_count,a_count
        rng=Random(590031+idx)
        aa,bb=shuffle_rows(a,rng),shuffle_rows(b,rng)
        cert=compare(aa,bb)
        assert bool(cert)==(not backwards)
        pa,pb=map(compile_four,(a,b))
        n=len(set().union(*pa))
        assert n==len(set().union(*pb))
        ra,rb=(restored(shuffle_rows(p,rng)) for p in (pa,pb))
        second=compare(ra,rb)
        assert bool(second)==bool(cert)
        info={'context':kind,'reversed':backwards,'base_models':[a_count,b_count],
              'base_points':[len(set().union(*r)) for r in (a,b)],'physical_points_per_branch':n,
              'physical_triples_per_branch':len(pa),'decoded_certificate':second}
        if large and idx not in (0,3):continue
        branch_a,branch_b=(pa,pb) if large else (a,b)
        parts=[[(1,),(-1,),(1,i+2)] for i in range(7)]
        parts[0],parts[1]=cnf(branch_a,rng),cnf(branch_b,rng)
        if kind=='impossible':parts[3]=[(1,)]
        g=compile_seven(parts);g,star=relabel(g,[0,1,2,3],rng)
        final=graph_reader(g,star,large)
        assert bool(final)==bool(cert)
        info['graph']={'vertices':len(g),'edges':sum(len(nbrs) for nbrs in g)//2,
                       'regular_branches_encoded':large,'excluded_only_A':bool(final),
                       'actual_mask':int(bool(a_count))+2*bool(b_count)+4*(kind=='impossible')}
        reports.append(info)
    return reports


if __name__=='__main__':
    import argparse
    ap=argparse.ArgumentParser()
    ap.add_argument('--large',action='store_true')
    print(json.dumps(run(ap.parse_args().large),indent=2))
