"""Two-terminal relations detected on unlabelled ternary NAE systems."""
from collections import defaultdict
from itertools import combinations
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'frontier2_quotient'))
from kernel import iso


def edges(rows):
    return {frozenset(row) for row in rows}


def fano_missing(names):
    lines = {(i, j, (i+1 ^ j+1)-1) for i in range(7) for j in range(i+1, 7)
             if (i+1 ^ j+1)-1 > j}
    assert len(lines) == 7 and (0, 1, 2) in lines
    return edges(tuple(names[i] for i in t) for t in lines if t != (0, 1, 2))


def source(which, controls):
    # Terminals are 0 and 1; the weak/strong modules both use the five private points 2..6.
    equality = fano_missing(range(7))
    free = edges([*combinations((2,3,4,5),3), (0,2,6), (1,3,6)])
    context = fano_missing([0,7,8,9,10,11,12])
    context.add(frozenset((0,7 if controls == 'forces_different' else 9,1)))
    if controls == 'impossible':
        context.add(frozenset((0,7,8)))
    return context | (equality if which == 'strong' else free)


def good(edge, assignment):
    return len({assignment[v] for v in edge}) == 2


def signatures(rows, pins):
    vertices=sorted(set().union(*rows))
    private = [v for v in vertices if v not in pins]
    counts=[0]*4
    for i in range(1<<len(private)):
        assignment={v:(i>>j)&1 for j,v in enumerate(private)}
        for word in range(4):
            assignment.update({v:word>>j&1 for j,v in enumerate(pins)})
            if all(good(e, assignment) for e in rows):
                counts[word]+=1
    return tuple(counts)


def components(primal, pins):
    remaining=set(primal)-set(pins)
    while remaining:
        a=remaining.pop()
        part={a};stack=[a]
        while stack:
            u=stack.pop()
            visit=primal[u] & remaining
            stack.extend(visit);part.update(visit);remaining-=visit
        yield part


def cuts(rows, private_size=5):
    primal=defaultdict(set)
    for e in rows:
        for v in e:
            primal[v].update(e-{v})
    for pins in combinations(sorted(primal),2):
        for part in components(primal,pins):
            if len(part)!=private_size: continue
            local={e for e in rows if e & part}
            if set().union(*local)-part!=set(pins):continue
            outside=rows-local
            if not all(any(p in e for e in outside) for p in pins):continue
            table=signatures(local,pins)
            assert table[0]==table[3] and table[1]==table[2]
            yield pins, local, outside, table


def compare(a,b):
    """Look for a strict inclusion of projected relations before any global solve."""
    right=list(cuts(b))
    for pa, ea, ca, sa in cuts(a):
        for pb, eb, cb, sb in right:
            if len(ca)!=len(cb):continue
            if any(x and not y for x,y in zip(sa,sb)):continue
            if all(bool(x)==bool(y) for x,y in zip(sa,sb)):continue
            # Two unary tags mark the unordered terminal set in the context isomorphism.
            aa = ca | {frozenset((p,)) for p in pa}
            bb = cb | {frozenset((p,)) for p in pb}
            mapping=iso(aa,bb)
            if mapping:
                assert {frozenset(mapping[v] for v in e) for e in ca}==cb
                assert {mapping[p] for p in pa}==set(pb)
                return {'stronger_counts':list(sa),'weaker_counts':list(sb),
                        'source_capsule_points':len(set.union(set(),*ea)),
                        'target_capsule_points':len(set.union(set(),*eb)),
                        'context_edges_checked':len(ca),'context_points_mapped':len(mapping)}
    return None
