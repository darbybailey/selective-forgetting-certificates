"""Conditional projection on cut vertices and incomparable SAT residuals."""
import itertools
import json
from math import prod


def primes_after_two(count):
    result = []
    value = 3
    while len(result) < count:
        if all(value % d for d in range(2, int(value**0.5) + 1)):
            result.append(value)
        value += 2
    return result


def false_row(assignment):
    return tuple(-v if bit else v for v, bit in assignment.items())


def restrict(formula, values):
    out = []
    for row in formula:
        if any(abs(l) in values and bool(values[abs(l)]) == (l > 0) for l in row):
            continue
        out.append(tuple(l for l in row if abs(l) not in values))
    return out


def family(hard, m):
    h = 1
    last = max(abs(v) for row in hard for v in row)
    xs = list(range(last+1, last+m+1))
    last = xs[-1]
    formula = list(hard)
    badges = []
    for p, x in zip(primes_after_two(m), xs):
        y = last + 1
        n = p.bit_length()
        zs = list(range(y+1, y+1+n))
        last = zs[-1]
        badges.append((p, y, zs))
        for hv in (0, 1):
            for xv in (0, 1):
                formula.append(false_row({h: hv, x: xv, y: 1^(hv^xv)}))
            for z in zs:
                formula.append(false_row({h: hv, x: 0, z: 1-hv}))
            for forbidden in range(p, 1 << n):
                assignment = {h:hv, x:1}
                assignment.update((z, ((forbidden >> j) & 1)^hv) for j, z in enumerate(zs))
                formula.append(false_row(assignment))
    return xs, badges, formula


def normalize(formula):
    return tuple(sorted(tuple(sorted(row)) for row in formula))


def project(formula, pivot, budget):
    adj = {}
    for row in formula:
        vertices = sorted(set(abs(v) for v in row if abs(v) != pivot))
        for v in vertices:
            adj.setdefault(v, set())
        if vertices:
            for v in vertices[1:]:
                adj[vertices[0]].add(v)
                adj[v].add(vertices[0])
    comp_id = {}
    components = []
    for v in adj:
        if v in comp_id:
            continue
        i = len(components)
        seen = {v}
        stack = [v]
        while stack:
            for w in adj[stack.pop()]:
                if w not in seen:
                    stack.append(w)
                    seen.add(w)
        components.append(sorted(seen))
        comp_id.update(dict.fromkeys(seen, i))
    rows = [[] for _ in components]
    core = []
    boundary = {0, 1}
    small = []
    for row in formula:
        v = next((abs(l) for l in row if abs(l) != pivot), None)
        if v is None:
            boundary = {b for b in boundary if not restrict([row], {pivot:b})}
        else:
            rows[comp_id[v]].append(row)
    for vs, local in zip(components, rows):
        if len(vs) > budget:
            core.extend(local)
            continue
        small.append(len(vs))
        possible = set()
        for b in boundary:
            for bits in itertools.product((0,1), repeat=len(vs)):
                assignment=dict(zip(vs, bits))
                assignment[pivot]=b
                if not restrict(local, assignment):
                    possible.add(b)
                    break
        boundary &= possible
    return normalize(core), sorted(boundary), small


def common_certificate(left, right, budget):
    common = {abs(l) for row in left for l in row} & {abs(l) for row in right for l in row}
    for pivot in sorted(common):
        a, ma, _ = project(left, pivot, budget)
        b, mb, _ = project(right, pivot, budget)
        if a == b and set(ma) <= set(mb):
            return pivot, ma, mb
    return None


def brute(formula, vs):
    return {bits for bits in itertools.product((0,1), repeat=len(vs))
            if not restrict(formula, dict(zip(vs,bits)))}


def main():
    small_h=[(1,2),(1,-2),(2,3)]
    xs,badges,small=family(small_h,2)
    suffix=sorted({abs(l) for row in small for l in row} - set(xs))
    models=[]
    for bits in itertools.product((0,1), repeat=2):
        models.append(brute(restrict(small,dict(zip(xs,bits))),suffix))
    assert [len(x) for x in models] == [3,15,9,45]
    assert all(not a&b for a,b in itertools.combinations(models,2))
    # A connected large component, preserved exactly after deleting the pivot and
    # projecting the small independent components. SAT truth is withheld from the reader.
    r=12
    spine=[(v,-v-1) for v in range(2,r)] + [(-v,v+1) for v in range(2,r)]
    fixtures={'sat':spine+[(1,2),(-1,-2)], 'unsat':spine+[(1,2),(-1,2),(1,-2),(-1,-2)]}
    variants=6
    trials=[]
    for name,H in fixtures.items():
        xs,badges,f=family(H,variants)
        counts = set()
        gold=len(brute(H,list(range(1,r+1))))
        assert (name=='sat')==(gold>0)
        checks=0
        for d in range(variants+1):
            for bits in itertools.product((0,1),repeat=d):
                g=restrict(f,dict(zip(xs,bits)))
                core,mask,small_sizes=project(g,1,7)
                assert core==normalize(H) and mask==[0,1]
                checks+=1
                if d==variants:
                    counts.add(gold*prod(p for (p,_,_),b in zip(badges,bits) if b))
        assert len(counts)==(2**variants if gold else 1)
        trials.append(dict(core_status=name,variables=max(abs(v) for e in f for v in e),
                           clauses=len(f),classifications=checks,depth_m_residuals=2**variants,
                           distinct_model_counts=len(counts),root_core_models=gold))
    # An actual change in a branch's allowed boundary value prevents interchangeability.
    cut=fixtures['sat']+[(1,)]
    anchor_checks=[]
    for name,H in fixtures.items():
        xs,_,formula=family(H,variants)
        renamed={v:(31*v)%47+1 for v in set(abs(l) for row in formula for l in row)}
        def relabel(rows):
            return [tuple((1 if lit>0 else -1)*renamed[abs(lit)] for lit in reversed(row))
                    for row in reversed(rows)]
        reference=relabel(restrict(formula,dict.fromkeys(xs,0)))
        for i in range(2**variants):
            right=relabel(restrict(formula,{v:(i>>j)&1 for j,v in enumerate(xs)}))
            proof=common_certificate(reference, right, 7)
            assert proof is not None
        anchor_checks.append({'core_status':name,'found_without_given_pivot':2**variants})
    positive=common_certificate(cut+[(-1,)],cut,7)
    assert positive is not None
    assert common_certificate(cut,cut+[(-1,)],7) is None
    mask_results=[]
    for fixed in ((1,),(-1,)):
        core,mask,_=project(cut+[fixed],1,7)
        mask_results.append(mask)
    assert mask_results==[[1],[]]
    return {'two_gate_bruteforce':{'models':[len(s) for s in models],
            'pairwise_model_intersections':[len(a&b) for a,b in itertools.combinations(models,2)]},
            'gate_primes':primes_after_two(variants),'large_examples':trials,'extra_unit_controls':mask_results,
            'formula_only_pivot_discovery':anchor_checks,'wrong_implication_control_abstains':True}

if __name__=='__main__':
    print(json.dumps(main(),indent=2))
