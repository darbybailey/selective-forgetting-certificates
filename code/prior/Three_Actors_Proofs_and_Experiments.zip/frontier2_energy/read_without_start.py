"""Exact local projection and a global parity witness from an unordered list of triples."""
from itertools import combinations
from random import Random
import json
from energy import build,gabber_galil,torus,violated


def classify(edges):
    n=1+max(p for line in edges for p in line)
    incident=[[] for _ in range(n)]
    for i,line in enumerate(edges):
        if len(line)!=3 or len(set(line))!=3:
            return None,None
        for v in line:incident[v].append(i)
    if any(len(ids)!=4 for ids in incident):
        return None,None
    chart=[None]*n; port=[None]*n; extensions=[]
    internal=set()
    for root in range(n):
        if chart[root] is not None:
            continue
        points={p for j in incident[root] for p in edges[j]}
        if len(points)!=9:
            continue
        touched={j for p in points for j in incident[p]}
        local={j for j in touched if all(v in points for v in edges[j])}
        if len(local)!=10 or any(sum(j in local for j in incident[v])<3 for v in points):
            continue
        boundary=sorted({v for j in touched-local for v in edges[j] if v in points})
        if len(boundary)!=6:
            continue
        order=sorted(points)
        masks=[sum(1<<order.index(v) for v in edges[j]) for j in local]
        patterns={}
        for w in range(512):
            if all(0 < w&m < m for m in masks):
                bits=tuple(w>>order.index(v)&1 for v in boundary)
                patterns.setdefault(bits,w)
        if len(patterns)!=2:
            continue
        first=next((b for b in patterns if not b[0]),None)
        if first is None or tuple(1-b for b in first) not in patterns:
            continue
        if any(chart[v] is not None for v in order):
            return None,None
        i=len(extensions)
        for v in order:chart[v]=i
        for v,b in zip(boundary,first):port[v]=b
        extensions.append((order,patterns[first],patterns[tuple(1-b for b in first)]))
        internal.update(local)
    if None in chart:return None,None
    neighbors=[[] for group in extensions]
    for j,line in enumerate(edges):
        if j in internal:continue
        bits={(chart[v],port[v]) for v in line}
        if any(phase is None for g,phase in bits):return None,None
        if any((g,1^phase) in bits for g,phase in bits):continue
        if len(bits)==1:return False,None
        if len(bits)==2:
            (a,p),(b,q)=bits
            neighbors[a].append((b,1^p^q))
            neighbors[b].append((a,1^p^q))
    values=[None]*len(extensions)
    for g in range(len(values)):
        if values[g] is not None:continue
        values[g]=0;stack=[g]
        while stack:
            v=stack.pop()
            for w,r in neighbors[v]:
                other=values[v]^r
                if values[w] is None:
                    values[w]=other;stack.append(w)
                elif values[w]!=other:
                    return False,None
    bits=[0]*n
    for (order,w0,w1),val in zip(extensions,values):
        word=w1 if val else w0
        for i,v in enumerate(order):bits[v]=word>>i&1
    if any(violated(e,bits) for e in edges):return None,None
    return True,bits


def alter(parts,red,blue):
    # Exchange the singly occurring positive port of two unmodified blue relations.
    # This imposes equality between the two connected regions in addition to disequality.
    pos={tuple(row):i for i,row in enumerate(parts[3])}
    n=len(blue)
    a=(3,4,9*blue[0]+2)
    b=(9*n+3,9*n+4,9*(n+blue[0])+2)
    new=[list(p) for p in parts]
    new[3][pos[a]]=(a[0],a[1],b[2]);new[3][pos[b]]=(b[0],b[1],a[2])
    return new


def scramble(parts,seed):
    rows=[tuple(e) for p in parts for e in p]
    ren=list(range(max(max(e) for e in rows)+1));rng=Random(seed);rng.shuffle(ren)
    rows=[tuple(ren[x] for x in row) for row in rows]
    rows=[tuple(rng.sample(row,len(row))) for row in rows]
    rng.shuffle(rows)
    return rows


def run():
    report=[]
    for geometry,h,perms in [('torus',2,torus(2)),('expander',3,gabber_galil(3)),
                              ('expander',11,gabber_galil(11))]:
        r,b=perms;parts=build(r,b)
        for true,incoming in ((True,parts),(False,alter(parts,r,b))):
            for seed in (934,2124):
                edges=scramble(incoming,seed)
                answer,assignment=classify(edges)
                assert answer==true
                if true:
                    assert not any(violated(e,assignment) for e in edges)
                report.append({'geometry':geometry,'parameter':h,'seed':seed,'variables':18*len(r),
                               'ground_truth':true,'answer':answer,'original_triples_checked_on_witness':len(edges) if true else 0})
    return {'inputs':'unordered relabeled triples only','tests':report}


if __name__=='__main__':print(json.dumps(run(),indent=2))
