"""NAE repair barriers from two ferromagnetic phases on a bounded-degree template."""
from collections import Counter, deque
from itertools import combinations, product
import json


def planes():
    return [[tuple(3*x+y for y in range(3)) for x in range(3)]]+[
        [tuple(3*x+(s*x+b)%3 for x in range(3)) for b in range(3)] for s in range(3)]


def internal_rows():
    p=planes()
    return [p[0][2],*(line for part in p[1:] for line in part)]


def valid(line, word):
    return len({(word>>x)&1 for x in line})>1


def local_check():
    rows=internal_rows()
    wanted=Counter()
    for word in range(512):
        if all(valid(line,word) for line in rows):
            wanted[tuple((word>>i)&1 for i in range(6))]+=1
    assert wanted=={(0,0,0,1,1,1):6,(1,1,1,0,0,0):6}
    return wanted


def gabber_galil(h):
    side=4*h*h
    red=[];blue=[]
    def idx(x,y,j):
        return 4*((x%h)*h+y%h)+j
    for x,y,j in product(range(h),range(h),range(4)):
        dests=((x+2*y,y),(x+2*y+1,y),(x,y+2*x),(x,y+2*x+1))
        a,b=dests[j]; newj=(j+1)%4
        red.append(idx(x,y,newj))
        blue.append(idx(a,b,newj))
    assert len(red)==side
    return red,blue


def torus(h):
    return ([((x+1)%h)*h+y for x,y in product(range(h),repeat=2)],
            [x*h+(y+1)%h for x,y in product(range(h),repeat=2)])


def build(red,blue):
    side=len(red)
    assert set(red)==set(blue)==set(range(side))
    assert all(u!=r and u!=b for u,(r,b) in enumerate(zip(red,blue)))
    parts=[[] for _ in range(4)]
    for v in range(2*side):
        for k,group in enumerate(planes()):
            for row in (group if k else group[2:]):
                parts[k].append(tuple(9*v+j for j in row))
    special=[]
    for copy in range(2):
        off=copy*side
        for v in range(side):
            rededge=(9*(off+v),9*(off+v)+1,9*(off+red[v])+5)
            if v==0: special.append(rededge)
            else: parts[0].append(rededge)
            parts[0].append((9*(off+v)+3,9*(off+v)+4,9*(off+blue[v])+2))
    a,b,c=special[0];d,e,f=special[1]
    parts[0].extend(((a,b,d),(c,e,f)))
    # Publish the modified matching last so the supplied start satisfies the first three.
    return parts[1:]+[parts[0]]


def word_pair(size):
    # x=0 row and x=1 row have opposite colors. Third row is nonconstant.
    a=(0,0,0,1,1,1,0,1,0)
    b=tuple(1-v if i<6 else v for i,v in enumerate(a))
    return a*size*2,a*size+b*size


def violated(line,bits):
    a,b,c=line
    return bits[a]==bits[b]==bits[c]


def audited(red,blue):
    parts=build(red,blue)
    size=len(red)
    start,goal=word_pair(size)
    for each in parts:
        assert sorted(x for row in each for x in row)==list(range(18*size))
    pairs={};n=0
    for i,part in enumerate(parts):
        for row in part:
            for a,b in combinations(row,2):
                key=tuple(sorted((a,b)))
                assert key not in pairs
                pairs[key]=1
            n+=1
    broken=[sum(violated(row,start) for row in part) for part in parts]
    assert broken==[0,0,0,1]
    assert not any(violated(row,goal) for part in parts for row in part)
    # Construct an ordinary path to a full solution. Check every affected constraint.
    flat=[r for p in parts for r in p]
    by_vertex=[[] for _ in start]
    for idx,row in enumerate(flat):
        for v in row:by_vertex[v].append(idx)
    count=1;peak=1; steps=0
    current=list(start)
    for v,desired in enumerate(goal):
        if current[v]==desired:continue
        old=sum(violated(flat[i],current) for i in by_vertex[v])
        current[v]^=1
        count+=sum(violated(flat[i],current) for i in by_vertex[v])-old
        peak=max(peak,count);steps+=1
    assert count==0 and tuple(current)==goal
    return {'variables':len(start),'triples':n,'initial_violations_by_matching':broken,'sweep_flips':steps,'sweep_peak_upper_bound':peak}


def bisect_exact(red,blue):
    # Complement symmetry lets us always place vertex zero in the set.
    n=len(red)
    edges=tuple(enumerate(red))+tuple(enumerate(blue))
    best=10*n
    for choice in combinations(range(1,n),n//2-1):
        half={0,*choice}
        best=min(best,sum((v in half)!=(w in half) for v,w in edges))
    return best


def ceil_positive_ratio(x,y):
    return -(-x//y)


def main():
    local_check()
    results=[]
    # 5 sqrt 2 < 7.07107, so the following rational is a certified lower gap.
    assert 707107**2>50*100000**2
    for h in (2,5,11,16,31):
        red,blue=gabber_galil(h)
        row=audited(red,blue)
        rhs=ceil_positive_ratio(92893*h*h-1000000,4000000)
        row.update(parameter=h,certified_peak_lower_bound=max(1,rhs))
        if h==2:
            b=bisect_exact(red,blue)
            row['exact_balanced_cut']=b
            row['cut_based_peak_lower_bound']=ceil_positive_ratio(b-1,4)
        results.append(row)
    small=[]
    for h in (2,4,8):
        red,blue=torus(h); row=audited(red,blue); row.update(width=h)
        if h<=4:row['exact_balanced_cut']=bisect_exact(red,blue)
        small.append(row)
    return {'local_truth_assignments':512,'port_patterns':2,'main':results,'grid_controls':small}


if __name__=='__main__':
    print(json.dumps(main(),indent=2))
