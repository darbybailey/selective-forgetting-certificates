"""A parsimonious count of violated clauses along canonical lifts of signed NAE assignments."""
from collections import Counter
from itertools import combinations, product
import json


def plane():
    vertical = [(3*x,3*x+1,3*x+2) for x in range(3)]
    return [vertical]+[[(3*0+b,3+(s+b)%3,6+(2*s+b)%3) for b in range(3)] for s in range(3)]


def good(row,bits):
    return len({bits[i] for i in row})==2


def half_plane():
    internal=[e for m in plane() for e in m][2:]
    boundaries=Counter()
    reps={}
    for b in product((0,1),repeat=9):
        if all(good(row,b) for row in internal):
            boundaries[b[:6]]+=1
            reps.setdefault(b[0], b)
    assert boundaries=={(0,0,0,1,1,1):6,(1,1,1,0,0,0):6}
    return reps


def val(lit,bits):
    return bits[abs(lit)] ^ (lit<0)


def gate(cnf):
    """Signed NAE variable identifiers are positive integers; both signs are allowed."""
    last=max((abs(x) for row in cnf for x in row),default=0)
    s,z=last+1,last+2
    signed=[]
    for j,(a,b,c) in enumerate(cnf):
        u,v=z+2*j+1,z+2*j+2
        signed.extend(((-s,a,u),(-u,b,v),(-v,c,z)))
    signed.append((s,z,z))
    return signed,s,z


def extend_gate(cnf,x,start):
    signed,s,z=gate(cnf)
    bits={**x,s:int(not start),z:0}
    for j in range(len(cnf)):
        sub=signed[3*j:3*j+3]
        for p,q in product((0,1),repeat=2):
            bits.update({z+2*j+1:p,z+2*j+2:q})
            if all(len({val(v,bits) for v in row})>1 for row in sub):
                break
        else:
            return None
    return bits


def chain_gate(cnf,K):
    """Keep guarded rows in the same order; append K sensitive activation checks."""
    assert K>=1
    signed,s,f=gate(cnf)
    next_id=f+2*len(cnf)+1
    chain=[s]+list(range(next_id,next_id+K-1))
    activation=[(a,a,-b) for a,b in zip(chain,chain[1:])]
    activation.append((chain[-1],chain[-1],f))
    return signed[:-1]+activation,s,f,chain


def near_bits(cnf,K,j):
    """Known start whose only false signed triple is at position 3*m+j."""
    assert 0<=j<K
    _,s,f,chain=chain_gate(cnf,K)
    bits={abs(v):0 for row in cnf for v in row}
    bits.update({s:0,f:0})
    bits.update({f+1+h:0 for h in range(2*len(cnf))})
    bits.update({v:int(i>j) for i,v in enumerate(chain)})
    return bits


def compile_nae(signed,L):
    assert L>=3
    counts=Counter(abs(v) for row in signed for v in row)
    bases={};owners=[]
    for v,k in sorted(counts.items()):
        bases[v]=len(owners)
        owners.extend([v]*(L*k))
    edges=[[] for _ in range(4)]
    for b in range(len(owners)):
        for i,matching in enumerate(plane()):
            for row in (matching[2:] if i==0 else matching):
                edges[(i-1)%4].append(tuple(9*b+p for p in row))
    payloads=[]
    seen=Counter()
    removed={}
    for row in signed:
        slots=[]
        for lit in row:
            v=abs(lit);b=bases[v]+L*seen[v];seen[v]+=1
            nxt=b+1
            if lit>0:
                ports=(9*b,9*b+1,9*nxt+5)
            else:
                ports=(9*b+3,9*b+4,9*nxt+2)
            removed[b]=int(lit<0)
            slots.append(ports)
        x,y,z=slots
        payloads.extend(((x[0],y[0],z[0]),(x[1],x[2],y[1]),(z[1],z[2],y[2])))
    for v,k in sorted(counts.items()):
        for i in range(k*L):
            b=bases[v]+i
            nxt=bases[v]+(i+1)%(L*k)
            if removed.get(b)!=0:edges[3].append((9*b,9*b+1,9*nxt+5))
            if removed.get(b)!=1:edges[3].append((9*b+3,9*b+4,9*nxt+2))
    edges[3].extend(payloads)
    return edges,owners


def lift(owners,bits,reps):
    return tuple(c for v in owners for c in reps[bits[v]])


def audit_structure(edges,n):
    pairs=set()
    for matching in edges:
        assert sorted(v for row in matching for v in row)==list(range(n))
        for row in matching:
            for pair in combinations(sorted(row),2):
                assert pair not in pairs
                pairs.add(pair)
    return len(pairs)


def bad_counts(edges,bits):
    return [sum(not good(row,bits) for row in matching) for matching in edges]


def normalized_quotient(edges):
    """Re-read actual fourth triples using known block layout, never using source variable names."""
    maxvertex=max(max(row) for row in edges[3])
    blocks=(maxvertex+1)//9
    parent=list(range(blocks))
    def find(a):
        while parent[a]!=a:
            parent[a]=parent[parent[a]]
            a=parent[a]
        return a
    payload=[]
    for row in edges[3]:
        a,b,c=row
        if all(p%9>=6 for p in row):
            continue
        if a//9==b//9 and a%9 in (0,3) and b%9==a%9+1:
            assert a//9!=c//9 and (a%9<3)!=(c%9<3)
            parent[find(c//9)]=find(a//9)
        else:
            payload.append(row)
    parts={}
    for b in range(blocks):
        parts.setdefault(find(b),[]).append(b)
    idx={root:i+1 for i,(root,members) in enumerate(sorted(parts.items(),key=lambda p:min(p[1])))}
    def raw(row):
        return tuple((1 if p%9<3 else -1)*idx[find(p//9)] for p in row)
    return [raw(row) for row in payload],sorted(map(len,parts.values()))


def signs_truth(rows,bits):
    return sum(len({val(lit,bits) for lit in row})==1 for row in rows)


def helper_test():
    for b in product((0,1),repeat=5):
        a,x,y,w,z=b
        possible=any(len({a,x,u})==len({1-u,y,v})==len({1-v,w,z})==2
                     for u,v in product((0,1),repeat=2))
        assert possible==(len(set(b))==2)
    return 32


def check(cnf,L,reps):
    signed,s,z=gate(cnf)
    edges,owners=compile_nae(signed,L);N=9*len(owners)
    assert N==9*L*(9*len(cnf)+3)
    audit_structure(edges,N)
    quo,lengths=normalized_quotient(edges)
    # Order block groups by the smallest original block ID, skipping unused variable IDs.
    source_names=sorted(set(owners));decomp={v:i+1 for i,v in enumerate(source_names)}
    expected=[tuple(decomp[abs(v)]*(1 if v>0 else -1) for v in row) for row in signed]
    assert quo[::3]==expected
    assert all(any(-v in row for v in row) for j,row in enumerate(quo) if j%3!=0)
    xvars=sorted(abs(v) for v in set(abs(v) for r in cnf for v in r))
    first=extend_gate(cnf,{v:0 for v in xvars},True)
    near=lift(owners,first,reps)
    assert bad_counts(edges,near)==[0,0,0,1]
    trigger_index=len(edges[3])-3
    assert not good(edges[3][trigger_index],near)
    verified=[]
    for pattern in product((0,1),repeat=len(xvars)):
        x=dict(zip(xvars,pattern))
        sat=all(any(val(v,x) for v in row) for row in cnf)
        ext=extend_gate(cnf,x,False)
        assert (ext is not None)==sat
        if ext:
            cert=lift(owners,ext,reps)
            assert bad_counts(edges,cert)==[0]*4
            dist=sum(a!=b for a,b in zip(near,cert))
            assert dist>=6*L*(len(cnf)+1)
            verified.append(dist)
    return dict(source_clauses=len(cnf),spacing=L,vertices=N,triples=sum(map(len,edges)),
                starting_bad_counts=bad_counts(edges,near),trigger_index_in_fourth=trigger_index,
                quotient_sensitive= len(quo)//3,quotient_tautologies=2*len(quo)//3,
                decoded_clause_list_matches=True,all_shapes_checked=True,
                count_original_solutions=len(verified),full_witnesses_checked=len(verified),
                hamming_lower_bound_all_solutions=6*L*(len(cnf)+1),
                nearest_among_canonical_witnesses=min(verified,default=None))


def main():
    reps=half_plane();full=[tuple((i+1)*s for i,s in enumerate(bits)) for bits in product((-1,1),repeat=3)]
    results=[]
    for name,f,L in [('contradictory-cube',full,3),('single-survivor',full[:-1],3),
                     ('contradictory-repeated',[(1,1,1),(-1,-1,-1)],7),
                     ('full-tautology',[(1,-1,2),(-2,1,-1)],5)]:
        results.append({'name':name,**check(f,L,reps)})
    # Independently test every subset of the eight signed clauses, on every 3-bit input.
    decisions=0
    for subset in range(256):
        f=[row for j,row in enumerate(full) if subset & (1<<j)]
        for colors in product((0,1),repeat=3):
            x=dict(enumerate(colors,1))
            ext=extend_gate(f,x,False)
            assert (ext is not None)==all(any(val(v,x) for v in row) for row in f)
            decisions+=1
    # Count-preserving check for arbitrary assignments on the nonuniform signed source.
    raw=[(1,1,-2),(-2,3,1),(3,-3,2),(-1,-2,-3),(3,3,3)]
    graph,owners=compile_nae(raw,3)
    checks=0
    for bits in product((0,1),repeat=3):
        d=dict(enumerate(bits,1));seen=bad_counts(graph,lift(owners,d,reps))
        assert seen==[0,0,0,signs_truth(raw,d)];checks+=1
    return {'five_literal_helper_truth_rows':helper_test(),'gated_formula_assignment_checks':decisions,
            'signed_defect_count_preservation_checks':checks,'structured_runs':results}


if __name__=='__main__':
    print(json.dumps(main(),indent=2))
