"""Check an odd cycle of punctured affine planes in four perfect matchings."""
import argparse
from collections import Counter
from itertools import combinations, product
import json


def plane():
    # Points (x,y) have IDs 3*x + y. The deleted parallel lines are (0,1,2) and (3,4,5).
    vertical = [tuple(3*x+y for y in range(3)) for x in range(3)]
    return [vertical] + [[tuple(3*x+(s*x+b)%3 for x in range(3))
                          for b in range(3)] for s in range(3)]


def edges_of(classes):
    return [line for parallel in classes for line in parallel]


def is_nae(edges, colors):
    return all(len({colors[x] for x in line}) >= 2 for line in edges)


def port_models():
    lines = edges_of(plane())
    patterns = Counter()
    representatives = {}
    for colors in product(range(2), repeat=9):
        assert not is_nae(lines, colors)
        if is_nae(lines[2:], colors):
            pattern = tuple(colors[:6])
            patterns[pattern] += 1
            representatives.setdefault(pattern[0], colors)
    assert patterns == {(0,0,0,1,1,1):6, (1,1,1,0,0,0):6}
    return patterns, representatives


def ring(m, swapped=False):
    assert m >= 3
    classes = [[] for _ in range(4)]
    for i in range(m):
        for j,group in enumerate(plane()):
            for k,line in enumerate(group):
                if j != 0 or k == 2:
                    classes[j].append(tuple(9*i+x for x in line))
    connectors = [[9*i, 9*i+1, 9*((i+1)%m)+2] for i in range(m)]
    if swapped:
        connectors[0][1], connectors[1][1] = connectors[1][1], connectors[0][1]
    classes[0].extend(map(tuple,connectors))
    classes[0].extend((9*i+3, 9*((i+1)%m)+4, 9*((i+2)%m)+5) for i in range(m))
    return classes, list(map(tuple,connectors))


def dfs_search(edges,n):
    # Independent direct NAE search on original triples, with color symmetry.
    nodes = 0
    def recurse(colors):
        nonlocal nodes
        nodes += 1
        while True:
            pending = {}
            scores = Counter()
            for line in edges:
                used = {colors[v] for v in line if v in colors}
                if len(used) == 2:
                    continue
                free = [v for v in line if v not in colors]
                if not free:
                    return None
                if len(free)==1:
                    v, = free
                    desired = 1-next(iter(used))
                    if v in pending and pending[v] != desired:
                        return None
                    pending[v] = desired
                else:
                    for v in free:
                        scores[v] += 3-len(free)+1
            if pending:
                colors.update(pending)
                continue
            if not scores:
                return [colors.get(i,0) for i in range(n)]
            v = max(scores, key=lambda i:(scores[i],-i))
            for c in (0,1):
                found = recurse({**colors,v:c})
                if found is not None:
                    return found
            return None
    solution = recurse({0:0})
    if solution is not None:
        assert is_nae(edges,solution)
    return solution, nodes


def audit_shape(groups,n):
    assert len(groups)==4
    pts = list(range(n))
    for group in groups:
        assert sorted(p for line in group for p in line)==pts
    edges = edges_of(groups)
    pairs = Counter(pair for line in edges for pair in combinations(sorted(line),2))
    assert all(count==1 for count in pairs.values())
    nbrs = {v:set() for v in pts}
    for a,b in pairs:
        nbrs[a].add(b); nbrs[b].add(a)
    seen=set(); stack=[0]
    while stack:
        u=stack.pop()
        if u not in seen:
            seen.add(u); stack.extend(nbrs[u]-seen)
    assert len(seen)==n
    # Count nine-cliques in the point adjacency graph. Each plane needs one.
    def count(candidate, need):
        if need==1:
            return len(candidate)
        total = 0
        while len(candidate)>=need:
            v = min(candidate)
            candidate = candidate-{v}
            total += count(candidate & nbrs[v], need-1)
        return total
    assert count(set(pts),9)==0
    # Separately count 5-cliques in the edge-intersection graph. Fano requires 7.
    lines=list(map(set,edges))
    en={i:{j for j in range(i+1,len(lines)) if e&lines[j]} for i,e in enumerate(lines)}
    def edge_clique(candidates,depth):
        if depth==5:
            return 1
        return sum(edge_clique(candidates&en[v],depth+1) for v in candidates)
    assert edge_clique(set(en),0)==0
    return {'vertices':n,'edges':len(edges),'matching_sizes':[len(s) for s in groups],
            'connected':True,'distinct_point_pairs':len(pairs),'nine_point_cliques':0,
            'five_pairwise_intersecting_edges':0}


def lift(macro,reps):
    return [color for value in macro for color in reps[value]]


def sample(m, reps, exact):
    negative,connectors=ring(m)
    positive,near_connectors=ring(m,True)
    es=edges_of(negative); yes=edges_of(positive)
    no_shape=audit_shape(negative,9*m); yes_shape=audit_shape(positive,9*m)
    assert no_shape==yes_shape
    assert len(set(es)-set(yes))==len(set(yes)-set(es))==2
    base=[i%2 for i in range(m)]
    candidate=lift(base,reps)
    defects=sum(not is_nae([e],candidate) for e in es)
    assert defects==m%2
    for j in range(m):
        macro=[((i-(j+1))%m)%2 for i in range(m)]
        assert is_nae([e for e in es if e!=connectors[j]], lift(macro,reps))
    # Swapped ring: first and last variables are joined by a path through blocks
    # 2,...,m-1; choose those colors backwards. Block 1 opposes block 0.
    macro=[0,1]+[(m-i)%2 for i in range(2,m)]
    assert is_nae(yes,lift(macro,reps))
    result={'blocks':m,**no_shape,'unswapped_is_sat':m%2==0,
            'unswapped_minimum_monochromatic_edges':defects,
            'connector_deletions_with_checked_witness':m,
            'swapped_is_sat':True, 'swapped_explicit_macro_coloring':macro}
    if exact:
        for name, rows in [('unswapped',es),('swapped',yes)]:
            sol,visits=dfs_search(rows,9*m)
            assert (sol is not None)==result[name+'_is_sat']
            result[name+'_independent_search_nodes']=visits
    if m==3:
        result['unswapped_matchings']=negative
        result['swapped_matchings']=positive
        result['unswapped_one_defect_vertex_coloring']=candidate
        result['swapped_valid_vertex_coloring']=lift(macro,reps)
    return result


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--exact-through',type=int,default=5,
                        help='largest block count for the independent full NAE search')
    args=parser.parse_args()
    patterns, reps = port_models()
    runs=[sample(m,reps,m<=args.exact_through) for m in (3,4,5,7,11,21)]
    print(json.dumps({'affine_plane_assignments_examined':512,
                      'punctured_plane_port_pattern_multiplicities':
                          {''.join(map(str,k)):v for k,v in patterns.items()},
                      'tested_rings':runs},indent=2))
