"""Recompute the packaged results. Use --full for all compiled-graph checks."""
import argparse
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent

# Entries are (module, recorded JSON, extra command-line arguments).
QUICK = [
    ('next_flat/flat.py', 'RESULTS.json', ()),
    ('next_affine/affine.py', 'results.json', ()),
    ('next_priority/width.py', 'results.json', ()),
    ('next_weak/modal_exclusion.py', 'RESULTS.json', ()),
    ('next_ternary/ternary.py', 'results.json', ()),
    ('next_ternary/closure.py', 'closure_results.json', ()),
    ('next_ternary/connected.py', 'connected_results.json', ()),
    ('next_boundary/two_inputs.py', 'two_inputs_results.json', ()),
    ('next_boundary/verify_boundary.py', 'results.json', ()),
    ('next_nofold/certificates.py', 'RESULTS.json', ()),
    ('next_nofold/matroid.py', 'MATROID.json', ()),
    ('next_nofold/necklace.py', 'NECKLACE.json', ()),
    ('next_blind/rings.py', 'ring_results.json', ()),
    ('next_blind/spectrum.py', 'spectral_results.json', ()),
]
EXTRA = [
    ('next_boundary/three_way.py', 'three_way_results.json', ()),
    ('next_boundary/verify_boundary.py', 'large_results.json', ('--large',)),
    ('next_nofold/graphs.py', 'GRAPH_RESULTS.json', ()),
    ('next_blind/raw.py', 'raw_results.json', ()),
]

def digest(data):
    return sha256(data).hexdigest()


def check(item):
    module, filename, flags = item
    path = ROOT / module
    refpath = path.with_name(filename)
    env = dict(os.environ)
    env.pop('PYTHONPATH', None)
    env.update(PYTHONNOUSERSITE='1', PYTHONDONTWRITEBYTECODE='1',
               PYTHONOPTIMIZE='0', PYTHONHASHSEED='0')
    proc = subprocess.run([sys.executable, str(path), *flags], cwd=ROOT, env=env,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    label = ' '.join([module, *flags])
    if proc.returncode:
        raise RuntimeError(f'{label} failed: {proc.stderr.decode(errors="replace")}')
    expected = refpath.read_bytes()
    actual = json.loads(proc.stdout)
    if actual != json.loads(expected):
        raise ValueError(f'{label}: replay differs from {filename}')
    print(f'PASS  {label}', flush=True)
    return {'script': module, 'arguments': list(flags),
            'reference': str(refpath.relative_to(ROOT)),
            'script_sha256': digest(path.read_bytes()), 'reference_sha256': digest(expected)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--full', action='store_true', help='include the larger compiled-graph cases')
    parser.add_argument('--jobs', type=int, choices=(1,2), default=1,
                        help='maximum number of concurrent check processes')
    parser.add_argument('--report', type=Path, help='write a JSON replay record')
    args = parser.parse_args()
    indexed = {name for name, _, _ in QUICK + EXTRA}
    known_inputs = {str((ROOT/name).with_name(rec).relative_to(ROOT)) for name,rec,_ in QUICK + EXTRA}
    actual = {str(path.relative_to(ROOT)) for path in ROOT.glob('next_*/*.py')
              if '__main__' in path.read_text()}
    jsons = {str(path.relative_to(ROOT)) for path in ROOT.glob('next_*/*.json')}
    if actual != indexed or jsons != known_inputs:
        raise ValueError(f'replay inventory mismatch: {sorted(actual ^ indexed)}, {sorted(jsons ^ known_inputs)}')
    tests = QUICK + EXTRA if args.full else QUICK
    with ThreadPoolExecutor(max_workers=args.jobs) as pool:
        reports = list(pool.map(check, tests))
    files = sorted(path for path in ROOT.rglob('*') if path.is_file()
                   and len(path.relative_to(ROOT).parts) >= 2 and '__pycache__' not in path.parts)
    provenance = {str(path.relative_to(ROOT)): digest(path.read_bytes()) for path in files}
    result = {'full': args.full, 'checks': len(tests), 'all_match': True,
              'experiments': reports, 'input_sha256': provenance}
    if args.report:
        args.report.write_text(json.dumps(result, indent=2, sort_keys=True)+'\n')
    print(f'{len(tests)} replay checks passed.')


if __name__ == '__main__':
    main()
