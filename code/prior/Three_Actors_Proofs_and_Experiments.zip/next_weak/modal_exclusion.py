"""Stress-test seven-label modal exclusion, including its exact finite threshold."""
from collections import Counter
from itertools import combinations
from math import comb
import json

LABELS = 7


def profiles(total, labels=LABELS):
    """All ordered weak compositions, with one entry for each allowed output."""
    for separators in combinations(range(total + labels - 1), labels - 1):
        bounds = (-1,) + separators + (total + labels - 1,)
        yield tuple(bounds[i + 1] - bounds[i] - 1 for i in range(labels))


def profile_test(total):
    sizes = Counter()
    for histogram in profiles(total):
        maximum = max(histogram)
        flat = len(set(histogram)) == 1
        sizes["profiles"] += 1
        for position, hits in enumerate(histogram):
            if LABELS * hits <= total:
                sizes["eligible_true_tag_profile_pairs"] += 1
                if hits == maximum:
                    sizes["eligible_true_tag_among_modes"] += 1
                    assert flat and LABELS * hits == total
            if LABELS * hits < total:
                assert hits < maximum
    assert sizes["profiles"] == comb(total + LABELS - 1, LABELS - 1)
    assert sizes["eligible_true_tag_among_modes"] == (LABELS if total % LABELS == 0 else 0)
    return {**sizes, "views": total, "eligible_true_tag_among_modes": sizes["eligible_true_tag_among_modes"]}


def noisy_outputs(true_tag, model):
    if model == "eight":
        # An eight-view actor can output the true tag once. It emits every other
        # tag exactly once and an additional safe tag once more.
        return tuple(range(7)) + ((true_tag+1) % 7,)
    if model == "fourteen_nonflat":
        # Exactly 12/14 of the views are safe for EVERY singleton batch.
        histogram = [2] * 7
        histogram[(true_tag+1) % 7] += 1
        histogram[(true_tag+2) % 7] -= 1
        return tuple(tag for tag, count in enumerate(histogram) for _ in range(count))
    if model == "fourteen_flat":
        # This always hits 6/7, independently of which branch is actually true.
        return tuple(range(7)) * 2
    raise ValueError(model)


def batch_table(model):
    table = []
    for viable in range(128):
        live = [i for i in range(7) if viable >> i & 1]
        if len(live) == 1:
            outputs = noisy_outputs(live[0], model)
            counts = [outputs.count(i) for i in range(7)]
            table.append(max(range(7), key=lambda i:counts[i]))
        else:
            # No correctness on zero-live or multi-live groups is assumed.
            table.append(live[0] if live else 0)
    return table


def test_search(nvars, model):
    leaves = 1 << nvars
    batches = batch_table(model)
    incorrect = 0
    smallest = None
    for satisfying in range(1 << leaves):
        prefixes = [0]
        for depth in range(1, nvars+1):
            prefixes = [2 * prefix + bit for prefix in prefixes for bit in (0,1)]
            suffixes = 1 << (nvars-depth)
            low = (1 << suffixes)-1
            while len(prefixes) > 6:
                group = prefixes[:7]
                flags = sum(bool(satisfying & (low << (p * suffixes))) << i for i,p in enumerate(group))
                del prefixes[batches[flags]]
        found = any(satisfying >> p & 1 for p in prefixes)
        if found != bool(satisfying):
            incorrect += 1
            if smallest is None:
                smallest = satisfying
    return {"view_system":model, "four_variable_truth_tables":1 << leaves,
            "wrong_decisions":incorrect, "smallest_erroneous_truth_table":smallest}


def run():
    rows = [test_search(4,kind) for kind in ("eight","fourteen_nonflat","fourteen_flat")]
    assert [row["wrong_decisions"] == 0 for row in rows] == [True,True,False]
    return {"all_frequency_profiles":[profile_test(t) for t in (7,8,13,14,15,16)],
            "truth_table_tests":rows, "truth_tables_tested_per_system":65536,
            "truth_oracle":"Synthetic stress test: knows live sets only to implement adversarially admissible output counts."}


if __name__ == '__main__':
    print(json.dumps(run(),indent=2))
