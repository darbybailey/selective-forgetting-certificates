"""A single shared color can be aligned by complementing a whole NAE component."""
from collections import defaultdict
from itertools import product
from random import Random
import json
from ternary import (classify, compile_seven, connected_parts, decode_blocks, evaluate,
                     excluded, iso_map, lifted_map, one_group, read_triangles, reduce_factors,
                     relabel, scrambled_conjunction, source_pair, as_cnf)


def split_on_one(rows):
    if not rows or any(frozenset(-lit for lit in row) not in rows for row in rows):
        return None
    variables={abs(lit) for row in rows for lit in row}
    for shared in sorted(variables):
        private={row:frozenset(lit for lit in row if abs(lit)!=shared) for row in rows}
        if not all(private.values()):
            continue
        pieces=connected_parts(frozenset(private.values()))
        if len(pieces)<2:
            continue
        return [frozenset(row for row,v in private.items() if v in component)
                for component in pieces]
    return None


def actor(graph,star):
    pivot,*rest=star
    names,triangles=read_triangles(graph,pivot)
    blocks=decode_blocks(names,triangles,rest)
    reps=[];sets=[]
    for pattern in ((0,0,1),(0,1,0),(0,1,1)):
        ok,fac,_=reduce_factors(blocks,zip([names[v] for v in rest],pattern),set())
        rows=one_group(as_cnf(fac))[0] if ok else None
        if not rows or len(connected_parts(rows))!=1:return None
        parts=split_on_one(rows)
        if parts is None:return None
        group=set()
        for piece in parts:
            for j,old in enumerate(reps):
                mp,_=iso_map(piece,old)
                if mp is not None and lifted_map(piece,old,mp):
                    group.add(j)
                    break
            else:
                group.add(len(reps))
                reps.append(piece)
        sets.append(group)
    return {"all_three_residuals_connected":True,"components_per_branch":[len(s) for s in sets],
            "classes":len(reps),"excluded":excluded(sets)}


def homogenized(parts,rng):
    binary=scrambled_conjunction(parts,rng)
    ref=max(abs(x) for c in binary for x in c)+1
    rows=[]
    for c in binary:
        row=tuple(c)+(ref,)
        rows.extend([row,tuple(-v for v in row)])
    return scrambled_conjunction([rows],rng)


def main():
    bases=[source_pair(n) for n in (4,5,6,7)]
    records=[]
    for idx,(truth,control) in enumerate([(flags,False) for flags in product((0,1),repeat=4)]+[((0,1,1,1),True)]):
        rng=Random(172700+idx)
        f,g,h,i=(p[q] for p,q in zip(bases,truth))
        bf=bases[0][1] if control else f
        rows=[homogenized(p,rng) for p in ((f,g),(bf,h),(g,i))]
        # Independent exhaustive truth tests on original finite CNFs.
        mask=sum(1<<k for k,formula in enumerate(rows)
                 if any(evaluate(formula,n) for n in range(1<<max(abs(v) for c in formula for v in c))))
        sources=[[(1,),(-1,),(1,k+2)] for k in range(7)]
        for j,r in zip((0,1,3),rows):sources[j]=r
        graph=compile_seven(sources)
        graph,star=relabel(graph,[0,1,2,3],rng)
        cert=actor(graph,star)
        assert cert and cert["excluded"]==([] if control else [6]),(cert,control,idx)
        assert mask not in cert["excluded"]
        records.append({"vertices":len(graph),"edges":sum(map(len,graph))//2,"mask":mask,"certificate":cert})
    assert records[-1]["mask"]==6
    assert {r["mask"] for r in records[:-1]}==set(range(8))-{6}
    return {"graphs":records}


if __name__=="__main__":
    print(json.dumps(main(),indent=2,sort_keys=True))
