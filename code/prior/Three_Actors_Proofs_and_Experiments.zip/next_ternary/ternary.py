"""Exclude a three-branch pattern by gluing models of disjoint clause components."""
from collections import defaultdict
from itertools import product
from pathlib import Path
from random import Random
import json
import sys

root = Path(__file__).resolve().parents[1]
for directory in ('infer_new/actor', 'infer_new/quotient'):
    sys.path.insert(0, str(root / directory))
from audit import compile_seven, relabel
from quotient import as_cnf, decode_blocks, iso_map, lifted_map, one_group, read_triangles, reduce_factors


def connected_parts(rows):
    groups = []
    var_to_rows = defaultdict(set)
    for clause in rows:
        for lit in clause:
            var_to_rows[abs(lit)].add(clause)
    unseen = set(var_to_rows)
    while unseen:
        queue = [min(unseen)]
        unseen.remove(queue[0])
        clauses = set()
        for var in queue:
            for row in var_to_rows[var] - clauses:
                clauses.add(row)
                for lit in row:
                    if abs(lit) in unseen:
                        unseen.remove(abs(lit))
                        queue.append(abs(lit))
        groups.append(frozenset(clauses))
    return groups


def classify(rows, representatives):
    groups = set()
    for component in connected_parts(rows):
        for idx, rep in enumerate(representatives):
            mapping, _ = iso_map(component, rep)
            if mapping is not None and lifted_map(component, rep, mapping):
                groups.add(idx)
                break
        else:
            groups.add(len(representatives))
            representatives.append(component)
    return groups


def excluded(sets):
    impossible = []
    for mask in range(8):
        forced = set().union(*(members for i,members in enumerate(sets) if mask & (1<<i)))
        if any(members <= forced for i,members in enumerate(sets) if not mask & (1<<i)):
            impossible.append(mask)
    return impossible


def graph_reader(graph, star):
    pivot, *leaves = star
    names, triangles = read_triangles(graph, pivot)
    blocks = decode_blocks(names, triangles, leaves)
    reps = []
    sets = []
    for sig in ((0,0,1),(0,1,0),(0,1,1)):
        ok, factors, _ = reduce_factors(blocks, zip([names[v] for v in leaves],sig),set())
        reduced = one_group(as_cnf(factors))[0] if ok else None
        if reduced is None or not reduced:
            return None
        sets.append(classify(reduced, reps))
    return {"classes":len(reps),"components_per_branch":[len(s) for s in sets],
            "excluded":excluded(sets)}


def evaluate(formula, word):
    return all(any(((word>>(abs(l)-1))&1)==int(l>0) for l in c) for c in formula)


def source_pair(n):
    rng = Random(140204 + n)
    possible = [(a*sa,b*sb) for a in range(1,n+1) for b in range(a+1,n+1)
                for sa,sb in product((-1,1),repeat=2)]
    # Same variable and clause counts on the YES/NO alternatives.
    def make(want):
        for _ in range(10000):
            if want:
                eligible=[row for row in possible if evaluate([row],0)]
                rows=rng.sample(eligible,3*n)
            else:
                rows=rng.sample(possible,3*n)
            rows=frozenset(frozenset(row) for row in rows)
            signed=set.union(*(set(c) for c in rows))
            if len(signed)!=2*n or len(connected_parts(rows))!=1: continue
            if any(evaluate(rows,w) for w in range(1<<n))==want:
                return rows
        raise RuntimeError("Fixture generation exhausted")
    return [make(False),make(True)]


def scrambled_conjunction(parts,rng):
    offset=0
    formula=[]
    for part in parts:
        size=max(abs(x) for row in part for x in row)
        for row in sorted(tuple(sorted(c)) for c in part):
            formula.append([(abs(x)+offset)*(1 if x>0 else -1) for x in row])
        offset+=size
    signed=list(range(1,offset+1))
    rng.shuffle(signed)
    signed=[x*rng.choice((-1,1)) for x in signed]
    result=[]
    for row in formula:
        mapped=[signed[abs(x)-1]*(1 if x>0 else -1) for x in row]
        rng.shuffle(mapped)
        result.append(tuple(mapped))
    rng.shuffle(result)
    return result


def abstract_audit():
    tested=0
    for raw in product(range(8),repeat=3):
        sets=[{i for i in range(3) if w>>i&1} for w in raw]
        feasible={sum(1<<i for i,s in enumerate(sets) if s<=live)
                  for h in range(8) for live in [{k for k in range(3) if h>>k&1}]}
        assert set(excluded(sets))==set(range(8))-feasible
        tested+=1
    return tested


def run():
    pairs=[source_pair(n) for n in (4,5,6,7)]
    answers=[]
    for case in range(17):
        rng=Random(98807+case)
        f,g,h,i=([bool(case>>j&1) for j in range(4)] if case<16 else [False,True,True,True])
        af,ag,bh,ci=[r[x] for r,x in zip(pairs,(f,g,h,i))]
        bf=(af if case<16 else pairs[0][True])
        # The two inputs in each conjunction are assigned disjoint variable sets.
        branches=[scrambled_conjunction(x,rng) for x in ((af,ag),(bf,bh),(ag,ci))]
        truth=[any(evaluate(b,w) for w in range(1<<max(abs(x) for c in b for x in c))) for b in branches]
        mask=sum(1<<i for i,x in enumerate(truth) if x)
        sources=[[(1,),(-1,),(1,k+2)] for k in range(7)]
        for index,b in zip((0,1,3),branches): sources[index]=b
        graph=compile_seven(sources)
        graph,star=relabel(graph,[0,1,2,3],rng)
        certificate=graph_reader(graph,star)
        assert certificate and mask not in certificate["excluded"]
        answers.append({"source_truth":case,"vertices":len(graph),"edges":sum(map(len,graph))//2,
                        "true_mask":mask,"certificate":certificate})
    valid={r["true_mask"] for r in answers[:-1]}
    assert valid==set(range(8))-{6}
    assert all(r["certificate"]["excluded"]==[6] for r in answers[:-1]),answers
    assert answers[-1]["true_mask"]==6 and not answers[-1]["certificate"]["excluded"],answers[-1]
    for i,j in ((0,1),(0,2),(1,2)):
        assert {(m>>i&1,m>>j&1) for m in valid if m}==set(product((0,1),repeat=2))
    return {"abstract_set_systems_checked":abstract_audit(),"graphs":answers,
            "all_two_branch_projections_full_even_on_colorable_inputs":True}


if __name__=="__main__":
    print(json.dumps(run(),indent=2,sort_keys=True))
