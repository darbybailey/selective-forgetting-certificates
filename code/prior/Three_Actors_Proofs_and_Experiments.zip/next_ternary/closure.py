"""Exhaustive closure-system and multi-branch tests, independent of graph generation."""
from itertools import combinations
import json


def masks_of_components(supports, n):
    top=(1<<n)-1
    choices={top}
    for mask in supports:
        choices|={m&mask for m in choices}
    return choices


def monotone_mixture(patterns, n):
    top=(1<<n)-1
    inside=sorted(patterns-{0})
    image=set()
    for word in range(1<<len(inside)):
        live=[p for j,p in enumerate(inside) if (word>>j)&1]
        image.add(top if len(live)>1 else live[0] if live else 0)
    return image


def main():
    families=0;mixed=0
    for mask in range(256):
        family={w for w in range(8) if mask>>w&1}
        closed=7 in family and all(a&b in family for a in family for b in family)
        if closed:
            assert masks_of_components(sorted(family),3)==family
            families+=1
        if 0 in family and 7 in family:
            assert monotone_mixture(family,3)==family
            mixed+=1
    arities=[]
    for n in range(3,9):
        top=(1<<n)-1
        # A central conjunction of F_i, satellites F_i and H_i; one factor is
        # false at a time to make a generator for every possible intersection.
        generators=[]
        for i in range(1,n):
            generators.append(top^1^(1<<i))
            generators.append(top^(1<<i))
        family=masks_of_components(generators,n)
        assert set(range(top+1))-family=={top^1}
        colorable=family-{0}
        for skip in range(n):
            assert len({w & ~(1<<skip) for w in colorable})==2**(n-1)
        arities.append({"branches":n,"abstract_patterns":len(family),"sole_excluded":top^1})
    return {"three_bit_intersection_closed_families_containing_top":families,
            "three_bit_monotone_mixed_families_with_both_endpoints":mixed,"higher_arity":arities}


if __name__=="__main__":
    print(json.dumps(main(),indent=2))
