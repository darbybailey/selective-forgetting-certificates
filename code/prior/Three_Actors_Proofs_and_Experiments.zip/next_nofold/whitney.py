"""Recognition and exact witness transport for two-point Whitney switches."""
from collections import Counter, defaultdict
from itertools import combinations, permutations
from random import Random


def normalize(edges):
    return {frozenset(e) for e in edges}


def points(edges):
    return set().union(*edges)


def legal(parts):
    n = 3*len(parts[0])
    assert len(parts)==4
    assert all(sorted(x for e in row for x in e)==list(range(n)) for row in parts)
    pairs = [p for row in parts for e in row for p in combinations(sorted(e),2)]
    assert len(pairs)==len(set(pairs))
    return n


def random_source(n,seed):
    rng=Random(seed)
    for _ in range(1000):
        parts=[];used=set()
        for _ in range(4):
            for _ in range(3000):
                labels=list(range(n));rng.shuffle(labels)
                row=[tuple(sorted(labels[i:i+3])) for i in range(0,n,3)]
                pairs={p for e in row for p in combinations(e,2)}
                if not pairs & used:
                    parts.append(row);used|=pairs
                    break
            else:break
        if len(parts)==4:
            legal(parts)
            return parts
    raise RuntimeError('generation budget')


def glue(left,right,twist):
    """Split point 0 of each input into two common terminals."""
    a=legal(left);b=legal(right)
    data=[[] for _ in range(4)]
    for k in range(4):
        data[k].extend(tuple(v+1 if v else int(k>=2) for v in e) for e in left[k])
        # Reassign matching labels after twisting so every named matching is perfect.
        k2=(k+2*twist)%4
        data[k].extend(tuple(a+v if v else int(k2<2)^twist for v in e) for e in right[k2])
    assert legal(data)==a+b
    return data


def edges(parts):
    return normalize(e for row in parts for e in row)


def adjacency(source):
    adj={v:set() for v in points(source)}
    for e in source:
        for v in e: adj[v].update(e-{v})
    return adj


def components(adj, omit):
    pending=set(adj)-set(omit); out=[]
    while pending:
        v=min(pending);comp={v};pending.remove(v);q=[v]
        while q:
            u=q.pop()
            for w in adj[u]&pending:
                pending.remove(w);comp.add(w);q.append(w)
        out.append(comp)
    return out


def switch(source, pair, interior):
    a,b=pair
    mp={a:b,b:a}
    return {frozenset(mp.get(x,x) for x in e) if e&interior else e for e in source}


def recover_iso(a,b,initial=None):
    """Rooted color refinement with bounded backtracking; each success is checked."""
    if len(a)!=len(b) or len(points(a))!=len(points(b)):return None
    aa,bb=[{v:[e-{v} for e in z if v in e] for v in points(z)} for z in (a,b)]
    count=[5000]
    def search(c,d):
        count[0]-=1
        if count[0]<0:return None
        while True:
            rows=[]
            for adj,col in ((aa,c),(bb,d)):
                rows.append({v:(col[v],tuple(sorted(tuple(sorted(col[u] for u in edge)) for edge in star))) for v,star in adj.items()})
            tags=sorted(set(rows[0].values())|set(rows[1].values()));idx=dict(zip(tags,range(len(tags))))
            cc,dd=[{v:idx[t] for v,t in z.items()} for z in rows]
            hist=Counter(cc.values())
            if hist!=Counter(dd.values()):return None
            stable=len(set(c.values()))==len(hist)
            c,d=cc,dd
            if stable:break
        if len(hist)==len(c):
            inv={tag:v for v,tag in d.items()};mp={v:inv[t] for v,t in c.items()}
            return mp if normalize(tuple(mp[v] for v in e) for e in a)==b else None
        _,q=min((size,t) for t,size in hist.items() if size>1)
        va=min(v for v,t in c.items() if t==q)
        for vb in sorted(v for v,t in d.items() if t==q):
            r=search({**c,va:len(hist)},{**d,vb:len(hist)})
            if r is not None:return r
            if count[0]<0:break
    return search(*(initial if initial is not None else (dict.fromkeys(aa,0),dict.fromkeys(bb,0))))


def recover(a,b):
    if len(a)!=len(b) or len(points(a))!=len(points(b)):return None
    adj=adjacency(a)
    for pair in combinations(sorted(adj),2):
        parts=components(adj,pair)
        if len(parts)!=2:continue
        piece=parts[0]
        m=recover_iso(switch(a,pair,piece),b)
        if m is not None:return pair,piece,m
    return None


def hom(a,b):
    """Complete CSP. No assumption of injectivity or local injectivity."""
    aa=sorted(a,key=lambda e:tuple(sorted(e)));bb=sorted(points(b));idx=dict(zip(bb,range(len(bb))))
    domain=(1<<len(bb))-1; targets=[]
    for e in b:
        p=tuple(1<<idx[v] for v in e)
        targets.extend(permutations(p))
    av=sorted(points(a));ids=dict(zip(av,range(len(av))))
    arows=[tuple(ids[v] for v in sorted(e)) for e in aa]
    incid=[[] for _ in av]
    for i,e in enumerate(arows):
        for v in e:incid[v].append(i)
    nodes=[0]
    def dfs(ds,todo):
        nodes[0]+=1
        while todo:
            i=todo.pop(); u,v,w=arows[i];du,dv,dw=ds[u],ds[v],ds[w]
            pu=pv=pw=0
            for f,g,h in targets:
                if f&du and g&dv and h&dw:pu|=f;pv|=g;pw|=h
            if not pu:return None
            for j,p in ((u,pu),(v,pv),(w,pw)):
                if p!=ds[j]:ds[j]=p;todo.update(incid[j])
        pivots=[(d.bit_count(),j) for j,d in enumerate(ds) if d&(d-1)]
        if not pivots:return {v:bb[ds[j].bit_length()-1] for j,v in enumerate(av)}
        _,j=min(pivots); mask=ds[j]
        while mask:
            bit=mask&-mask; mask-=bit
            child=ds.copy();child[j]=bit
            r=dfs(child,set(incid[j]))
            if r is not None:return r
    result=dfs([domain]*len(av),set(range(len(aa))))
    if result is not None:assert normalize(tuple(result[v] for v in e) for e in a)<=b
    return result,nodes[0]


def defect(source,word):
    return sum(len({word>>v&1 for v in e})==1 for e in source)


def renamed(a,seed):
    r=Random(seed);old=sorted(points(a));new=old.copy();r.shuffle(new);m=dict(zip(old,new))
    return normalize(tuple(m[t] for t in e) for e in a)


def apply(word, pair, interior, mp):
    boundary=(word>>pair[0] ^ word>>pair[1])&1
    return sum((((word>>u)&1)^(boundary if u in interior else 0))<<v for u,v in mp.items())
