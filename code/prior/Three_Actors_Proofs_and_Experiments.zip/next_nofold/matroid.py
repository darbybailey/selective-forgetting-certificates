"""Convert an edge correspondence preserving binary dependencies to full-rank color transport."""
from collections import defaultdict
from itertools import combinations
from random import Random
import json
from whitney import *
from certificates import source_pair
from necklace import rank,signatures


def shadow(source):
    return {tuple(sorted((u,v))) for e in source for u,v in combinations(e,2)}


def character(edge):
    return sum(1<<u for u in edge)


def build_rows(a,b,edge_dictionary):
    """A pair of spanning forests, with all nonforest columns checked, suffices."""
    if set(edge_dictionary)!=shadow(b) or set(edge_dictionary.values())!=shadow(a):return None
    n=len(points(a))
    if points(a)!=set(range(n)) or points(b)!=set(range(n)):raise ValueError('consecutive labels required')
    # Dictionary maps target characters to source characters; extend it linearly.
    pivots={}
    def reduce(c,d):
        while c and c.bit_length() in pivots:
            f,g=pivots[c.bit_length()];c^=f;d^=g
        return c,d
    for q,p in sorted(edge_dictionary.items()):
        c,d=reduce(character(q),character(p))
        if c:pivots[c.bit_length()]=c,d
        elif d:return None
    image=[d for c,d in pivots.values()]
    if rank(image)!=len(image):return None
    # Complete both independent sets to ambient bases, also for disconnected shadows.
    unused=[1<<j for j in range(n)]
    for j in range(n):
        c,d=reduce(1<<j,0)
        if c:
            h=next(h for h in unused if rank(image+[h])>len(image))
            unused.remove(h);image.append(h);pivots[c.bit_length()]=c,h
    rows={}
    for j in range(n):
        c,d=reduce(1<<j,0)
        assert c==0
        rows[j]=d
    assert rank(rows.values())==n
    assert all(rows[u]^rows[v]==character(e) for (u,v),e in edge_dictionary.items())
    return rows


def number_models(a):
    masks=[character(e) for e in a]
    return sum(all(w&q not in (0,q) for q in masks) for w in range(1<<len(points(a))))


def short_circuits(a):
    adj=adjacency(a)
    return sum(len(adj[u]&adj[v]) for u,v in shadow(a))//3


def run():
    a,b=source_pair()
    a=renamed(a,66);b=renamed(b,77)
    pair,inside,mp=recover(a,b)
    forms={mp[v]:(1<<v)^((1<<pair[0])^(1<<pair[1]) if v in inside else 0) for v in points(a)}
    original_edges={character(p):p for p in shadow(a)}
    dic={q:original_edges[forms[q[0]]^forms[q[1]]] for q in shadow(b)}
    result=build_rows(a,b,dic)
    assert signatures(a,{v:1<<v for v in points(a)})==signatures(b,result)
    bad=None
    for u,v in combinations(sorted(dic),2):
        changed=dic.copy();changed[u],changed[v]=changed[v],changed[u]
        if build_rows(a,b,changed) is None:bad=[u,v];break
    assert bad
    seen={}
    for i in range(120):
        z=edges(random_source(15,714+i))
        count=number_models(z);triangles=short_circuits(z)
        if count and count in seen and triangles!=seen[count][1]:
            p,t=seen[count]
            control={'vertices':15,'triples':20,'exact_colorings_of_each':count,'generator_seeds':[p,714+i],
                     'three_element_circuits_in_point_shadows':[t,triangles],'invertible_linear_energy_equality':False}
            break
        seen[count]=(714+i,triangles)
    else:raise RuntimeError('no matched control')
    return {'pair_character_bijection_size':len(dic),'transport_rank_reconstructed':rank(result.values()),
            'all_character_multiplicities_agree':True,'corrupted_edge_bijection_rejected':bad,'same_model_count_control':control}
if __name__=='__main__':print(json.dumps(run(),indent=2))
