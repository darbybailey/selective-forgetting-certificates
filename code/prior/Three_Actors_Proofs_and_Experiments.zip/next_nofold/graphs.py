"""Only the final marked graph is passed to the equality recognizer."""
from pathlib import Path
import json,sys
from random import Random
from whitney import recover
from certificates import source_pair
root=Path(__file__).resolve().parents[1]
for sub in ('experiment_regular','infer_new/actor','infer_new/quotient','frontier2_quotient','frontier2_covers'):
    sys.path.append(str(root/sub))
from audit import compile_seven,relabel
from quotient import as_cnf,decode_blocks,read_triangles,reduce_factors,one_group
from kernel import ungauge
from near_obstruction import ring,edges_of


def encoding(es,rng):
    vs=sorted(set().union(*es));labels=list(range(1,len(vs)+1));rng.shuffle(labels)
    ids={v:a*rng.choice([1,-1]) for v,a in zip(vs,labels)}
    cnf=[]
    for e in sorted(tuple(sorted(e)) for e in es):
        row=tuple(ids[v] for v in e)
        cnf += [row,tuple(-v for v in row)]
    rng.shuffle(cnf)
    return cnf


def infer(graph,marks):
    p,*leaf=marks
    names,tri=read_triangles(graph,p); blocks=decode_blocks(names,tri,leaf)
    src=[]
    for pat in ((0,0,1),(0,1,0),(0,1,1)):
        ok,fs,_=reduce_factors(blocks,zip([names[v] for v in leaf],pat),set())
        src.append(None)
        if ok:
            rows=one_group(as_cnf(fs))[0]
            if rows:
                q=ungauge(rows)
                if q:src[-1]=q[0]
    for i in range(3):
        for j in range(i+1,3):
            if src[i] is not None and src[j] is not None:
                cert=recover(src[i],src[j])
                if cert is not None:
                    p,inside,mp=cert
                    return {'branches':[i,j],'false_pattern':1<<i,'verified_mapped_points':len(mp),
                            'two_terminal_separator':list(p),'side_size':len(inside)}
    return None


def test():
    out=[]
    for k,neg in enumerate((False,True)):
        a,b=source_pair()
        if neg:b=edges_of(ring(3,False)[0])
        rng=Random(27614+k)
        src=[[(1,),(-1,),(1,2+i)] for i in range(7)]
        src[0],src[1]=encoding(a,rng),encoding(b,rng)
        g=compile_seven(src);g,stars=relabel(g,[0,1,2,3],rng)
        cert=infer(g,stars)
        assert (cert is None) if neg else cert['false_pattern']==1
        out.append({'same_size_control':neg,'true_mask':1 if neg else 3,'vertices':len(g),
                    'edges':sum(map(len,g))//2,'actor':cert})
    return out
if __name__=='__main__':print(json.dumps(test(),indent=2))
