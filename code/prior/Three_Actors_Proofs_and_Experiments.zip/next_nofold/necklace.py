"""Combine arbitrarily many two-point shears and certify the complete Boolean energy function."""
from collections import Counter
from itertools import combinations
from random import Random
import json
from whitney import *


def join(pieces,orientation):
    m=len(pieces)
    labels=[{} for _ in pieces];n=2*(m-1)
    for i,P in enumerate(pieces):
        for v in range(legal(P)):
            if (i>0 and v==0) or (i+1<m and v==1):continue
            labels[i][v]=n;n+=1
    phase=0;out=[[] for _ in range(4)]
    for i,P in enumerate(pieces):
        if i:phase^=orientation[i-1]
        for k in range(4):
            def lift(v):
                if i>0 and v==0:return 2*(i-1)+(int(k<2)^orientation[i-1])
                if i+1<m and v==1:return 2*i+int(k>=2)
                return labels[i][v]
            out[(k+2*phase)%4].extend(tuple(lift(v) for v in e) for e in P[k])
    assert legal(out)==n
    return edges(out)


def decompose(es):
    adj=adjacency(es)
    sep=[p for p in combinations(sorted(adj),2) if len(components(adj,p))>1]
    if not sep or len(set().union(*sep))!=2*len(sep):return None
    left=components(adj,set().union(*sep))
    slabs=[]
    for comp in left:
        piece={e for e in es if e&comp}; terms=points(piece)-comp
        boundaries=[s for s in sep if set(s)<=terms]
        if len(boundaries) not in (1,2) or set().union(*boundaries)!=terms:return None
        slabs.append((piece,boundaries))
    if Counter(e for piece,_ in slabs for e in piece)!=Counter(es):return None
    if not all(sum(s in links for _,links in slabs)==2 for s in sep):return None
    tips=[i for i,(_,links) in enumerate(slabs) if len(links)==1]
    if len(tips)!=2:return None
    order=[];seams=[];i=tips[0];prev=None
    while i not in order:
        order.append(i)
        nxt=[s for s in slabs[i][1] if s!=prev]
        if not nxt:break
        prev=nxt[0];seams.append(prev)
        i=next(j for j,(_,links) in enumerate(slabs) if j!=i and prev in links)
    if len(order)!=len(slabs) or len(seams)!=len(order)-1:return None
    return [slabs[i][0] for i in order],seams


def colored(es,seams,i):
    row=dict.fromkeys(points(es),0)
    if i:row.update(dict.fromkeys(seams[i-1],1))
    if i<len(seams):row.update(dict.fromkeys(seams[i],2))
    return row


def rank(rows):
    pivots={}
    for r in rows:
        while r:
            v=r.bit_length()-1
            if v in pivots:r^=pivots[v]
            else:pivots[v]=r;break
    return len(pivots)


def signatures(es,forms):
    return Counter(forms[u]^forms[v] for e in es for u,v in combinations(e,2))


def recognition(A,B):
    a,b=decompose(A),decompose(B)
    if not a or not b or len(a[0])!=len(b[0]):return None
    blocks,seams=a
    for br,sr in ((b[0],b[1]),(b[0][::-1],b[1][::-1])):
        forms={};ok=True
        for i,(x,y) in enumerate(zip(blocks,br)):
            mp=recover_iso(x,y,(colored(x,seams,i),colored(y,sr,i)))
            if not mp:ok=False;break
            phase=0
            if i:
                c,d=seams[i-1]
                phase=forms[mp[c]]^(1<<c)
                if phase!=forms[mp[d]]^(1<<d):ok=False;break
            forms.update({v:(1<<u)^phase for u,v in mp.items()})
        if ok:
            assert rank(forms.values())==len(points(A))
            assert signatures(A,{v:1<<v for v in points(A)})==signatures(B,forms)
            return forms,len(seams)
    return None


def run():
    rng=Random(224183)
    beads=[random_source(s,493+i) for i,s in enumerate([12,15,18,15,12,18,15,12,15])]
    records=[]
    for m,word in [(3,[1,1]),(6,[1,0,1,0,1]),(9,[0,1,1,0,1,0,1,1])]:
        a=renamed(join(beads[:m],[0]*(m-1)),9371+m)
        b=renamed(join(beads[:m],word),9317+m)
        result=recognition(a,b)
        assert result is not None
        forms,k=result
        for _ in range(128):
            w=rng.getrandbits(len(forms))
            image=sum(((w&mask).bit_count()%2)<<v for v,mask in forms.items())
            assert defect(a,w)==defect(b,image)
        records.append({'beads':m,'discovered_separators':k,'input_switches':sum(word),'vertices':len(forms),
                        'triples':len(a),'transport_rank':rank(forms.values()),
                        'max_number_of_inputs_in_one_output_bit':max(mask.bit_count() for mask in forms.values()),
                        'full_shadow_character_multisets_equal':True,'checked_words':128})
    return records

if __name__=='__main__':print(json.dumps(run(),indent=2))
