from collections import Counter
from itertools import product
from pathlib import Path
import json,sys
from whitney import *


def second_hom(a,b):
    """Independent exhaustive enumeration. Two assigned points force the third on a linear target."""
    vertices=points(a)
    forced={}
    badj=adjacency(b)
    for e in b:
        for u,v,w in permutations(e):forced[u,v]=w
    adj=adjacency(a)
    triples=sorted(tuple(sorted(e)) for e in a); visits=[0]
    def search(d):
        visits[0]+=1
        while True:
            old=len(d)
            for e in triples:
                assigned=[u for u in e if u in d]
                if len(assigned)>=2:
                    u,v=assigned[:2]; w=next(t for t in e if t not in (u,v))
                    p=forced.get((d[u],d[v]))
                    if p is None or (w in d and d[w]!=p):return False
                    d[w]=p
            if old==len(d):break
        if len(d)==len(vertices):return True
        choices=[]
        for v in sorted(vertices-d.keys()):
            poss=set(badj)
            for u in adj[v]&d.keys():poss.intersection_update(badj[d[u]])
            choices.append((len(poss),v,poss))
        _,v,poss=min(choices)
        return any(search({**d,v:w}) for w in sorted(poss))
    exists=search({})
    return exists,visits[0]


def profile(es,pair,inter):
    occupied=sorted(set(pair)|inter);idx=dict(zip(occupied,range(len(occupied))))
    masks=[sum(1<<idx[v] for v in e) for e in es if e&inter]
    i,j=(idx[v] for v in pair)
    out=Counter()
    for word in range(1<<len(occupied)):
        if all(0 < word&mask <mask for mask in masks):out[((word>>i)&1,(word>>j)&1)]+=1
    return [out[a,b] for a,b in product(range(2),repeat=2)]


def source_pair(ls=41,rs=61):
    x=random_source(12,ls);y=random_source(15,rs)
    return edges(glue(x,y,False)),edges(glue(x,y,True))


def run():
    rec=[]
    for i,(l,r) in enumerate([(41,61),(42,45),(39,22),(17,108)]):
        a,b=source_pair(l,r)
        A=renamed(a,66+i);B=renamed(b,77+i)
        p,front,m=recover(A,B)
        for way,order in [('forward',(A,B)),('backward',(B,A))]:
            mp,nodes=hom(*order)
            exist,independent_nodes=second_hom(*order)
            assert not exist and mp is None
            if way=='forward':checks={}
            checks[way]=[nodes,independent_nodes]
        parts=components(adjacency(A),p)
        prof=[profile(A,p,k) for k in parts]
        n=sum(x*y for x,y in zip(*prof))
        p2=[m[v] for v in p]
        prof2=[profile(B,p2,k) for k in components(adjacency(B),p2)]
        assert n==sum(x*y for x,y in zip(*prof2)) and n>0
        # Deterministic per-row check for every extension. Constraints have at most five source bits.
        assignments=0
        for e in A:
            mapped=frozenset(m[(p[1] if v==p[0] else p[0]) if (v in p and e&front) else v] for v in e)
            assert mapped in B
            pts=sorted(set(e)|set(p))
            for bits in product((0,1),repeat=len(pts)):
                word=sum(1<<v for v,x in zip(pts,bits) if x)
                assert defect([e],word)==defect([mapped],apply(word,p,front,m))
                assignments+=1
        rec.append({'seeds':[l,r],'vertices':27,'triples':36,'connected':len(components(adjacency(A),()))==1,
                    'exact_models_each':n,'hom_exists_either_direction':False,'two_independent_no_hom_search_nodes':checks,
                    'exhaustive_local_shear_cases':assignments,'terminal_profiles':prof})
    return rec

if __name__=='__main__':print(json.dumps(run(),indent=2))
