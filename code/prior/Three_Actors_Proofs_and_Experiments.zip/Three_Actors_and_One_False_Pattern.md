# A distinction visible only to three actors

**Branch certificates beyond graph folds**  
Working note · November 23, 2026

A graph encodes three possible choices at a designated vertex. A choice is viable if some proper coloring realizes it. An actor tries to discard one incorrect description of which choices are viable. Is there anything it can learn jointly that every comparison of two choices misses?

**Yes, on an explicit family.** Each pair of branch answers realizes all four true/false combinations, even when the graph is promised colorable. Yet one three-branch pattern is impossible. If B and C both work, A must work. On shuffled graphs with 11,645 vertices, an actor recovered that implication from adjacency and the four designated vertices. A matched control really did have only B and C viable. The actor abstained there. This is a precise version of the intuition behind the Borromean analogy. For the separate extremal result below, four matchings partition V binary points into triples that must use both colors. No point pair repeats.

| Finding | Scope |
|---|---|
| A witness of B and a witness of C can jointly certify A. | The actor verifies the shared pieces and how to join them. The three branches can all be connected. |
| Some branch relationships survive even when no ordinary hypergraph map exists. | A change of coordinates transports witnesses. A cycle-matroid criterion recognizes a complete class of such maps. |
| At most 5V/12 affine parameters can vary freely. | Connected examples attain the bound. Deciding whether an instance comes within √V of it is NP-complete. |
| Several unreliable answers could suffice. | A uniform eight-view actor permitted one mistake per sole-live batch would imply P=NP. The required uniform guarantee is open. |

**Audit of the preceding note.** The released archive for *How much does one defect reveal?* runs 27 checks by default and adds six with the full option. All 33 passed a fresh replay from that archive. Its 24 reconstructed peak-two paths are separate from its 282 stress-test paths, for 306 total. The 24 cover three selected starts on each of eight fixtures. The 282 cover every listed start on 46 further fixtures. The universal quantifier in the theorem is established by the proof. The earlier abstract already identifies its promises and the open uniform case.

## The three-way witness argument

Let F, G, H and I be independently chosen Boolean constraint systems. Build three branches whose viability bits are

    A = F AND G       B = F AND H       C = G AND I.

Here F in the equation means “F has a solution,” and likewise for the other systems. Each occurrence may be independently relabeled. Within a branch the pieces initially use disjoint variable sets. A B-witness supplies a solution of F. A C-witness supplies a solution of G. Those two assignments together solve A. No single component has to occur in all three branches.

**Sharpness.** If F and G are both viable, A works and H and I can set the answers for B and C arbitrarily. If A fails, the possibilities for B,C are 00, 01 and 10. Exactly one full pattern is missing. Even after removing the all-false row to enforce colorability, every pair of branch answers occurs with all four truth values. Consequently no binary implication among the branch statuses accounts for the missing pattern.

**What the reader checks.** Decode the three residual formulas and enumerate their variable-connected components. Two components receive a shared name only after a signed variable map carries their whole clause sets onto each other. For the connected variant, check that every piece is invariant under flipping all its bits and that its only shared variable is one color reference. Either local coloring can then be flipped to align the reference. No satisfying assignment is required to check this gluing argument.

| Tests using actual compiler graphs | Observations |
|---|---|
| 17 shuffled graphs, 3,455 vertices / 6,264 edges each | All 16 hidden-status configurations excluded only the pattern “B and C alone.” In the seventeenth graph that pattern was true and the reader abstained. |
| 17 shuffled graphs, 11,645 vertices / 21,060 edges each | The same experiment with three connected residuals gave the same exclusions and correct abstention. |
| Independent ground truth | Exhaustive evaluation of the generated source formulas, performed separately from the graph reader, checked each viable-set mask. |

The finite examples use easy payloads to permit independent ground truth. The gluing theorem allows the disjoint payloads themselves to encode arbitrary SAT instances. The common structure that matters is which witnesses can be joined.

## Exactly what component information reveals

Suppose branch j requires solutions of all component types in a set S_j. For a proposed viable set P, collect every type required by any branch in P. Call that union U. The actor can exclude P whenever a branch outside P has all its required types in U. This is sound whenever the proposed identifications and gluing conditions are certified.

It is also complete for the abstract information given. If every excluded branch has a required type outside U, assign exactly the types in U the status “viable.” This assignment realizes P. Actual formulas may support extra inferences. The abstract converse identifies the point at which an actor must inspect additional information.

**All arities.** With one central branch requiring every Fᵢ and satellite i requiring Fᵢ and Hᵢ, the only missing full pattern has every satellite viable and the center impossible. For three or more branches, every proper projection remains full on nonempty outcomes. The replay checks arities three through eight. The general proof follows by choosing the independent statuses directly.

**Algebra of the possible answers.** Each unsatisfiable component removes all branches requiring it. Multiple failures take intersections of the remaining sets. Conversely, every intersection-closed family containing the all-viable set can be represented this way. Introduce one factor for each allowed mask and place it in exactly the branches that the mask omits. On three branches there are 61 such families. This is an application of the classical Horn/intersection correspondence. [Dechter and Pearl](https://ftp.cs.ucla.edu/pub/stat_ser/r172-reprint.pdf)

A different rule applies to alternatives within a branch. If a shared context can realize a set of boundary states, a branch is viable when its allowed states intersect that set. In the two-pin test, one seven-point piece permits only equal pins while its replacement permits equal or unequal pins. An actor detected the resulting strict implication on a 330,799-vertex graph. On the underlying 13-point systems the solution counts were zero and 60. The reversed, same-size control forced abstention. This permits two independent SAT payloads to have branch bits f and f OR g. A separate three-pin experiment and its colorability-promise qualification are in the archive.

## Witnesses can travel without a fold

A two-terminal twist interchanges two shared variables on one side of a separation. For a coloring x, add xₛ XOR xₜ to every private bit on that side. When the terminals agree, the private coloring stays fixed. When they differ, complementing the private coloring aligns it with the interchanged terminals. This invertible linear transformation preserves each corresponding triple's satisfied or violated status. On a shuffled 9,319-vertex graph the actor recovered an exclusion this way. Both 27-point branches had 240 colorings. Exhaustive independent searches established that there was no ordinary hypergraph homomorphism in either direction.

**How far linear comparison goes.** For a linear four-matching system let D(x) count defective triples and form the graph shadow by joining points that share a triple. For each triple, four times its defect indicator is one plus the three signed pair products. Consequently D is determined by the binary characters corresponding to the shadow edges. An invertible binary linear change of variables preserves D on every assignment exactly when the cycle matroids of the two shadows are isomorphic. The character lists must match, and their dependencies over the two-element field are precisely the even edge sets. The same classification covers every homogeneous linear map that never increases D on equal-order connected inputs, even if the map may be singular. Averaging over a uniform assignment forces any such pointwise inequality to be equality.

The shadows have bounded degree, so the matroid test is polynomial by Rao and Sarma. The implementation validates explicit transports and counterexamples. One pair has 50 solutions per branch but different numbers of three-edge circuits, 71 and 68, ruling out this entire class of transports. A complete implementation of the published matroid-isomorphism algorithm is outside these tests. [Rao and Sarma, Corollary 6.3](https://www.cse.iitm.ac.in/~bvrr/jour/RS1.pdf)

**What changes with an affine offset.** Given a known solution of A, finding whether some rank-one affine map can ensure D_B(Tx) ≤ D_A(x) on every input is already equivalent to deciding B. If B has a witness w, the map x ↦ w XOR (x₁ times the all-ones vector) always outputs w or its complement. The converse follows by evaluating T on the known A-witness. Hardness persists on compiled instances even at rank at least 2V/9+1. The checker symbolically verified whole affine spaces of dimensions 73 and 217 on 324 and 972 points. The appendix gives disjoint and connected near-full-rank versions under explicit promises.

## How many choices can be forgotten together?

Call a set of satisfying colorings an affine flat of dimension d if it is a translate of a binary linear subspace of that dimension. Once the affine rule is known, all 2ᵈ settings of its d parameters are safe. The original variables can be correlated; these parameters need not be individually free original variables.

**Sharp bound.** For any linear system of four perfect matchings on V points, a flat consisting entirely of satisfying colorings has dimension at most 5V/12. For every positive integer b there exists a connected system on 12b points attaining dimension 5b exactly.

**Proof.** On a triple with values x,y,z, the affine image of the pair of differences (x XOR y, x XOR z) avoids (0,0). Every nonempty affine subset of the binary plane avoiding the origin has a nonzero linear form identically one. Thus some pair in this triple is permanently opposite on the flat. Choose one such pair per triple. The chosen edges form a simple bipartite graph of maximum degree four. Requiring opposite colors on its edges leaves one free bit per connected component, including isolated points. Conversely, any bipartite choice of one pair per triple produces a satisfying flat of exactly that dimension.

There are 4V/3 chosen edges. A connected component on s points has at most min(⌊s²/4⌋,2s) edges, at most 16(s−1)/7 for s≥2. Adding over all components gives at most 5V/12 components. Equality comes from disjoint selected copies of the complete bipartite graph on four plus four points, with the remaining vertices isolated in the selected graph. The unselected incidences connect the original hypergraph. In a connected 300-point example the replay verifies all 400 triples simultaneously on a 125-dimensional flat.

**Knowing that much freedom exists can still be hard.** On connected inputs it is NP-complete to decide whether there is a satisfying flat of dimension at least ⌈5V/12−√V⌉. Membership follows by naming the opposite pair in every triple and counting the components. For hardness, attach a large connected extremal system to a 3-SAT encoding through a redundant triple. Its selected pair remains opposite, so all of the padding's free parameters survive a YES instance. Removing the redundant triple leaves every NO encoding unsatisfiable. The threshold is within √V of the universal upper bound. The proof leaves the decision complexity at exact equality open here.

## The information that local views lose

Make a ring of k nine-point pieces. Consecutive pieces transmit a Boolean phase, either unchanged or reversed. An even number of reversals permits exactly 2·6ᵏ perfect colorings. An odd number permits none. On a proper interval of the ring the signs can be removed by independently switching the local phase conventions. The obstruction is the sign accumulated around a closed circuit.

**A sharp threshold.** Every rooted neighborhood through radius k−1 has the same structure in the even and odd systems, even when the four matchings are distinguished. At radius k their rooted-neighborhood multisets differ. In a 297-point pair, a radius-32 neighborhood can contain 288 points and still conceal the parity. The actor can recover the sign by following the wires around the circle; a supplied coloring or relationship to another branch is unnecessary.

There is also a test using just the adjacency matrix of each point graph. Its first distinguishing count of closed walks occurs at length 2k. The even system has k·2^(k+3) additional closed walks of that length. A path around the unwrapped chain must gain height 2k to wind once. Shorter closed walks therefore have matching lifts. At the minimum winding length each crossing fixes the order of a wire step and an internal step. Two local port choices per turn give the stated difference. Full counting and rooted-view proofs are in the archive.

**Original graph control.** Eight independently shuffled compiler graphs, each with 50,883 vertices and 92,040 edges, realized all eight masks, including an uncolorable control. Ordinary one-dimensional color refinement from four individually marked star vertices produced identical signatures through stabilization on all eight. Exact graph decoding followed by the parity calculation recovered all eight answers. This rules out one precise class of summaries. The source-neighborhood radius and point-graph walk formulas concern the decoded systems; the raw-graph color-refinement result is a separate test and proof.

## A weaker target that would still decide SAT

Tag seven partial SAT assignments and compile three questions about their possible completions. When exactly one tag has any completion, the three answers encode that tag. If several tags have completions, removing any one leaves another. A sound deletion in each seven-way batch keeps at most six candidates after each pruning step. Repeating after each variable split and verifying final witnesses decides SAT. This is the setting in which the original project asks for one false nonempty pattern. [Membership comparability](https://doi.org/10.1137/S0097539793258131)

**Eight views.** A deterministic actor may instead return eight guesses, one per efficiently constructed presentation, translated back to the same seven tag names. Suppose that whenever a batch has a sole live tag, at most one guess names it. Some name is repeated. Delete a most frequent name: it occurs at least twice, so the sole live branch survives. Multi-live and all-dead batches need no accuracy promise. The guarantee is per batch and covers all satisfiable source formulas, including branches with many witnesses. Proving it for one uniform polynomial-time rule would imply P=NP.

For a randomized actor, any inverse-polynomial advantage over the blind 6/7 success probability on every sole-live batch suffices for RP=NP. Estimate output frequencies to within less than half the advantage and remove an empirically most frequent name. Polynomially many fresh samples keep the total chance of mistakenly removing a sole survivor below one half over the full search. Final witness verification excludes false positives. Conversely, if NP=RP, repeated one-sided decision procedures can certify a viable choice with arbitrarily high constant success. Tiny advantages already occur unconditionally: sampling a random full coloring occasionally finds a directly verifiable solution. An exponentially small advantage gives no polynomial sampling bound by this reasoning.

**Where this leaves the research.** The three-way rule proves that pairwise comparisons can miss the only safe exclusion available from a specified structure. The weak-actor criterion gives a measurable next target on instances with independent, unrecognized payloads. The simulations of noisy responses are synthetic. No tested method supplies the required per-batch guarantee. P versus NP remains open, and priority of these particular combined results has not been established. [Clay Mathematics Institute](https://www.claymath.org/millennium/p-vs-np/)
