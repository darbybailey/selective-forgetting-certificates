"""Graph-only actor tests. Only the audit/compiler are allowed source labels."""
from itertools import combinations, product
import json
from pathlib import Path
from random import Random
import sys
from elimination import YES, NO, UNKNOWN, audit_star, decide, excluded_pattern

HERE = Path(__file__).resolve().parent
# The release includes the unmodified graph compiler and Boolean encoder.
for path in [HERE.parent/'baseline', HERE.parents[1]/'next_global']:
    if (path/'compiler'/'three_star'/'three_star.py').is_file():
        sys.path.insert(0,str(path/'compiler'/'three_star'))
        sys.path.insert(0,str(path/'pruning'))
        break
from three_star import make_star
from ruled_out import bit_questions, combined_code

SEED = 418001
CAP = 10
PRIOR = [(), *((i,) for i in range(1,8)), (1,2), (1,2,4), (3,5), (1,2,3,4,5,6,7)]


def compile_seven(formulas):
    return make_star([f for f,_ in bit_questions(formulas)])


def relabel(graph, terminals, rand):
    p=list(range(len(graph)))
    rand.shuffle(p)
    result = [set() for _ in graph]
    for v,neighbors in enumerate(graph):
        result[p[v]] = {p[w] for w in neighbors}
    return result, [p[v] for v in terminals]


def exhaustive_graphs():
    edges = list(combinations(range(5),2))
    checks = excl = 0
    for mask in range(1<<len(edges)):
        g = [set() for _ in range(5)]
        for i,(x,y) in enumerate(edges):
            if mask&(1<<i):
                g[x].add(y)
                g[y].add(x)
        if not {1,2,3} <= g[0]:
            continue
        models = [xs for xs in product(range(3),repeat=5)
                  if all(xs[x] != xs[y] for x,y in edges if y in g[x])]
        answers, _ = audit_star(g,0,(1,2,3),CAP)
        truth = [any(xs[x] == xs[y] for xs in models) for x,y in combinations((1,2,3),2)]
        assert [YES if bit else NO for bit in truth] == answers
        for expected,(u,v) in zip(answers,combinations((1,2,3),2)):
            assert decide(g,{0:2,u:0,v:0},4,dfs_order=True)[0] == expected
        mask = sum(1<<i for i,bit in enumerate(truth) if bit)
        assert excluded_pattern(answers) != mask
        checks += 3
        excl += 1
    return {'candidates':checks,'graphs':excl}


def table():
    rng=Random(SEED)
    prior_cases = set(PRIOR)
    candidate_checks = prior_checks = max_width = unknown = viable_graphs = 0
    hist = {}
    prior_rows = []
    for coords in product((False,True),repeat=7):
        live=tuple(i for i in range(1,8) if coords[i-1])
        formulas=[[(1,)] if ok else [(1,),(-1,)] for ok in coords]
        graph = compile_seven(formulas)
        target = combined_code(coords)
        trials = 4 if live in prior_cases else 2
        for trial in range(trials):
            g,(pivot,*leaves) = (graph, [0,1,2,3]) if trial==0 else relabel(graph,range(4),rng)
            answers, widths = audit_star(g,pivot,leaves,CAP)
            expected = [YES if target&(1<<i) else NO for i in range(3)]
            assert answers == expected, (live, trial, answers, expected)
            assert excluded_pattern(answers) != target
            for w in widths:
                hist[w]=hist.get(w,0)+1
            if live in prior_cases:
                prior_checks+=len(answers)
                if trial==0:
                    prior_rows.append({'live':list(live),'vertices':len(g),'answers':answers,'widths':widths})
            candidate_checks += len(answers)
            max_width=max(max_width,*widths)
            unknown+=answers.count(UNKNOWN)
            viable_graphs+=bool(target)
    return {'seed':SEED,'cap':CAP,'truth_configurations':128,
            'presentations':candidate_checks//3,'colorable_presentations':viable_graphs,
            'pair_decisions':candidate_checks,'unknown_pairs':unknown,
            'prior_graphs':len(prior_rows),'prior_presentations':prior_checks//3,
            'prior_pair_decisions':prior_checks,'max_width':max_width,
            'width_counts':hist, 'prior_canonical_rows':prior_rows}


def unlimited_unit_controls():
    rows=[]
    for n in [2,5,12]:
        sources=[]
        target=0
        for i in range(1,8):
            units=[((v if (v+i)%2==0 else -v),) for v in range(1,n+1)]*2
            if i in (2,6):
                target |= i
            else:
                units.append((-units[0][0],))
            sources.append(units)
        g=compile_seven(sources)
        answers,widths=audit_star(g,0,(1,2,3),CAP)
        assert answers == [YES if target&(1<<i) else NO for i in range(3)]
        rows.append({'source_variables':n,'vertices':len(g),'widths':widths,'answers':answers})
    return rows


def high_width_controls():
    sizes = [3,4,5,12]
    rows = []
    for t in sizes:
        source=[(i,j) for i,j in combinations(range(1,t+1),2)]
        graph=compile_seven([source]*7)
        cap = t-2
        answers,widths=audit_star(graph,0,(1,2,3),cap)
        assert answers == [UNKNOWN]*3
        rows.append({'variables_per_source':t,'vertices':len(graph),
                     'cap':cap,'outcomes':answers,'processed_widths':widths})
    return rows


if __name__=='__main__':
    print(json.dumps({'truth_table':exhaustive_graphs(),'compiled':table(),
                      'larger_signed_unit_sources':unlimited_unit_controls(),
                      'arbitrary_cap_controls':high_width_controls()},indent=2,sort_keys=True))
