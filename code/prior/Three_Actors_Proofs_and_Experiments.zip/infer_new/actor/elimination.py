"""Capped exact variable elimination for three-color queries on a graph."""
from heapq import heapify, heappop, heappush
from itertools import combinations, product

YES, NO, UNKNOWN = "yes", "no", "unknown"


def decide(graph, pins, cap, *, dfs_order=False):
    """Take only the graph, pinned colors and a fixed nonnegative width cap.

    Return (status, full coloring on YES, largest bucket scope after projection).
    """
    if cap < 0:
        raise ValueError("negative width cap")
    if any(v in graph[v] for v in range(len(graph))):
        return NO, None, 0
    if any(pins.get(w) == c for v, c in pins.items() for w in graph[v]):
        return NO, None, 0
    available = {v: tuple(c for c in range(3)
                          if all(pins.get(w) != c for w in graph[v]))
                 for v in range(len(graph)) if v not in pins}
    if any(not domain for domain in available.values()):
        return NO, None, 0
    adj = {v: {w for w in graph[v] if w in available} for v in available}
    incident = {v: set() for v in adj}
    factors = {}
    fresh = 0

    def store(scope, allowed):
        nonlocal fresh
        idx = fresh
        fresh += 1
        factors[idx] = scope, allowed
        for x in scope:
            incident[x].add(idx)

    for x in adj:
        for y in adj[x]:
            if x < y:
                store((x, y), {(a,b) for a in available[x]
                               for b in available[y] if a != b})
    trail = []
    priority = None
    if dfs_order:
        priority = iter(_dfs_postorder(adj))
    queue = [(len(neighbors), v) for v,neighbors in adj.items()]
    heapify(queue)
    width = 0
    while adj:
        if priority is not None:
            v = next(priority)
        else:
            while True:
                degree, v = heappop(queue)
                if v in adj and degree == len(adj[v]):
                    break
        ns = tuple(sorted(adj[v]))
        if len(ns) > cap:
            return UNKNOWN, None, width
        width = max(width, len(ns))
        index = {w:i for i,w in enumerate((v,)+ns)}
        checks = []
        for idx in sorted(incident[v]):
            scope, allowed = factors.pop(idx)
            checks.append((tuple(index[w] for w in scope), allowed))
            for w in scope:
                if w != v:
                    incident[w].remove(idx)
        del incident[v]
        extensions = {}
        for colors in product(*(available[w] for w in ns)):
            for c in available[v]:
                row = (c,) + colors
                if all(tuple(row[i] for i in ix) in allowed
                       for ix, allowed in checks):
                    extensions[colors] = c
                    break
        if not extensions:
            return NO, None, width
        trail.append((v, ns, extensions))
        if ns:
            store(ns, extensions.keys())
        for x in ns:
            adj[x].remove(v)
        for x,y in combinations(ns,2):
            adj[x].add(y)
            adj[y].add(x)
        if priority is None:
            for x in ns:
                heappush(queue, (len(adj[x]),x))
        del adj[v]
    model = dict(pins)
    for v,ns,extensions in reversed(trail):
        model[v] = extensions[tuple(model[w] for w in ns)]
    colors = tuple(model[v] for v in range(len(graph)))
    assert all(colors[v] != colors[w] for v in range(len(graph)) for w in graph[v])
    return YES, colors, width


def _dfs_postorder(adj):
    # Iterators reproduce recursive DFS, so every undirected edge has
    # comparable ancestor/descendant endpoints in the resulting forest.
    output = []
    seen = set()
    for root in sorted(adj):
        if root in seen:
            continue
        seen.add(root)
        stack = [(root, iter(sorted(adj[root])))]
        while stack:
            v, cursor = stack[-1]
            w = next(cursor, None)
            if w is None:
                output.append(v)
                stack.pop()
            elif w not in seen:
                seen.add(w)
                stack.append((w, iter(sorted(adj[w]))))
    return output


def decide_unit_family(graph, pins):
    """The fixed fallback cap covers all signed unit-source graphs, by Proof.md."""
    result = decide(graph, pins, 10)
    if result[0] != UNKNOWN:
        return result
    return decide(graph, pins, 3304, dfs_order=True)


def audit_star(graph, pivot, leaves, cap):
    """Evaluate three pair queries independently. Unknowns are explicit."""
    pairs = list(combinations(leaves, 2))
    if len(pairs) != 3 or len(set(leaves)) != 3 or not set(leaves) <= graph[pivot]:
        raise ValueError("expected three distinct designated neighbors")
    answers = []
    widths = []
    for u,v in pairs:
        status, _, width = decide(graph, {pivot:2, u:0, v:0}, cap)
        widths.append(width)
        answers.append(status)
    return answers, widths


def excluded_pattern(answers):
    """Return a nonempty three-bit mask proven different from the true mask."""
    for i,status in enumerate(answers):
        if status == NO:
            return 1 << i
        if status == YES:
            return 1 << ((i+1) % 3)
    return None
