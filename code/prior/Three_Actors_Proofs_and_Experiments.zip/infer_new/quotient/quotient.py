"""Graph-only equal-satisfiability certificates between undecided pins."""
from collections import Counter,defaultdict
from itertools import combinations
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'decode'))
from fuse import read_triangles,decode_blocks,reduce_factors,as_cnf


def unit_restrict(formula):
    rows={frozenset(c) for c in formula if not any(-x in c for x in c)}
    while True:
        if frozenset() in rows:
            return None
        forced={next(iter(c)) for c in rows if len(c)==1}
        if any(-x in forced for x in forced):
            return None
        if not forced:
            return frozenset(rows)
        false={-x for x in forced}
        rows={c-false for c in rows if not c&forced}


def one_group(clauses):
    """Reduce a provable guarded disjunction to its unique unrefuted branch."""
    residual=unit_restrict(clauses)
    if residual is None or not residual:
        return residual,0
    # A potential switch only ever appears unnegated in the switch row.
    counts=Counter(x for c in residual for x in c)
    for row in sorted(residual,key=lambda c:(len(c),sorted(c))):
        if not all(counts[x]==1 and counts[-x]>0 for x in row):
            continue
        groups={s:[] for s in row}
        for c in residual-{row}:
            picked=[-v for v in c if -v in row]
            if len(picked)!=1:
                break
            groups[picked[0]].append(c-{-picked[0]})
        else:
            fs=[unit_restrict(f) for f in groups.values()]
            kept=[f for f in fs if f is not None]
            if not kept:
                return None,len(fs)
            if any(not f for f in kept):
                return frozenset(),len(fs)-len(kept)
            if len(kept)==1:
                return kept[0],len(fs)-1
    return residual,0


def lifted_map(left,right,mp):
    if len(mp)!=len({abs(x) for x in mp.values()}):
        return False
    result=frozenset(frozenset(mp[abs(x)] if x>0 else -mp[abs(x)] for x in c) for c in left)
    return result==right


def sort_map(left,right):
    def keys(f):
        vs=sorted({abs(v) for c in f for v in c})
        counts=Counter(v for c in f for v in c)
        return vs,counts
    a,x=keys(left);b,y=keys(right)
    if len(a)!=len(b) or len(left)!=len(right):return None
    mp={}
    for u,v in zip(a,b):
        if (x[u],x[-u])==(y[v],y[-v]):mp[u]=v
        elif (x[u],x[-u])==(y[-v],y[v]):mp[u]=-v
        else:return None
    return mp if lifted_map(left,right,mp) else None


def incidence(cnf):
    variables=sorted({abs(x) for c in cnf for x in c})
    ids={s:v for j,x in enumerate(variables) for s,v in ((x,2*j),(-x,2*j+1))}
    n=2*len(variables)
    g=[{j^1} for j in range(n)]
    for c in sorted(cnf,key=lambda c:(len(c),sorted(c))):
        neighbors={ids[x] for x in c}
        v=len(g)
        g.append(neighbors)
        for u in neighbors:
            g[u].add(v)
    return g,[0]*n+[1]*len(cnf),variables


def iso_map(left,right):
    if len(left)!=len(right) or Counter(map(len,left))!=Counter(map(len,right)):return None,None
    aligned=sort_map(left,right)
    if aligned is not None:return aligned,'sorted'
    g,a,x=incidence(left); h,b,y=incidence(right)
    if len(g)!=len(h) or len(x)!=len(y):return None,None
    def refine(a,b):
        while True:
            ids={}
            def step(gs,cs):
                out=[]
                for i,ns in enumerate(gs):
                    key=(cs[i],tuple(sorted(cs[j] for j in ns)))
                    if key not in ids:ids[key]=len(ids)
                    out.append(ids[key])
                return out
            na,nb=step(g,a),step(h,b)
            if Counter(na)!=Counter(nb):return None,None
            stable=len(set(na))==len(set(a))
            a,b=na,nb
            if stable:return a,b
    # Polynomially capped individualization. A correct full map is always checked.
    for _ in range(len(x)+1):
        a,b=refine(a,b)
        if a is None:return None,None
        ga=defaultdict(list);gb=defaultdict(list)
        for i in range(2*len(x)):
            ga[a[i]].append(i);gb[b[i]].append(i)
        if not all(len(v)==len(gb[k]) for k,v in ga.items()):return None,None
        matched={i:j for k in ga for i,j in zip(ga[k],gb[k])}
        mp={u:(-1 if matched[2*i]%2 else 1)*y[matched[2*i]//2] for i,u in enumerate(x)}
        if lifted_map(left,right,mp):return mp,'refined'
        ambiguous=[(len(v),k) for k,v in ga.items() if len(v)>1]
        if not ambiguous:return None,None
        _,k=min(ambiguous)
        u=ga[k][0];v=gb[k][0];fresh=max(a)+1
        a[u]=fresh;b[v]=fresh
    return None,None


def actor(graph,pivot,leaves):
    parsed=read_triangles(graph,pivot)
    if parsed is None or len(set(leaves))!=3 or len(leaves)!=3 or not set(leaves)<=graph[pivot]:return None,{}
    names,raw=parsed; blocks=decode_blocks(names,raw,leaves)
    if blocks is None:return 1,{'forced_unsat':True}
    cores=[]; removed=[]
    for b,c in ((False,True),(True,False),(True,True)):
        ok,fs,_=reduce_factors(blocks,zip((names[v] for v in leaves),(False,b,c)),set())
        f,dead=one_group(as_cnf(fs)) if ok else (None,0)
        cores.append(f);removed.append(dead)
    info={'branches_removed_by_unit_conflict':removed,'remaining_clause_counts':[None if f is None else len(f) for f in cores]}
    for i,j in combinations(range(3),2):
        a,b=cores[i],cores[j]
        if a is None or b is None:
            if a==b:
                info.update(equal_pins=[i,j],basis='both_contradictions')
                return 1<<i,info
            continue
        mp,kind=iso_map(a,b)
        if mp is not None:
            info.update(equal_pins=[i,j],basis=kind,checked_signed_variable_map_size=len(mp))
            return 1<<i,info
    return None,info
