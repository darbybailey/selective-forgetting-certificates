"""Conditional SAT pruning tests. The hypothetical actor explicitly uses truth tables."""
from collections import Counter
from itertools import product
from math import ceil, log
from random import Random
import json


def evaluate(clauses, assignment):
    return all(any(((assignment >> (abs(literal) - 1)) & 1) == (literal > 0)
                   for literal in clause) for clause in clauses)


def all_models(clauses, n):
    return [a for a in range(1 << n) if evaluate(clauses, a)]


def source_formulas():
    random = Random(197702)
    for n in (4, 6, 8):
        for i in range(12):
            planted = random.randrange(1 << n)
            base = []
            while len(base) < 4*n:
                variables = random.sample(range(1, n+1), 3)
                clause = tuple(x if random.randrange(2) else -x for x in variables)
                if evaluate([clause], planted):
                    base.append(clause)
            yield 'planted', n, base
            yield 'unique', n, base + [(x if (planted >> (x-1)) & 1 else -x,)
                                      for x in range(1, n+1)]
            # All eight sign choices on a planted clause support jointly rule it out.
            u, v, w = (abs(x) for x in base[0])
            conflict = [(u*s, v*t, w*r) for s,t,r in product((-1,1), repeat=3)]
            yield 'unsatisfiable', n, base+conflict


def response_weights(survivors):
    """Adversarial controlled model, using known exact truth to generate votes out of 12."""
    good = [i for i, value in enumerate(survivors) if value]
    bad = [i for i, value in enumerate(survivors) if not value]
    if len(good) == 1:
        # Plurality goes to a wrong answer; the unique viable index beats 1/3.
        out = [0]*3
        out[good[0]], out[bad[0]], out[bad[1]] = 5, 6, 1
        return out
    if len(good) == 2:
        # In a multiple-survivor group it is safe even to lose one true option.
        out = [0]*3
        out[good[0]], out[good[1]], out[bad[0]] = 1, 6, 5
        return out
    return [4,4,4]


def sample_votes(weights, repeats, random):
    counts = [0,0,0]
    for _ in range(repeats):
        z = random.randrange(sum(weights))
        i = 0 if z < weights[0] else (1 if z < weights[0]+weights[1] else 2)
        counts[i] += 1
    return counts


def frontier_search(clauses, n, reference_models, policy, stats, random):
    # This control uses the reference models exclusively to simulate the hypothetical
    # selector. Actual use of the reduction would query its graph-input implementation.
    prefixes = [0]
    delta = 1/12
    repeats = ceil(9*log(36*n)/(2*delta**2))
    for depth in range(1,n+1):
        expanded = [prefix | (value << (depth-1))
                    for prefix in prefixes for value in (0,1)]
        while len(expanded) > 2:
            group = expanded[:3]
            alive = [any((witness & ((1<<depth)-1)) == prefix
                         for witness in reference_models) for prefix in group]
            weights = response_weights(alive)
            if policy == 'sampled':
                weights = sample_votes(weights,repeats,random)
                stats['draws'] += repeats
            removed = min(range(3),key=lambda i: weights[i])
            if sum(alive) == 1:
                stats['unique_groups'] += 1
                if not alive[max(range(3),key=lambda i: weights[i])]:
                    stats['wrong_plurality_unique_groups'] += 1
                if alive[removed]:
                    stats['lost_only_survivor_in_group'] += 1
            if sum(alive) == 2 and alive[removed]:
                stats['removed_one_of_two_survivors'] += 1
            expanded.pop(removed)
            stats['triple_comparisons'] += 1
        prefixes = expanded
    return next((w for w in prefixes if evaluate(clauses,w)),None)


def exhaustive_pruning_checks():
    cases = 0
    loss = 0
    strictly_admissible = 0
    for truth in product((False,True), repeat=3):
        for a in range(13):
            for b in range(13-a):
                weights = [a,b,12-a-b]
                if sum(truth) == 1 and weights[truth.index(True)] <= 4:
                    continue
                # Any frequency tie at the bottom may be broken arbitrarily.
                strictly_admissible += 1
                for drop in range(3):
                    if weights[drop] != min(weights):
                        continue
                    cases += 1
                    loss += any(truth) and not any(ok for i,ok in enumerate(truth) if i != drop)
    assert loss == 0
    return {'denominator':12, 'patterns_and_admissible_vote_vectors':strictly_admissible,
            'allowed_bottom_tie_breaks':cases,'unsafe_drops':loss}


def main():
    report = {}
    for policy in ['exact','sampled']:
        stats = Counter()
        random = Random(33883)
        outcomes = Counter()
        for kind, n, clauses in source_formulas():
            models = all_models(clauses,n)
            answer = frontier_search(clauses,n,models,policy,stats,random)
            if answer is not None:
                assert evaluate(clauses,answer)
            assert (answer is not None) == bool(models), (kind,n,policy)
            outcomes[kind] += 1
        report[policy] = {'formula_cases':dict(outcomes),'comparisons': dict(sorted(stats.items()))}
    # A model has its only correct candidate in the middle of these three frequencies.
    report['plurality_control'] = {'viable_pattern':[False,True,False],
                                   'votes':response_weights([False,True,False]),
                                   'plurality_correct':False,'bottom_deletion_safe':True}
    # On an exactly uniform response a tie rule can erase the only survivor.
    blind_safe = [drop != survivor for survivor in range(3) for drop in [0]]
    report['blind_bottom_tie'] = {'exact_uniform_votes':[4,4,4], 'drop_index':0,
                                  'retains_only_survivor_by_index':blind_safe}
    report['exhaustive_single_step'] = exhaustive_pruning_checks()
    return report


if __name__ == '__main__':
    print(json.dumps(main(),indent=2,sort_keys=True))
