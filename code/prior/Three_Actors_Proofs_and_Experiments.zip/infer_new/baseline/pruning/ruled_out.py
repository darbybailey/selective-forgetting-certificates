"""Seven-way compression from any ruled-out nonempty three-bit pattern."""
from itertools import product
import json
from frontier import all_models, evaluate, source_formulas


def encode_or(formulas):
    """An ordinary width-at-most-three CNF equisatisfiable to a disjunction of CNFs."""
    last = max([abs(lit) for formula in formulas for clause in formula for lit in clause], default=0)
    switches = []
    for _ in formulas:
        last += 1
        switches.append(last)
    long_clauses = [tuple(switches)] + [
        (-s,)+tuple(c) for s,formula in zip(switches, formulas) for c in formula
    ]
    clauses = []
    for clause in long_clauses:
        while len(clause)>3:
            last += 1
            clauses.append((clause[0],clause[1],last))
            clause=(-last,)+clause[2:]
        clauses.append(clause)
    return clauses,last


def bit_questions(sources):
    return [encode_or([f for i,f in enumerate(sources,1) if i & (1 << j)]) for j in range(3)]


def combined_code(survivors):
    pattern = 0
    for i,decision in enumerate(survivors,1):
        if decision:
            pattern |= i
    return pattern


def verify_coded_questions():
    queries = drops = 0
    for truth in product((False,True),repeat=7):
        # A satisfiable source is a genuine 3-literal disjunction. Unsatisfiable
        # sources retain this clause and add a conflicting pair of units.
        sources = [[(1,2,3)] if good else [(1,2,3),(1,),(-1,)] for good in truth]
        bits = []
        for formula, n in bit_questions(sources):
            assert max(map(len,formula))<=3
            bits.append(any(evaluate(formula,a) for a in range(1<<n)))
            queries+=1
        actual = sum((1<<j) for j,bit in enumerate(bits) if bit)
        assert actual == combined_code(truth)
        for discarded in range(1,8):
            if actual == discarded:
                continue
            assert not any(truth) or any(yes for i,yes in enumerate(truth,1) if i!=discarded)
            drops += 1
    return {'source_membership_patterns':128,'ordinary_3CNF_OR_queries':queries,
            'safe_discards_for_all_admissible_oracle_outputs':drops}


def known_false_report(survivors):
    """Controlled worst-case actor uses ground truth. Prefer discarding a live branch."""
    actual = combined_code(survivors)
    allowed = [i for i in range(1,8) if i != actual]
    return next((i for i in allowed if survivors[i-1]), allowed[0])


def verify_frontier():
    cases = groups = existing_dropped = 0
    for kind, n, clauses in source_formulas():
        witnesses = all_models(clauses,n)
        prefixes = [0]
        for depth in range(1,n+1):
            prefixes = [p | (choice<<(depth-1)) for p in prefixes for choice in (0,1)]
            while len(prefixes)>6:
                truth=[any((w&((1<<depth)-1))==p for w in witnesses) for p in prefixes[:7]]
                index=known_false_report(truth)-1
                existing_dropped += int(truth[index])
                del prefixes[index]
                groups+=1
        assert any(evaluate(clauses,p) for p in prefixes)==bool(witnesses)
        cases+=1
    return {'controlled_formula_runs':cases,'group_calls':groups,'discarded_live_branches':existing_dropped}


if __name__ == '__main__':
    print(json.dumps({'coding':verify_coded_questions(),'frontier':verify_frontier()},indent=2,sort_keys=True))
