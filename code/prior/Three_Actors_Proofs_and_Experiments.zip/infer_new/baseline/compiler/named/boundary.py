"""Exact finite checks for nonedge relations in four-coloring. Python 3 standard library."""
from itertools import combinations, product, permutations
from functools import lru_cache
import json
from random import Random


def add_edge(graph, u, v):
    graph[u].add(v)
    graph[v].add(u)


@lru_cache(maxsize=None)
def triangle_support(domain0, domain1, domain2):
    """All colors supported by an injective assignment of this triangle."""
    support = [0, 0, 0]
    for i, j, k in permutations((1, 2, 4, 8), 3):
        if domain0 & i and domain1 & j and domain2 & k:
            support[0] |= i
            support[1] |= j
            support[2] |= k
    return tuple(support)


def coloring(graph, k, pins=None):
    """Complete graph-only backtracking with exact edge and triangle filtering."""
    pins = pins or {}
    full = (1 << k) - 1
    initial = [1 << pins[v] if v in pins else full for v in range(len(graph))]
    triangles = [[] for _ in graph]
    for x, neighbors in enumerate(graph):
        for y, z in combinations(sorted(w for w in neighbors if w > x), 2):
            if z in graph[y]:
                tri = x, y, z
                for v in tri:
                    triangles[v].append(tri)

    def propagate(domains, changed):
        pending = set(changed)
        while pending:
            x = pending.pop()
            mask = domains[x]
            if not mask:
                return False
            if mask.bit_count() == 1:
                for y in graph[x]:
                    if domains[y] & mask:
                        domains[y] ^= mask
                        if not domains[y]:
                            return False
                        pending.add(y)
            for tri in triangles[x]:
                allowed = triangle_support(*(domains[y] for y in tri))
                for y, new in zip(tri, allowed):
                    if not new:
                        return False
                    if new != domains[y]:
                        domains[y] = new
                        pending.add(y)
        return True

    if not propagate(initial, range(len(graph))):
        return None

    # Pinning may disconnect the remaining CSP. This split uses graph structure.
    remaining = {v for v, domain in enumerate(initial) if domain.bit_count() > 1}
    components = []
    while remaining:
        seed = min(remaining)
        remaining.remove(seed)
        component = []
        stack = [seed]
        while stack:
            v = stack.pop()
            component.append(v)
            for w in graph[v]:
                if w in remaining:
                    remaining.remove(w)
                    stack.append(w)
        components.append(component)

    def extend(domains, component):
        undecided = [(domains[v].bit_count(), -len(graph[v]), v)
                     for v in component if domains[v].bit_count() > 1]
        if not undecided:
            return domains
        v = min(undecided)[2]
        for color in range(k):
            mask = 1 << color
            if domains[v] & mask:
                choice = domains.copy()
                choice[v] = mask
                if propagate(choice, [v]):
                    result = extend(choice, component)
                    if result is not None:
                        return result
        return None

    current = initial
    for component in components:
        current = extend(current, component)
        if current is None:
            return None
    colors = tuple(mask.bit_length() - 1 for mask in current)
    assert valid(graph, colors)
    assert all(colors[v] == c for v, c in pins.items())
    return colors


def valid(graph, colors):
    return len(colors) == len(graph) and all(colors[v] != colors[w]
            for v, nbrs in enumerate(graph) for w in nbrs)


def make_graph(n, triples):
    # Vertex 0 excludes one of the first three colors on all variable nodes 1..n.
    h = [set() for _ in range(1 + n + 3 * len(triples))]
    known = [2] + [0] * n
    for i in range(n):
        add_edge(h, 0, 1 + i)
    for j, clause in enumerate(triples):
        tri = [1 + n + 3 * j + i for i in range(3)]
        for v, w in combinations(tri, 2):
            add_edge(h, v, w)
        for v, x in zip(tri, clause):
            add_edge(h, v, x + 1)
        known.extend([1, 2, 3])
    assert valid(h, known)
    return h, known


def equality_instance(h, known):
    a, b = len(h), len(h) + 1
    g = [s.copy() for s in h] + [set(), set()]
    for v, color in enumerate(known):
        add_edge(g, v, b if color == 0 else a)
    assert valid(g, known + [0, 1])
    return g, a, b


def difference_instance(g, a, b, known):
    c, p, q = range(len(g), len(g) + 3)
    g = [s.copy() for s in g] + [set(), set(), set()]
    add_edge(g, p, q)
    for v in (a, b, c):
        for w in (p, q):
            add_edge(g, w, v)
    add_edge(g, b, c)
    assert valid(g, known + [0, 2, 3])
    return g, c


def nae(n, clauses):
    return any(all(len({bits[v] for v in es}) == 2 for es in clauses)
               for bits in product(range(2), repeat=n))


def test_gadgets(n, clauses):
    expected = nae(n, clauses)
    h, known = make_graph(n, clauses)
    assert (coloring(h, 3, {0: 2}) is not None) == expected
    g, a, b = equality_instance(h, known)
    assert (coloring(g, 4, {a: 0, b: 0}) is not None) == expected
    i, c = difference_instance(g, a, b, known + [0, 1])
    assert (coloring(i, 4, {a: 0, c: 1}) is not None) == expected
    return expected


def verify_finite_families():
    fano = [tuple(sorted((i, (i+1) % 7, (i+3) % 7))) for i in range(7)]
    results = {}
    for name, n, base in [('all_subsets_of_triples_on_5_points', 5,
                            list(combinations(range(5), 3))),
                           ('all_subsets_of_fano_lines', 7, fano)]:
        total = sat = 0
        for mask in range(1 << len(base)):
            clauses = [e for j, e in enumerate(base) if (mask >> j) & 1]
            sat += test_gadgets(n, clauses)
            total += 1
        results[name] = {'inputs': total, 'NAE_satisfiable': sat,
                          'NAE_unsatisfiable': total-sat}
    return results


def glue(g, g_term, h, h_term):
    """Union with exactly two ordered terminal identifications."""
    mapping = dict(zip(h_term, g_term))
    union = [s.copy() for s in g]
    for w in range(len(h)):
        if w not in mapping:
            mapping[w] = len(union)
            union.append(set())
    for w, adjacent in enumerate(h):
        for u in adjacent:
            if w < u:
                add_edge(union, mapping[w], mapping[u])
    assert g_term[1] not in union[g_term[0]]
    return union, mapping


def two_source_instance(first, second):
    n, es = first
    h, known = make_graph(n, es)
    g, a, b = equality_instance(h, known)
    n, es = second
    h, known = make_graph(n, es)
    h, d, e = equality_instance(h, known)
    inverted, f = difference_instance(h, d, e, known + [0, 1])
    graph, right_map = glue(g, (a, b), inverted, (d, f))
    hubs = {a, b, right_map[e]}
    assert all(i in hubs or hubs.intersection(nbrs)
               for i, nbrs in enumerate(graph))
    assert set.intersection(*(graph[i] for i in hubs))
    variables = first[0] + second[0]
    nclauses = len(first[1]) + len(second[1])
    assert len(graph) == 7 + variables + 3 * nclauses
    assert sum(map(len, graph)) // 2 == 10 + 2 * variables + 9 * nclauses
    return graph, a, b


def shuffle_graph(g, terminals, rng):
    labels = list(range(len(g)))
    rng.shuffle(labels)
    h = [set() for _ in g]
    for i, e in enumerate(g):
        h[labels[i]] = {labels[j] for j in e}
    return h, tuple(labels[t] for t in terminals)


def check_glue():
    # Mix a Fano obstruction and its single-line deletion, K5, and balanced
    # seeded random sources. Keep all source truth labels only in the test.
    rng = Random(20261123)
    fano = [tuple(sorted((i, (i+1) % 7, (i+3) % 7))) for i in range(7)]
    sources = [(7, sorted(fano)), (7, sorted(fano[:-1])),
               (5, list(combinations(range(5), 3))), (5, [(0, 1, 2)])]
    counts = {False: 2, True: 2}
    while min(counts.values()) < 8:
        n = rng.randrange(5, 8)
        edges = list(combinations(range(n), 3))
        clauses = sorted(rng.sample(edges, rng.randint(5, len(edges))))
        source = n, clauses
        flag = nae(*source)
        if counts[flag] < 8 and source not in sources:
            sources.append(source)
            counts[flag] += 1
    truth = [nae(*source) for source in sources]
    tally = dict.fromkeys(('both', 'equal_only', 'different_only', 'neither'), 0)
    max_size = 0
    fano_cases = {}
    for i, first in enumerate(sources):
        for j, second in enumerate(sources):
            g, a, b = two_source_instance(first, second)
            g, (a, b) = shuffle_graph(g, (a, b), rng)
            max_size = max(max_size, len(g))
            x = coloring(g, 4, {a: 0, b: 0}) is not None
            y = coloring(g, 4, {a: 0, b: 1}) is not None
            assert (x, y) == (truth[i], truth[j]), (i, j, x, y)
            status = [['neither', 'different_only'], ['equal_only', 'both']][x][y]
            tally[status] += 1
            if i < 2 and j < 2:
                fano_cases[f'{i},{j}'] = status
    return {'seed': 20261123, 'source_truth': truth, 'sources': [
            {'variables': n, 'hyperedges': clauses} for n, clauses in sources],
            'ordered_source_pairs': sum(tally.values()), 'counts': tally,
            'max_graph_vertices': max_size,
            'fano_0_and_fano_deletion_1': fano_cases}


def verify_coloring_solver():
    edges = list(combinations(range(5), 2))
    checks = 0
    for mask in range(1 << len(edges)):
        graph = [set() for _ in range(5)]
        chosen = [edge for i, edge in enumerate(edges) if (mask >> i) & 1]
        for u, v in chosen:
            add_edge(graph, u, v)
        for k, second in product((3, 4), (0, 1)):
            expected = False
            for tail in product(range(k), repeat=3):
                colors = (0, second) + tail
                if all(colors[x] != colors[y] for x, y in chosen):
                    expected = True
                    break
            assert (coloring(graph, k, {0: 0, 1: second}) is not None) == expected
            checks += 1
    return checks


if __name__ == '__main__':
    results = {'named_single_source': verify_finite_families(),
               'named_two_sources': check_glue(),
               'direct_solver_crosschecks': verify_coloring_solver()}
    print(json.dumps(results, indent=2))
