"""Three independently selectable equal-pair branches of a deterministic 3-color star."""
from itertools import combinations, product
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "named"))
from boundary import add_edge, coloring, valid


class Builder:
    def __init__(self):
        # Pivot, zero, switch b, switch c, and one in exact vertex order.
        self.graph = [set() for _ in range(5)]
        self.negation = {1: 4, 4: 1}
        for u, v in ((0, 1), (0, 4), (1, 4), (0, 2), (0, 3)):
            add_edge(self.graph, u, v)

    def vertex(self):
        self.graph.append(set())
        return len(self.graph) - 1

    def boolean(self):
        v = self.vertex()
        add_edge(self.graph, v, 0)
        return v

    def opposite(self, v):
        if v not in self.negation:
            w = self.boolean()
            add_edge(self.graph, v, w)
            self.negation[w], self.negation[v] = v, w
        return self.negation[v]

    def nae(self, x, y, z):
        tri = [self.vertex() for _ in range(3)]
        for v, w in combinations(tri, 2):
            add_edge(self.graph, v, w)
        for v, w in zip(tri, (x, y, z)):
            add_edge(self.graph, v, w)

    def three_or(self, x, y, z):
        w = self.boolean()
        self.nae(x, y, w)
        self.nae(self.opposite(w), z, 1)

    def clause(self, literals):
        literals = list(literals)
        while len(literals) > 3:
            w = self.boolean()
            self.three_or(literals[0], literals[1], w)
            literals = [self.opposite(w)] + literals[2:]
        self.three_or(*(literals + [1] * (3 - len(literals))))


CODES = [(0, 1), (1, 0), (1, 1)]
PAIRS = [(1, 2), (1, 3), (2, 3)]


def make_star(sources):
    build = Builder()
    build.clause([2, 3])
    for source, code in zip(sources, CODES):
        guards = [v if bit == 0 else build.opposite(v)
                  for v, bit in zip((2, 3), code)]
        variables = {}
        for clause in source:
            signed = []
            for literal in clause:
                if abs(literal) not in variables:
                    variables[abs(literal)] = build.boolean()
                v = variables[abs(literal)]
                signed.append(v if literal > 0 else build.opposite(v))
            build.clause(guards + signed)
    return build.graph


def raise_minimum_degree(graph):
    padded = [neighbors.copy() for neighbors in graph]
    for v, neighbors in enumerate(graph):
        for _ in range(max(3 - len(neighbors), 0)):
            base = len(padded)
            padded.extend(set() for _ in range(6))
            for i, j in product(range(3), range(3, 6)):
                add_edge(padded, base + i, base + j)
            add_edge(padded, v, base)
            # Both private shores may use the two colors other than the pivot.
            # Joining the new vertices to it keeps every vertex within distance two.
            for w in range(base, base + 6):
                add_edge(padded, 0, w)
    return padded


def verify():
    possible = ((1, 2),)   # x or y
    impossible = ((1,), (-1,))
    # Width-three clauses exercise both extension variables of a guarded five-OR.
    sat_three = tuple(clause for clause in product((1, -1), (2, -2), (3, -3))
                      if clause != (1, 2, 3))
    unsat_three = tuple(product((1, -1), (2, -2), (3, -3)))
    cases = [(support, [possible if b else impossible for b in support])
             for support in product((False, True), repeat=3)]
    cases.extend([((True, False, True), [sat_three, unsat_three, possible]),
                  ((False, True, False), [unsat_three, sat_three, impossible])])
    rows = []
    for support, sources in cases:
        graph = make_star(sources)
        padded = raise_minimum_degree(graph)
        assert min(len(s) for s in padded) >= 3
        assert sorted(padded[0])[:3] == [1, 2, 3]
        assert all(v == 0 or v in padded[0] or neighbors & padded[0]
                   for v, neighbors in enumerate(padded))
        for want, formula in zip(support, sources):
            n = max(abs(lit) for clause in formula for lit in clause)
            assert any(all(any(bits[abs(lit) - 1] == (lit > 0) for lit in clause)
                               for clause in formula) for bits in product((0, 1), repeat=n)
                       ) == want
        expected = dict(zip(CODES, support))
        outcomes = []
        for g in (graph, padded):
            found = []
            for b, c in product((0, 1), repeat=2):
                colors = coloring(g, 3, {0: 2, 1: 0, 2: b, 3: c})
                flag = colors is not None
                assert flag == expected.get((b, c), False)
                if flag:
                    assert valid(g, colors)
                    equal = [pair for pair in PAIRS if colors[pair[0]] == colors[pair[1]]]
                    assert equal == [PAIRS[CODES.index((b, c))]]
                found.append(flag)
            outcomes.append(found)
        assert outcomes[0] == outcomes[1]
        rows.append({'source_sats': list(support), 'core_vertices': len(graph),
                     'padded_vertices': len(padded), 'terminals_00_01_10_11': outcomes[0]})
    return {'source_triples': len(cases), 'pinned_graph_decisions': 8 * len(cases),
            'full_width_source_controls': 2, 'cases': rows}


if __name__ == '__main__':
    print(json.dumps(verify(), indent=2))
