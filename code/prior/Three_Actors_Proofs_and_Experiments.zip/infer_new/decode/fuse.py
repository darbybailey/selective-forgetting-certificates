"""Recover NAE factors from a verified graph skeleton, then forget low-occurrence bits."""
from collections import defaultdict
from itertools import product


def read_triangles(graph, pivot):
    boolean = set(graph[pivot])
    outside = set(range(len(graph))) - boolean - {pivot}
    if any(v in graph[v] or any(v not in graph[w] for w in graph[v])
           for v in range(len(graph))):
        return None
    name = {}
    for v in sorted(boolean):
        partners = graph[v] & boolean
        if len(partners) > 1:
            return None
        if v in name:
            continue
        name[v] = v + 2
        if partners:
            name[next(iter(partners))] = -(v + 2)
    factors = []
    while outside:
        v = next(iter(outside))
        triangle = (graph[v] & outside) | {v}
        if len(triangle) != 3:
            return None
        pins = []
        for w in triangle:
            adjacent = graph[w] & boolean
            if len(adjacent) != 1 or graph[w] != (triangle - {w}) | adjacent:
                return None
            pins.append(name[next(iter(adjacent))])
        factors.append(tuple(pins))
        outside -= triangle
    return name, factors


def normalize(raw):
    """NAE is unchanged by flipping every entry; +/-1 are fixed true/false."""
    f = frozenset(raw)
    if any(-x in f for x in f):
        return None
    negated = frozenset(-x for x in f)
    return f if min(f, default=0) < min(negated, default=0) else negated


def reduce_factors(factors, pins, allowed=None):
    assigned = {}
    for value, flag in pins:
        fixed = flag if value > 0 else not flag
        if abs(value) in assigned and assigned[abs(value)] != fixed:
            return False, set(), 0
        assigned[abs(value)] = fixed
    def substitute(x):
        if abs(x) not in assigned:
            return x
        return 1 if assigned[abs(x)] == (x > 0) else -1
    fs = {normalize(substitute(x) for x in f) for f in factors}
    fs.discard(None)
    merges = 0
    while True:
        if any(len(f)<2 for f in fs):
            return False, set(), merges
        occurs = defaultdict(list)
        for f in fs:
            for x in f:
                if abs(x) != 1 and (allowed is None or abs(x) in allowed):
                    occurs[abs(x)].append((x, f))
        low = min((v for v, incident in occurs.items() if len(incident)<=2),
                  key=lambda v: (len(occurs[v]),v), default=None)
        if low is None:
            return True, fs, merges
        incident = occurs[low]
        for _, f in incident:
            fs.remove(f)
        if len(incident) == 2:
            (x,f),(y,g) = incident
            tail = g-{y}
            if x == y:
                tail = {-a for a in tail}
            merged = normalize((f-{x}) | tail)
            if merged is not None:
                fs.add(merged)
            merges += 1


def residual_components(fs):
    index = defaultdict(set)
    for f in fs:
        for x in f:
            if abs(x)>1:
                index[abs(x)].add(f)
    rest = set(index)
    while rest:
        stack = [min(rest)]
        rest.remove(stack[0])
        variables, factors = [], set()
        while stack:
            v = stack.pop()
            variables.append(v)
            for f in index[v] - factors:
                factors.add(f)
                for x in f:
                    w = abs(x)
                    if w in rest:
                        rest.remove(w)
                        stack.append(w)
        yield variables, factors


def evaluate(component, factors):
    for values in product((False,True),repeat=len(component)):
        assignment = dict(zip(component,values))
        assignment[1] = True
        if all(len({assignment[abs(x)] == (x>0) for x in f})==2 for f in factors):
            return True
    return False


def analyze(graph, pivot, leaves, multiplier=1):
    """Return the four individual pin statuses, plus residual sizes. Fixed multiplier."""
    parsed = read_triangles(graph,pivot)
    if parsed is None or len(leaves)!=3 or not set(leaves)<=set(graph[pivot]):
        return None
    names, factors = parsed
    results = []
    for b,c in product((False,True), repeat=2):
        ok, fs, merges = reduce_factors(factors,zip((names[v] for v in leaves),(False,b,c)))
        status = ok
        sizes = []
        if ok:
            for component, fset in residual_components(fs):
                sizes.append(len(component))
                if len(component)>multiplier*(len(graph).bit_length()-1):
                    if status is not False:
                        status = None
                elif not evaluate(component,fset):
                    status = False
        results.append((status, sorted(sizes,reverse=True), merges))
    return results


def exclude(results):
    if results is None:
        return None
    possibilities = set()
    for truth in product((False,True),repeat=4):
        if all(row[0] is None or row[0] == t for t,row in zip(truth,results)):
            possibilities.add(7 if truth[0] else sum(1<<(i-1) for i in range(1,4) if truth[i]))
    return next((i for i in range(1,8) if i not in possibilities),None)


def decode_blocks(name, triangles, leaves):
    """Freeze the high-incidence variables, split private pieces, and project each exactly."""
    constraints_by_var = defaultdict(list)
    for index, f in enumerate(triangles):
        for x in f:
            constraints_by_var[abs(x)].append(index)
    named = {abs(name[v]) for v in leaves}
    private = {v for v, ids in constraints_by_var.items() if len(ids)<=2} - named
    parent = list(range(len(triangles)))

    def root(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    for v in private:
        indices = constraints_by_var[v]
        if len(indices) == 2:
            parent[root(indices[0])] = root(indices[1])
    blocks = defaultdict(list)
    for i,f in enumerate(triangles):
        blocks[root(i)].append(f)
    projected = set()
    for block in blocks.values():
        ok, residue, _ = reduce_factors(block,(),private)
        if not ok:
            return None
        projected.update(residue)
    return projected


def two_sat(clauses):
    """Test implication reachability in both directions for each complementary pair."""
    outgoing = defaultdict(set)
    for row in clauses:
        if len(row) == 0:
            return False
        a,b = row if len(row) == 2 else (row[0],row[0])
        outgoing[-a].add(b)
        outgoing[-b].add(a)
    def closure(x):
        seen, work = {x},[x]
        while work:
            here = work.pop()
            for nxt in outgoing.get(here,set())-seen:
                work.append(nxt)
                seen.add(nxt)
        return seen
    return not any(-x in closure(x) and x in closure(-x)
                   for x in {abs(y) for row in clauses for y in row})


def as_cnf(factors):
    clauses = set()
    for f in factors:
        for side in (f,{-x for x in f}):
            if 1 not in side:
                clauses.add(tuple(sorted(side-{-1})))
    return clauses


def backdoor_2sat(clauses, budget):
    """Exact SAT when deleting at most budget variables reduces clause width to two."""
    def choose(used):
        large = next((tuple(abs(x) for x in c if abs(x) not in used) for c in clauses
                      if sum(abs(x) not in used for x in c)>2), None)
        if large is None:
            return used
        if len(used)==budget:
            return None
        for v in large[:3]:
            hit = choose(used | {v})
            if hit is not None:
                return hit
        return None
    cover = choose(set())
    if cover is None:
        return None
    for flags in product((False,True),repeat=len(cover)):
        pins=dict(zip(sorted(cover),flags))
        reduced = []
        for c in clauses:
            if not any(pins.get(abs(x))==(x>0) for x in c):
                reduced.append(tuple(x for x in c if abs(x) not in pins))
        if two_sat(reduced):
            return True
    return False


def transparent(graph, pivot, leaves, budget=4):
    parsed = read_triangles(graph,pivot)
    if parsed is None or len(leaves)!=3 or not set(leaves)<=set(graph[pivot]):
        return None
    names, factors = parsed
    blocks = decode_blocks(names,factors,leaves)
    if blocks is None:
        return [(False,[],0)]*4
    result=[]
    for b,c in product((False,True),repeat=2):
        pins = zip((names[v] for v in leaves),(False,b,c))
        ok, fs, _ = reduce_factors(blocks,pins,set())
        if not ok:
            result.append((False,[],0))
            continue
        clauses = as_cnf(fs)
        width = max(map(len,clauses),default=0)
        status = backdoor_2sat(clauses,budget)
        result.append((status, [width], len(clauses)))
    return result


def core_after_blocks(graph,pivot,leaves,multiplier=1):
    """Reserve high-incidence variables during encoding inversion before core enumeration."""
    parsed=read_triangles(graph,pivot)
    if parsed is None or len(leaves)!=3 or not set(leaves)<=set(graph[pivot]):
        return None
    names,triangles=parsed
    blocks=decode_blocks(names,triangles,leaves)
    if blocks is None:
        return [(False,[],0)]*4
    result=[]
    for b,c in product((False,True),repeat=2):
        ok,fs,merges=reduce_factors(blocks,zip((names[v] for v in leaves),(False,b,c)))
        status=ok
        sizes=[]
        if ok:
            for vs,fs0 in residual_components(fs):
                sizes.append(len(vs))
                if len(vs)>multiplier*(len(graph).bit_length()-1):
                    if status is not False:
                        status=None
                elif not evaluate(vs,fs0):
                    status=False
        result.append((status,sorted(sizes,reverse=True),merges))
    return result
