"""Read exact Boolean boundary variables of disjoint nine-point charts from unnamed triples."""
from collections import Counter,defaultdict
from itertools import combinations
from math import prod


def parities(vertices,links):
    adjacency={v:[] for v in vertices}
    for a,b,h in links:
        adjacency[a].append((b,h)); adjacency[b].append((a,h))
    root,phase={},{}
    for anchor in adjacency:
        if anchor in root:continue
        root[anchor]=anchor;phase[anchor]=0;todo=[anchor]
        while todo:
            v=todo.pop()
            for u,h in adjacency[v]:
                if u not in root:
                    root[u]=anchor; phase[u]=phase[v]^h;todo.append(u)
                elif phase[u] != phase[v]^h:
                    return None
    return root,phase


def charts_of(edges):
    incident=defaultdict(set)
    for e in edges:
        if len(e)!=3:return None
        for v in e:incident[v].add(e)
    if any(len(es)!=4 for es in incident.values()):return None
    candidates=set()
    for v,es in incident.items():
        keys=frozenset().union(*es)
        if len(keys)!=9: return None
        candidates.add(keys)
    result=[]
    for cand in candidates:
        local=set().union(*(incident[v] for v in cand))
        inside={e for e in local if e<=cand}
        if len(inside)!=10:continue
        deg=Counter(v for e in inside for v in e)
        ports=tuple(sorted(v for v in cand if deg[v]==3))
        if len(ports)!=6 or not all(deg[v] in (3,4) for v in cand):continue
        if any((e & cand)-set(ports) for e in local-inside):continue
        order=tuple(sorted(cand))
        index={v:i for i,v in enumerate(order)}
        ids=[index[v] for v in ports]
        mask=[sum(1<<index[v] for v in e) for e in inside]
        models=defaultdict(list)
        for w in range(512):
            if all(0 < w & m < m for m in mask):
                label=tuple((w>>i)&1 for i in ids)
                models[label].append(w)
        if len(models)!=2:continue
        pat=next(bits for bits in models if bits[0]==0) if any(not b[0] for b in models) else None
        if pat is None or tuple(1-x for x in pat) not in models:continue
        if len(models[pat])!=len(models[tuple(1-x for x in pat)]):continue
        result.append((cand,inside,ports,pat,len(models[pat]),order,models[pat][0]))
    owner=set()
    for cand,*_ in result:
        if owner & cand:return None
        owner.update(cand)
    if owner!=set(incident):return None
    return result


def ungauge(rows):
    rows={frozenset(r) for r in rows}
    if not rows:return None
    equations=[];edges=set()
    for row in rows:
        if len(row)!=3 or frozenset(-u for u in row) not in rows:return None
        e=frozenset(abs(u) for u in row)
        if len(e)!=3:return None
        edges.add(e)
        for u,v in combinations(row,2):equations.append((abs(u),abs(v),(u<0)^(v<0)))
    gauge=parities(set().union(*edges),equations)
    if gauge is None:return None
    return edges,gauge[1]


def kernel(edges):
    edges={frozenset(e) for e in edges}
    charts=charts_of(edges)
    if not charts:return None
    mapping={};internals=set()
    for _,ins,ports,pat,*_ in charts:
        internals.update(ins)
        for v,h in zip(ports,pat):mapping[v]=ports[0],h
    anchors=[c[2][0] for c in charts]
    links=[];payload=[]
    for e in edges-internals:
        if not all(v in mapping for v in e):return None
        row={mapping[v] for v in e}
        if any((v,1-h) in row for v,h in row):continue
        if len(row)==1:
            return {'inconsistent':True,'blocks':len(charts)}
        if len(row)==2:
            (u,k),(v,h)=row
            links.append((u,v,1^k^h))
        else:payload.append(row)
    labeling=parities(anchors,links)
    if labeling is None:return {'inconsistent':True,'blocks':len(charts)}
    owner,phase=labeling
    vertices=set(owner.values())
    compact=Counter()
    for row in payload:
        signed=frozenset((owner[v],phase[v]^h) for v,h in row)
        if any((v,1-h) in signed for v,h in signed):continue
        if len(signed)==1:return {'inconsistent':True,'blocks':len(charts)}
        key=tuple(sorted(signed))
        mirror=tuple((v,1-h) for v,h in key)
        compact[min(key,mirror)]+=1
    gauge_eqs=[(u,v,h^k) for row in compact for (u,h),(v,k) in combinations(row,2)]
    monotone=parities(vertices,gauge_eqs)
    mono_rows=None if monotone is None else {tuple(v for v,h in row) for row in compact}
    return {'inconsistent':False,'blocks':len(charts),'charts':charts,'owner':owner,'phase':phase,
            'roots':vertices,'rows':compact,'monotone':mono_rows,'monotone_phase':None if monotone is None else monotone[1],
            'multipliers':Counter(c[4] for c in charts)}


def lift(k,usermodel):
    assignment={}
    for _,_,ports,pat,_,order,word in k['charts']:
        a=ports[0];r=k['owner'][a]
        flipped=k['phase'][a]^usermodel[r]
        for i,v in enumerate(order):assignment[v]=(word>>i)&1^flipped
    return assignment


def iso(a,b,cap=100000):
    """Bounded search for a verified unsigned hypergraph isomorphism; failures abstain."""
    if len(a)!=len(b) or not a or not b:return None
    A={frozenset(e) for e in a};B={frozenset(e) for e in b}
    av=sorted(set.union(*(set(x) for x in A)));bv=sorted(set.union(*(set(x) for x in B)))
    if len(av)!=len(bv):return None
    ordinal={v:i for i,v in enumerate(av)}
    def residual_hist(edges,part):
        return Counter((len(e),tuple(sorted(part[v] for v in e if v in part))) for e in edges)
    budget=[cap]
    def rec(mapping,used):
        budget[0]-=1
        if budget[0]<0:return None
        if len(mapping)==len(av):
            return mapping.copy() if {frozenset(mapping[v] for v in e) for e in A}==B else None
        qa=max((v for v in av if v not in mapping),key=lambda v:sum(3**len(e & mapping.keys()) for e in A if v in e))
        h=residual_hist(A,{v:ordinal[v] for v in [*mapping,qa]})
        part={t:ordinal[s] for s,t in mapping.items()}
        for qb in bv:
            if qb in used:continue
            part[qb]=ordinal[qa]
            if residual_hist(B,part)==h:
                mapping[qa]=qb
                r=rec(mapping,used|{qb});del mapping[qa]
                if r is not None:return r
            del part[qb]
            if budget[0]<0:break
        return None
    return rec({},set())
